# My VoIP — Android SIP phone

Kotlin Android app using the Linphone SDK. Existing features are retained: SIP accounts, dial pad, incoming/outgoing call UI, phone/app contacts, call history, recordings, messages, settings, themes and wallpaper.

## Build with GitHub Actions (phone-only workflow)

1. Upload the contents of this project to your GitHub repository (keep the `.github/workflows/android-build.yml` file).
2. Open **Actions → Android APK** and run the workflow (or push to `main` / `master`).
3. Download the `my-voip-debug-apk` artifact and install the APK on a compatible Android phone.

The workflow uses JDK 17 and Gradle 8.7. The APK is currently configured for `arm64-v8a` only to reduce size. It is a debug-signed APK; it is suitable for testing, not Play Store release.

## Security and backup notes

- SIP account data and app-lock / backup-password preferences are migrated to AndroidX EncryptedSharedPreferences where Android Keystore is available. If Keystore initialization fails, the app falls back to legacy private preferences so the app can still start; that fallback is not encrypted.
- Daily backup requires a user-defined Backup Password. The full archive is encrypted with AES-256-GCM and includes SIP accounts, app contacts, favorites, settings, exported SIP call-history metadata, and WAV recordings. The latest seven full archives are retained locally.
- For scheduled cloud upload, choose a writable backup folder through Android's Storage Access Framework. If the Google Drive provider exposes a writable folder, WorkManager can upload the encrypted archive when network is available. Provider availability, background scheduling and battery restrictions can affect timing; this is not a Google Drive REST API integration.
- Call history is preserved as export metadata inside the encrypted archive and copied to the app's private `call_history_backup.json` on restore. Linphone does not expose a supported API here to reinsert imported call-log rows into its internal call-history database; restoring those rows into the native Recents list is not implemented.
- Recording should only be used after obtaining the other participant's consent and following local law.

## Important limitations before production use

- The app now raises a high-priority incoming-call notification with a full-screen call activity intent while the SIP Core process is alive. Reliable delivery after Android kills the process still requires provider-compatible push (typically FCM) and backend/provider configuration; this project does not contain those credentials or server endpoints.
- SIP registration, NAT traversal, one-way audio, Bluetooth routing, incoming notifications, recording and battery behavior must be tested with the actual SIP provider and target phones. Network changes trigger SIP registration refresh; STUN/ICE settings still depend on provider and network conditions.
- Daily encrypted archive upload uses the selected document-tree provider, not the Drive REST API. A successful upload must be verified on the user's Drive account. Push calling remains provider/backend dependent.
- APK size must be measured from the Actions artifact; the Linphone native SDK may make the final APK larger than the 20 MB preference.

## Current build configuration

- compileSdk / targetSdk: 34
- minSdk: 26 (Android 8.0)
- Java / Kotlin target: 17
- ABI: arm64-v8a
- Linphone SDK: pinned to 5.4.0 for reproducible dependency resolution
