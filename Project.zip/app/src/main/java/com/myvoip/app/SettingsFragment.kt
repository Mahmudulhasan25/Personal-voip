package com.myvoip.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    private lateinit var rows: LinearLayout

    private val wallpaperPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val ok = Wallpaper.save(requireContext(), uri)
            context?.toast(if (ok) "Wallpaper set hoyeche" else "Chhobi neya gelo na")
        }
        wallpaperDialog()
    }

    private val appWallpaperPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val ok = AppWallpaper.save(requireContext(), uri)
            context?.toast(if (ok) "Wallpaper set hoyeche" else "Chhobi neya gelo na")
        }
        appWallpaperDialog()
    }

    private fun appWallpaperDialog() {
        WallpaperUi.show(
            requireContext(), 0,
            onGallery = { appWallpaperPicker.launch("image/*") },
            onRemove = {
                AppWallpaper.remove(requireContext())
                requireActivity().recreate()
            },
            onApplied = { requireActivity().recreate() }
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        rows = view.findViewById(R.id.rows)
        view.findViewById<View>(R.id.btnBack).setOnClickListener {
            parentFragmentManager.popBackStack()
        }
        view.findViewById<android.widget.EditText>(R.id.etSettingsSearch)
            .addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                    query = s?.toString() ?: ""
                    reload()
                }

                override fun afterTextChanged(s: android.text.Editable?) {}
            })
    }

    override fun onStart() {
        super.onStart()
        reload()
    }

    private fun onOff(b: Boolean) = if (b) "ON" else "OFF"

    private val grey = 0xFF8A8F98.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private class Item(
        val group: Int,
        val icon: Int,
        val color: Int,
        val title: String,
        val subtitle: String?,
        val toggle: Boolean? = null,
        val onToggle: ((Boolean) -> Unit)? = null,
        val onClick: (() -> Unit)? = null
    )

    private var query = ""

    /** Group-er majhe patla dhushor patti (phone-er Settings-er moto). */
    private fun divider() {
        val v = View(requireContext())
        v.setBackgroundColor(0x22808080)
        rows.addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8)))
    }

    private fun addRow(item: Item) {
        val ctx = requireContext()
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(20), dp(14), dp(18), dp(14))
        val tv = android.util.TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        row.setBackgroundResource(tv.resourceId)

        // Rongin chokhuni icon
        val ic = ImageView(ctx)
        ic.setImageResource(item.icon)
        ic.setPadding(dp(9), dp(9), dp(9), dp(9))
        val bg = android.graphics.drawable.GradientDrawable()
        bg.cornerRadius = dp(11).toFloat()
        bg.setColor(item.color)
        ic.background = bg
        row.addView(ic, LinearLayout.LayoutParams(dp(42), dp(42)))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val colLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        colLp.marginStart = dp(16)
        colLp.marginEnd = dp(8)
        row.addView(col, colLp)

        val t = TextView(ctx)
        t.text = item.title
        t.textSize = 17f
        col.addView(t)
        if (!item.subtitle.isNullOrEmpty()) {
            val st = TextView(ctx)
            st.text = item.subtitle
            st.textSize = 13f
            st.setTextColor(grey)
            col.addView(st)
        }

        if (item.toggle != null) {
            val sw = SwitchCompat(ctx)
            sw.isChecked = item.toggle
            sw.setOnCheckedChangeListener { _, b -> item.onToggle?.invoke(b) }
            row.addView(sw)
            row.setOnClickListener { sw.toggle() }
        } else {
            val ch = ImageView(ctx)
            ch.setImageResource(R.drawable.ic_chevron)
            ch.setColorFilter(0xFFB0B5BD.toInt())
            row.addView(ch, LinearLayout.LayoutParams(dp(24), dp(24)))
            row.setOnClickListener { item.onClick?.invoke() }
        }
        rows.addView(row)
    }

    private fun themeName() = when (AppSettings.themeMode) {
        1 -> "Light"
        2 -> "Dark"
        3 -> "AMOLED black"
        else -> "System default"
    }

    private fun reload() {
        rows.removeAllViews()
        val ctx = requireContext()

        val items = listOf(
            Item(0, R.drawable.ic_volume, 0xFFFF9800.toInt(), "Loudspeaker by default",
                "Start every call on speaker", AppSettings.speakerDefault,
                { AppSettings.speakerDefault = it }),
            Item(0, R.drawable.ic_call, 0xFF7E57C2.toInt(), "Ringtone",
                "Ring on incoming calls", AppSettings.ringtoneOn,
                { AppSettings.ringtoneOn = it }),
            Item(0, R.drawable.ic_record, 0xFFE5484D.toInt(), "Recording reminder",
                "Warn me before recording a call", AppSettings.askRecordConsent,
                { AppSettings.askRecordConsent = it }),

            Item(1, R.drawable.ic_person, 0xFF1E88E5.toInt(), "SIP accounts",
                "Server, login, UDP / TCP / TLS", onClick = { open(AccountsFragment()) }),
            Item(1, R.drawable.ic_network, 0xFF16A36A.toInt(), "Network",
                "STUN ${onOff(AppSettings.useStun)} · ICE ${onOff(AppSettings.useIce)} · SRTP ${onOff(AppSettings.useSrtp)}",
                onClick = { networkDialog() }),

            Item(1, R.drawable.ic_call, 0xFF00ACC1.toInt(), "Speed dial & voicemail",
                "Hold a digit 1-9 on the dial pad", onClick = { speedDialDialog() }),
            Item(1, R.drawable.ic_call, 0xFFFB8C00.toInt(), "Call forwarding",
                if (Extras.forwardTo.isEmpty()) "Off" else "To ${Extras.forwardTo}",
                onClick = { forwardDialog() }),
            Item(1, R.drawable.ic_call_end, 0xFFE5484D.toInt(), "Blocked numbers",
                "${Extras.blocked().size} blocked", onClick = { blockDialog() }),

            Item(2, R.drawable.ic_theme, 0xFFEC407A.toInt(), "Theme", themeName(),
                onClick = { themeDialog() }),
            Item(2, R.drawable.ic_theme, 0xFF8E24AA.toInt(), "Theme color",
                accentNames[AppSettings.accent], onClick = { accentDialog() }),
            Item(2, R.drawable.ic_image, 0xFF3949AB.toInt(), "App wallpaper",
                if (AppWallpaper.exists(ctx)) "Custom image" else "Default",
                onClick = { appWallpaperDialog() }),
            Item(2, R.drawable.ic_image, 0xFF12B5A0.toInt(), "Call screen wallpaper",
                if (Wallpaper.exists(ctx)) "Custom image" else "Default",
                onClick = { wallpaperDialog() }),

            Item(3, R.drawable.ic_backup, 0xFF3F6EF5.toInt(), "Backup & restore",
                "File, Google Drive, daily auto backup", onClick = { open(BackupFragment()) }),
            Item(3, R.drawable.ic_lock, 0xFF5E35B1.toInt(), "App lock (PIN)",
                if (Extras.pin.isEmpty()) "Off" else "On", onClick = { pinDialog() }),
            Item(3, R.drawable.ic_backup, 0xFF2E7D32.toInt(), "Backup password",
                if (Extras.backupPassword.isEmpty()) "Required for daily encrypted backup" else "On (AES-256-GCM)",
                onClick = { backupPwDialog() }),
            Item(3, R.drawable.ic_lock, 0xFF7B7F8A.toInt(), "Privacy & data",
                "Clear history, recordings, accounts", onClick = { privacyDialog() }),
            Item(3, R.drawable.ic_notifications, 0xFFF59E0B.toInt(), "Notifications",
                "Open system settings", onClick = { notificationDialog() }),

            Item(4, R.drawable.ic_bug, 0xFF7B7F8A.toInt(), "Call debug info",
                "Call timeline (send a screenshot if there is a problem)",
                onClick = { debugDialog() }),
            Item(4, R.drawable.ic_info, 0xFF1E88E5.toInt(), "About", "My VoIP v1.0",
                onClick = { aboutDialog() })
        )

        val q = query.trim().lowercase()
        val shown = if (q.isEmpty()) items else items.filter {
            it.title.lowercase().contains(q) || (it.subtitle ?: "").lowercase().contains(q)
        }
        var lastGroup = -1
        for (item in shown) {
            if (q.isEmpty() && lastGroup != -1 && item.group != lastGroup) divider()
            lastGroup = item.group
            addRow(item)
        }
        if (shown.isEmpty()) {
            val e = TextView(ctx)
            e.text = "Kichu pawa jayni"
            e.setTextColor(grey)
            e.gravity = Gravity.CENTER
            e.setPadding(dp(20), dp(40), dp(20), dp(40))
            rows.addView(e)
        }
    }

    private fun open(f: Fragment) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.container, f)
            .addToBackStack(null)
            .commit()
    }

    // ---------- Theme ----------

    private fun inputDialog(title: String, hint: String, init: String, phone: Boolean,
                            password: Boolean = false, onOk: (String) -> Unit) {
        val ctx = requireContext()
        val et = android.widget.EditText(ctx)
        et.hint = hint
        et.setText(init)
        et.inputType = when {
            password && phone -> android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            password -> android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            phone -> android.text.InputType.TYPE_CLASS_PHONE
            else -> android.text.InputType.TYPE_CLASS_TEXT
        }
        et.setPadding(dp(20), dp(20), dp(20), dp(20))
        AlertDialog.Builder(ctx).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun forwardDialog() {
        inputDialog("Incoming call kon number-e jabe?", "Number (khali = bondho)", Extras.forwardTo, true) {
            Extras.forwardTo = it
            reload()
        }
    }

    private fun speedDialDialog() {
        val keys = listOf("1") + (2..9).map { it.toString() }
        val labels = keys.map { k ->
            val n = Extras.speed(k)
            (if (k == "1") "1 (Voicemail)" else k) + ": " + (if (n.isEmpty()) "—" else n)
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Speed dial")
            .setItems(labels.toTypedArray()) { _, i ->
                val k = keys[i]
                inputDialog("Digit $k-er number", "Number (khali = muche felo)", Extras.speed(k), true) {
                    Extras.setSpeed(k, it)
                    reload()
                }
            }
            .setNegativeButton("Close", null).show()
    }

    private fun blockDialog() {
        val list = Extras.blocked().toList().sorted()
        val b = AlertDialog.Builder(requireContext()).setTitle("Blocked numbers")
        if (list.isEmpty()) b.setMessage("Kono number block kora nei") else
            b.setItems(list.map { "$it  (unblock korte chapun)" }.toTypedArray()) { _, i ->
                Extras.unblock(list[i])
                reload()
            }
        b.setPositiveButton("Block a number") { _, _ ->
            inputDialog("Number block", "Number", "", true) {
                Extras.block(it)
                reload()
            }
        }
        b.setNegativeButton("Close", null).show()
    }

    private fun pinDialog() {
        if (Extras.pin.isEmpty()) {
            inputDialog("PIN thik korun (kom pokkhe 4 digit)", "PIN", "", true, true) {
                if (it.length < 4) context?.toast("Kom pokkhe 4 digit") else {
                    Extras.pin = it
                    reload()
                    context?.toast("App lock on")
                }
            }
        } else {
            AlertDialog.Builder(requireContext()).setTitle("App lock")
                .setItems(arrayOf("PIN bodlano", "Lock bondho korun")) { _, w ->
                    inputDialog("Ager PIN", "PIN", "", true, true) { old ->
                        if (old != Extras.pin) context?.toast("PIN thik na")
                        else if (w == 1) {
                            Extras.pin = ""
                            reload()
                        } else inputDialog("Notun PIN", "PIN", "", true, true) {
                            if (it.length >= 4) {
                                Extras.pin = it
                                reload()
                            } else context?.toast("Kom pokkhe 4 digit")
                        }
                    }
                }.setNegativeButton("Close", null).show()
        }
    }

    private fun backupPwDialog() {
        AlertDialog.Builder(requireContext()).setTitle("Backup password")
            .setMessage("Daily full backup, call history and recordings are encrypted with AES-256-GCM. Restore-er age ei password dite hobe. Password bhule gele backup khola jabe na.")
            .setPositiveButton("Set / change") { _, _ ->
                inputDialog("Backup password", "Password", "", false, true) {
                    Extras.backupPassword = it
                    reload()
                }
            }
            .setNeutralButton("Turn off") { _, _ ->
                Extras.backupPassword = ""
                reload()
            }
            .setNegativeButton("Close", null).show()
    }

    private val accentNames = arrayOf("Teal", "Blue", "Purple", "Pink", "Red", "Orange", "Green", "Indigo", "Slate")
    private val accentColors = intArrayOf(
        0xFF087F8C.toInt(), 0xFF1E88E5.toInt(), 0xFF7E57C2.toInt(), 0xFFEC407A.toInt(),
        0xFFE5484D.toInt(), 0xFFFB8C00.toInt(), 0xFF2E7D32.toInt(), 0xFF3F51B5.toInt(), 0xFF546E7A.toInt()
    )

    private fun accentDialog() {
        val names = Array<CharSequence>(accentNames.size) { i ->
            val sp = android.text.SpannableString("●   " + accentNames[i])
            sp.setSpan(android.text.style.ForegroundColorSpan(accentColors[i]), 0, 1, 0)
            sp.setSpan(android.text.style.RelativeSizeSpan(1.4f), 0, 1, 0)
            sp
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Theme color")
            .setSingleChoiceItems(names, AppSettings.accent) { d, which ->
                AppSettings.accent = which
                d.dismiss()
                requireActivity().recreate()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun themeDialog() {
        val names = arrayOf("System default", "Light", "Dark", "AMOLED black")
        AlertDialog.Builder(requireContext())
            .setTitle("Theme")
            .setSingleChoiceItems(names, AppSettings.themeMode) { d, which ->
                val prev = AppSettings.themeMode
                AppSettings.themeMode = which
                AppSettings.applyTheme()
                d.dismiss()
                if (which == 3 || prev == 3) requireActivity().recreate()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- Notifications ----------

    private fun notificationDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Notifications")
            .setMessage(
                "Call cholar shomoy je notification dekhay, ar app-er notification " +
                    "on/off phone-er system settings theke thik kora jay."
            )
            .setPositiveButton("Open system settings") { _, _ ->
                try {
                    val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, requireContext().packageName)
                    startActivity(i)
                } catch (e: Exception) {
                    context?.toast("Settings khola gelo na")
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- Privacy & Security ----------

    private fun privacyDialog() {
        val opts = arrayOf(
            "Record-er age shotorkobarta: ${onOff(AppSettings.askRecordConsent)} (change korte chapen)",
            "Call history muchun",
            "Shob recording muchun",
            "Shob account, contact ar favorite muchun"
        )
        AlertDialog.Builder(requireContext())
            .setTitle("Privacy & Security")
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> {
                        AppSettings.askRecordConsent = !AppSettings.askRecordConsent
                        reload()
                        context?.toast("Record-er age shotorkobarta ${onOff(AppSettings.askRecordConsent)}")
                    }
                    1 -> confirm("Shob call history muchben?") { SipEngine.clearLogs() }
                    2 -> confirm("Shob recording muchben?") {
                        SipEngine.recordingsDir().listFiles()?.forEach { it.delete() }
                    }
                    3 -> confirm("Shob account, contact ar favorite muchben? (Age backup nin)") {
                        Store.saveAccounts(emptyList())
                        Store.saveContacts(emptyList())
                        Store.setFavorites(emptySet())
                        Store.defaultAccountId = null
                        SipEngine.applyAccounts()
                    }
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun confirm(title: String, action: () -> Unit) {
        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setPositiveButton("Muchun") { _, _ ->
                action()
                context?.toast("Hoyeche")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Network (NAT) ----------

    private fun networkDialog() {
        val items = arrayOf(
            "STUN (public IP khuje ber kore)",
            "ICE (aro kora-kori path khuje)",
            "Audio encryption SRTP (server na dhorle call hobe na)"
        )
        val checked = booleanArrayOf(AppSettings.useStun, AppSettings.useIce, AppSettings.useSrtp)
        AlertDialog.Builder(requireContext())
            .setTitle("Network (NAT)")
            .setMultiChoiceItems(items, checked) { _, which, isChecked ->
                when (which) {
                    0 -> AppSettings.useStun = isChecked
                    1 -> AppSettings.useIce = isChecked
                    else -> AppSettings.useSrtp = isChecked
                }
            }
            .setPositiveButton("Apply") { _, _ ->
                SipEngine.applyAccounts()
                reload()
                context?.toast("Account abar register hocche")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Wallpaper ----------

    private fun wallpaperDialog() {
        WallpaperUi.show(
            requireContext(), 1,
            onGallery = { wallpaperPicker.launch("image/*") },
            onRemove = {
                Wallpaper.remove(requireContext())
                reload()
            },
            onApplied = { reload() }
        )
    }

    // ---------- Debug ----------

    private fun debugDialog() {
        val text = SipEngine.debugText()
        AlertDialog.Builder(requireContext())
            .setTitle("Call debug info")
            .setMessage(if (text.isEmpty()) "Ekhono kono call hoyni" else text)
            .setPositiveButton("Close", null)
            .setNeutralButton("Clear") { _, _ -> SipEngine.clearDebug() }
            .show()
    }

    // ---------- About ----------

    private fun aboutDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("My VoIP")
            .setMessage(
                "SIP softphone (Linphone SDK, GPLv3).\n\n" +
                    "Password app-er private storage-e save thake. " +
                    "Call record korar age onno pokkhoer shommoti nin."
            )
            .setPositiveButton("OK", null)
            .show()
    }
}
