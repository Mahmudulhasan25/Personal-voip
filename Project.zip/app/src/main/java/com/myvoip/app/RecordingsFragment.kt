package com.myvoip.app

import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingsFragment : Fragment(R.layout.fragment_list) {

    private lateinit var adapter: TwoLineAdapter
    private var files: List<File> = emptyList()
    private var player: MediaPlayer? = null
    private var playingFile: File? = null
    private var pendingSave: File? = null
    private var playSpeed = 1f

    // "Save to phone": user nije jayga (jemon Downloads) beche nen
    private val createDoc = registerForActivityResult(
        ActivityResultContracts.CreateDocument("audio/x-wav")
    ) { uri: Uri? ->
        val src = pendingSave
        pendingSave = null
        if (uri != null && src != null) copyTo(src, uri)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.findViewById<TextView>(R.id.tvTitle).text = "Recordings"
        view.findViewById<TextView>(R.id.tvEmpty).text =
            "Kono recording nei.\nCall cholar shomoy Record chapen."
        view.findViewById<Button>(R.id.btnAction).visibility = View.GONE

        val list = view.findViewById<ListView>(R.id.list)
        adapter = TwoLineAdapter(requireContext(), emptyList())
        list.adapter = adapter
        list.emptyView = view.findViewById(R.id.tvEmpty)

        list.setOnItemClickListener { _, _, pos, _ ->
            val f = files.getOrNull(pos) ?: return@setOnItemClickListener
            showOptions(f)
        }
    }

    override fun onStart() {
        super.onStart()
        reload()
    }

    override fun onStop() {
        super.onStop()
        stopPlayer()
    }

    private fun reload() {
        val all = SipEngine.recordingsDir().listFiles { f ->
            f.isFile && f.name.endsWith(".wav")
        }?.toList() ?: emptyList()

        // Khali (kichu record hoyni) file muche fele
        val real = ArrayList<File>()
        for (f in all) {
            if (f.length() < 100) f.delete() else real.add(f)
        }
        files = real.sortedByDescending { it.lastModified() }
        adapter.rows = files.map { f ->
            Row(titleOf(f), "${fmtDate(f.lastModified())} · ${f.length() / 1024} KB")
        }
        adapter.notifyDataSetChanged()
    }

    /** rec_20261113_153012_01712345678.wav -> "01712345678" */
    private fun titleOf(f: File): String {
        val parts = f.nameWithoutExtension.split("_", limit = 4)
        val num = if (parts.size >= 4) parts[3] else f.nameWithoutExtension
        val name = PhoneContacts.nameFor(num)
        return if (name != null) "$name ($num)" else num
    }

    private fun fmtDate(ms: Long): String =
        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("Asia/Dhaka")
        }.format(Date(ms))

    private fun showOptions(f: File) {
        val isPlaying = playingFile == f && player != null
        val opts = arrayOf(if (isPlaying) "Stop" else "Play", "Save to phone", "Delete", "Speed: ${playSpeed}x")
        AlertDialog.Builder(requireContext())
            .setTitle(titleOf(f))
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> if (isPlaying) stopPlayer() else play(f)
                    1 -> {
                        pendingSave = f
                        createDoc.launch(f.name)
                    }
                    3 -> {
                        val sp = arrayOf("0.5x", "1x", "1.5x", "2x")
                        val vals = floatArrayOf(0.5f, 1f, 1.5f, 2f)
                        AlertDialog.Builder(requireContext())
                            .setTitle("Playback speed")
                            .setItems(sp) { _, i ->
                                playSpeed = vals[i]
                                applySpeed()
                            }
                            .show()
                    }
                    2 -> AlertDialog.Builder(requireContext())
                        .setTitle("Ei recording muchben?")
                        .setPositiveButton("Muchun") { _, _ ->
                            if (playingFile == f) stopPlayer()
                            f.delete()
                            reload()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
            .show()
    }

    private fun play(f: File) {
        stopPlayer()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { stopPlayer() }
            mp.prepare()
            mp.start()
            player = mp
            applySpeed()
            playingFile = f
            context?.toast("Playing...")
        } catch (e: Exception) {
            context?.toast("Play kora gelo na: ${e.message}")
            stopPlayer()
        }
    }

    private fun applySpeed() {
        try {
            val mp = player ?: return
            if (playSpeed != 1f || mp.isPlaying) {
                mp.playbackParams = android.media.PlaybackParams().setSpeed(playSpeed)
            }
        } catch (_: Exception) {
        }
    }

    private fun stopPlayer() {
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        try {
            player?.release()
        } catch (_: Exception) {
        }
        player = null
        playingFile = null
    }

    private fun copyTo(src: File, uri: Uri) {
        try {
            requireContext().contentResolver.openOutputStream(uri)?.use { out ->
                src.inputStream().use { input -> input.copyTo(out) }
            }
            context?.toast("Phone-e save hoyeche")
        } catch (e: Exception) {
            context?.toast("Save hoyni: ${e.message}")
        }
    }
}
