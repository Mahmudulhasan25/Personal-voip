package com.myvoip.app

import android.app.Application
import android.os.Build
import android.os.Process
import android.os.SystemClock
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

class MyVoipApp : Application() {

    override fun onCreate() {
        super.onCreate()
        val t0 = SystemClock.elapsedRealtime()
        installCrashReporter()
        Store.init(this)
        AppSettings.init(this)
        MessageStore.init(this)
        Extras.init(this)
        AppSettings.applyTheme()
        val t1 = SystemClock.elapsedRealtime()
        SipEngine.init(this)
        val t2 = SystemClock.elapsedRealtime()
        SipEngine.logEvent(
            "STARTUP process->app ${t0 - Process.getStartElapsedRealtime()}ms, " +
                "store/settings ${t1 - t0}ms, linphone ${t2 - t1}ms"
        )
        // Bhari kaj gulo pechone, jate app jhotpot khole
        Thread {
            val c0 = SystemClock.elapsedRealtime()
            PhoneContacts.load(this)
            SipEngine.logEvent(
                "STARTUP contacts ${PhoneContacts.list.size} loaded in ${SystemClock.elapsedRealtime() - c0}ms"
            )
            BackupScheduler.apply(this)
        }.start()
    }

    /** Crash hole karon file-e likhe rakhe; porer bar app khulle MainActivity screen-e dekhay. */
    private fun installCrashReporter() {
        val file = File(filesDir, "crash.txt")
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                file.writeText(
                    "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), " +
                        "${Build.MANUFACTURER} ${Build.MODEL}\n\n$sw"
                )
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, throwable)
        }
    }
}
