package com.myvoip.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BackupFragment : Fragment(R.layout.fragment_backup) {

    private lateinit var tvAutoStatus: TextView

    // Backup file save: user nije jayga (jemon Google Drive) beche nen
    private val createDoc = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) writeBackup(uri)
    }

    private val chooseDriveFolder = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                requireContext().contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                AppSettings.driveTreeUri = uri.toString()
                context?.toast("Backup folder selected. Daily cloud backup is ready.")
                BackupScheduler.apply(requireContext())
            } catch (e: Exception) {
                context?.toast("Folder permission save hoyni: ${e.message}")
            }
        }
        updateStatus()
    }

    // Restore file nirbachon
    private val openDoc = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) readBackup(uri)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        tvAutoStatus = view.findViewById(R.id.tvAutoStatus)

        view.findViewById<Button>(R.id.btnDriveFolder).setOnClickListener {
            chooseDriveFolder.launch(null)
        }

        view.findViewById<Button>(R.id.btnBackup).setOnClickListener {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            createDoc.launch("myvoip_backup_$stamp.json")
        }

        view.findViewById<Button>(R.id.btnRestore).setOnClickListener {
            confirmRestore { openDoc.launch(arrayOf("*/*")) }
        }

        val chk = view.findViewById<CheckBox>(R.id.chkAuto)
        chk.isChecked = AppSettings.autoBackup
        chk.setOnCheckedChangeListener { _, checked ->
            AppSettings.autoBackup = checked
            context?.let { BackupScheduler.apply(it) }
            updateStatus()
        }

        view.findViewById<Button>(R.id.btnAutoNow).setOnClickListener {
            try {
                val ctx = requireContext()
                Backup.autoBackup(ctx)
                val archive = Backup.createFullArchive(ctx)
                val uploaded = if (AppSettings.driveTreeUri.isNotBlank())
                    Backup.uploadLatestToDrive(ctx, archive) else false
                context?.toast(if (uploaded) "Encrypted full backup + Drive upload hoyeche" else "Encrypted full backup phone-e hoyeche. Drive upload-er jonno folder select ebong Backup Password dorkar.")
            } catch (e: Exception) {
                context?.toast("Backup hoyni: ${e.message}")
            }
            updateStatus()
        }

        view.findViewById<Button>(R.id.btnRestoreAuto).setOnClickListener {
            val f = Backup.latestFullArchive(requireContext())
            if (f == null) {
                context?.toast("Kono encrypted full backup nei")
            } else {
                confirmRestore {
                    val err = Backup.restoreFullArchive(requireContext(), f)
                    context?.toast(err ?: "Full backup restore hoyeche")
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        updateStatus()
    }

    private fun updateStatus() {
        val ctx: Context = context ?: return
        val last = AppSettings.lastAutoBackup
        val lastText = if (last == 0L) {
            "Ekhono auto-backup hoyni"
        } else {
            "Shesh auto-backup: " +
                SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("Asia/Dhaka")
                }.format(Date(last))
        }
        val state = if (AppSettings.autoBackup) "Chalu" else "Bondho"
        val files = Backup.backupDir(ctx).listFiles()?.size ?: 0
        val cloud = if (Extras.backupPassword.isBlank()) "Set Backup Password to enable encrypted daily backup" else
            if (AppSettings.driveTreeUri.isBlank()) "Drive folder not selected" else
            if (AppSettings.lastCloudBackup == 0L) "Drive selected · upload pending" else "Drive synced: " +
                SimpleDateFormat("dd MMM, hh:mm a", Locale.US).format(Date(AppSettings.lastCloudBackup))
        tvAutoStatus.text = "$state · $lastText · $files files\n$cloud"
    }

    private fun confirmRestore(action: () -> Unit) {
        AlertDialog.Builder(requireContext())
            .setTitle("Restore korben?")
            .setMessage("Ekhon-kar SIP account, contact ar settings backup-er tothyo diye bodle jabe.")
            .setPositiveButton("Restore") { _, _ -> action() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun writeBackup(uri: Uri) {
        val ctx = context ?: return
        try {
            ctx.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(Backup.export().toByteArray())
            }
            ctx.toast("Backup save hoyeche")
        } catch (e: Exception) {
            ctx.toast("Backup hoyni: ${e.message}")
        }
    }

    private fun readBackup(uri: Uri) {
        val ctx = context ?: return
        try {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes == null) {
                ctx.toast("File pora gelo na")
                return
            }
            val temp = java.io.File(ctx.cacheDir, "selected_myvoip_backup.enc")
            val isFull = bytes.size >= 7 && String(bytes.copyOfRange(0, 7), Charsets.US_ASCII) == "MYVOIP1"
            val err = if (isFull) {
                temp.writeBytes(bytes)
                Backup.restoreFullArchive(ctx, temp)
            } else {
                Backup.restore(String(bytes, Charsets.UTF_8))
            }
            temp.delete()
            ctx.toast(err ?: "Restore hoyeche")
        } catch (e: Exception) {
            ctx.toast("Restore hoyni: ${e.message}")
        }
    }
}
