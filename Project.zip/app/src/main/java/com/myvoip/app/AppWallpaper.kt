package com.myvoip.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/** App-er mul screen-er (Recents, Contacts, Settings...) wallpaper. */
object AppWallpaper {
    private fun file(ctx: Context) = File(ctx.filesDir, "app_wallpaper.jpg")

    fun exists(ctx: Context): Boolean = file(ctx).exists()

    /** Screen-er motoi chhoto kore pore (boro chhobi decode korle dhimey hoy). */
    fun load(ctx: Context): Bitmap? {
        if (!exists(ctx)) return null
        return try {
            val path = file(ctx).absolutePath
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, b)
            val target = maxOf(ctx.resources.displayMetrics.heightPixels, 1280)
            var sample = 1
            while (maxOf(b.outWidth, b.outHeight) / (sample * 2) >= target) sample *= 2
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Throwable) {
            null
        }
    }

    fun remove(ctx: Context) {
        file(ctx).delete()
    }

    fun save(ctx: Context, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return false
            file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }
}
