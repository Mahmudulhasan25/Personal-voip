package com.myvoip.app

import android.content.Context
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

fun Context.toast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

fun fmtDuration(totalSeconds: Int): String {
    val s = if (totalSeconds < 0) 0 else totalSeconds
    return "%d:%02d".format(s / 60, s % 60)
}

/** List-er ekta row: upore title, niche chhoto subtitle. */
class Row(val title: CharSequence, val subtitle: String)

class TwoLineAdapter(private val ctx: Context, var rows: List<Row>) : BaseAdapter() {
    override fun getCount(): Int = rows.size
    override fun getItem(position: Int): Any = rows[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val v = convertView
            ?: LayoutInflater.from(ctx).inflate(android.R.layout.simple_list_item_2, parent, false)
        val t1 = v.findViewById<TextView>(android.R.id.text1)
        val t2 = v.findViewById<TextView>(android.R.id.text2)
        t1.text = rows[position].title
        t1.textSize = 19f // naam ektu boro
        t2.text = rows[position].subtitle
        t2.textSize = 13.5f // number ar bibaron choto
        t2.alpha = 0.55f // halka jhapsha
        return v
    }
}

class Field(
    val hint: String,
    val initial: String = "",
    val password: Boolean = false,
    val phone: Boolean = false
)

/**
 * Chhoto form dialog: kichu text field + (chaile) ekta dropdown.
 * onOk-e field-er lekha (trim kora) ar dropdown-er selected position ashe.
 */
fun formDialog(
    ctx: Context,
    title: String,
    fields: List<Field>,
    choices: List<String> = emptyList(),
    choiceIndex: Int = 0,
    onOk: (List<String>, Int) -> Unit
) {
    val pad = (16 * ctx.resources.displayMetrics.density).toInt()
    val box = LinearLayout(ctx)
    box.orientation = LinearLayout.VERTICAL
    box.setPadding(pad, pad / 2, pad, 0)

    val edits = ArrayList<EditText>()
    for (f in fields) {
        val et = EditText(ctx)
        et.hint = f.hint
        et.setText(f.initial)
        et.setSingleLine()
        et.inputType = when {
            f.password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            f.phone -> InputType.TYPE_CLASS_PHONE
            else -> InputType.TYPE_CLASS_TEXT
        }
        box.addView(et)
        edits.add(et)
    }

    var spinner: Spinner? = null
    if (choices.isNotEmpty()) {
        val sp = Spinner(ctx)
        sp.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, choices)
        sp.setSelection(choiceIndex)
        box.addView(sp)
        spinner = sp
    }

    val scroll = ScrollView(ctx)
    scroll.addView(box)

    AlertDialog.Builder(ctx)
        .setTitle(title)
        .setView(scroll)
        .setPositiveButton("Save") { _, _ ->
            onOk(edits.map { it.text.toString().trim() }, spinner?.selectedItemPosition ?: 0)
        }
        .setNegativeButton("Cancel", null)
        .show()
}

/** Bangladesh shomoy (Asia/Dhaka), AM/PM shoho. */
fun fmtDhaka(ms: Long, pattern: String = "dd MMM, hh:mm a"): String =
    java.text.SimpleDateFormat(pattern, java.util.Locale.US).apply {
        timeZone = java.util.TimeZone.getTimeZone("Asia/Dhaka")
    }.format(java.util.Date(ms))

/** Naam boro, tar pashe number chhoto kintu porar moto spashto — ek-i line-e. */
fun nameWithNumber(ctx: android.content.Context, name: String, number: String): CharSequence {
    val tv = android.util.TypedValue()
    ctx.theme.resolveAttribute(android.R.attr.textColorPrimary, tv, true)
    val base = try {
        ctx.getColor(tv.resourceId)
    } catch (_: Exception) {
        0xFF808080.toInt()
    }
    // theme-er lekhar rong, ~78% opaque: halka kintu wallpaper-er upor-o dekha jay
    val numColor = (base and 0x00FFFFFF) or (0xC7 shl 24)
    val sb = android.text.SpannableStringBuilder(name)
    val start = sb.length
    sb.append("  ").append(number)
    sb.setSpan(android.text.style.RelativeSizeSpan(0.8f), start, sb.length, 0)
    sb.setSpan(android.text.style.ForegroundColorSpan(numColor), start, sb.length, 0)
    return sb
}
