package com.myvoip.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat

object WallpaperFx {
    /** Shosta blur: chhoto kore abar boro kore. pct 0..100 */
    fun blur(src: Bitmap, pct: Int): Bitmap {
        if (pct <= 0) return src
        return try {
            val f = 1f + pct / 100f * 22f
            val w = maxOf(8, (src.width / f).toInt())
            val h = maxOf(8, (src.height / f).toInt())
            val small = Bitmap.createScaledBitmap(src, w, h, true)
            Bitmap.createScaledBitmap(small, src.width, src.height, true)
        } catch (e: Throwable) {
            src
        }
    }
}

/**
 * Wallpaper Mode sheet: On/Off, preview, Gallery, Dim, Blur, (Cards), Remove, Apply.
 * target 0 = App wallpaper (Cards slider thake), 1 = Call screen wallpaper.
 */
object WallpaperUi {
    fun show(
        ctx: Context,
        target: Int,
        onGallery: () -> Unit,
        onRemove: () -> Unit,
        onApplied: () -> Unit
    ) {
        val k = if (target == 0) "app_wp" else "call_wp"
        val exists = if (target == 0) AppWallpaper.exists(ctx) else Wallpaper.exists(ctx)
        val full = if (target == 0) AppWallpaper.load(ctx) else Wallpaper.load(ctx)
        // Preview-er jonno chhoto version (druto blur-er jonno)
        val small = full?.let {
            val s = 480f / maxOf(it.width, it.height)
            if (s < 1f) Bitmap.createScaledBitmap(it, (it.width * s).toInt(), (it.height * s).toInt(), true) else it
        }

        var on = AppSettings.getBool("${k}_on", true)
        var dim = AppSettings.getInt("${k}_dim", if (target == 0) 0 else 40)
        var blur = AppSettings.getInt("${k}_blur", 0)
        var cards = AppSettings.getInt("${k}_cards", 65)

        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(8), dp(20), dp(8))

        // ---- On/Off ----
        val top = LinearLayout(ctx)
        top.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val t1 = TextView(ctx)
        t1.text = "Wallpaper On/Off"
        t1.textSize = 17f
        t1.setTypeface(null, android.graphics.Typeface.BOLD)
        val t2 = TextView(ctx)
        t2.text = "Delete na kore wallpaper bondho rakhun"
        t2.textSize = 13f
        t2.alpha = 0.6f
        col.addView(t1)
        col.addView(t2)
        top.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = SwitchCompat(ctx)
        sw.isChecked = on
        top.addView(sw)
        root.addView(top)

        // ---- Preview ----
        val preview = ImageView(ctx)
        preview.scaleType = ImageView.ScaleType.CENTER_CROP
        val pbg = GradientDrawable()
        pbg.cornerRadius = dp(18).toFloat()
        pbg.setColor(0x33808080)
        preview.background = pbg
        preview.outlineProvider = ViewOutlineProvider.BACKGROUND
        preview.clipToOutline = true
        val plp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190))
        plp.topMargin = dp(14)
        root.addView(preview, plp)

        fun refresh() {
            if (small == null) {
                preview.setImageDrawable(null)
                return
            }
            preview.setImageBitmap(WallpaperFx.blur(small, blur))
            preview.colorFilter = PorterDuffColorFilter(
                Color.argb(dim * 255 / 100, 0, 0, 0), PorterDuff.Mode.SRC_ATOP
            )
            preview.alpha = if (on) 1f else 0.35f
        }
        sw.setOnCheckedChangeListener { _, b ->
            on = b
            refresh()
        }

        // ---- Gallery ----
        val gal = Button(ctx)
        gal.text = if (exists) "Gallery (chhobi bodlan)" else "Gallery (chhobi bachai)"
        val glp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        glp.topMargin = dp(10)
        root.addView(gal, glp)

        // ---- Sliders ----
        fun slider(label: String, init: Int, onChange: (Int) -> Unit) {
            val row = LinearLayout(ctx)
            row.gravity = Gravity.CENTER_VERTICAL
            val name = TextView(ctx)
            name.text = label
            name.textSize = 15f
            row.addView(name, LinearLayout.LayoutParams(dp(60), ViewGroup.LayoutParams.WRAP_CONTENT))
            val sb = SeekBar(ctx)
            sb.max = 100
            sb.progress = init
            row.addView(sb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val v = TextView(ctx)
            v.text = "$init%"
            v.gravity = Gravity.END
            row.addView(v, LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.WRAP_CONTENT))
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    v.text = "$p%"
                    onChange(p)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            root.addView(row, lp)
        }
        slider("Dim", dim) { dim = it; refresh() }
        slider("Blur", blur) { blur = it; refresh() }
        if (target == 0) slider("Cards", cards) { cards = it }

        refresh()

        val sv = ScrollView(ctx)
        sv.addView(root)

        val b = AlertDialog.Builder(ctx)
            .setTitle(if (target == 0) "App wallpaper mode" else "Call screen wallpaper mode")
            .setView(sv)
            .setPositiveButton("Apply") { _, _ ->
                AppSettings.putBool("${k}_on", on)
                AppSettings.putInt("${k}_dim", dim)
                AppSettings.putInt("${k}_blur", blur)
                if (target == 0) AppSettings.putInt("${k}_cards", cards)
                onApplied()
            }
            .setNegativeButton("Cancel", null)
        if (exists) b.setNeutralButton("Remove") { _, _ -> onRemove() }
        val dlg = b.create()
        gal.setOnClickListener {
            dlg.dismiss()
            onGallery()
        }
        dlg.show()
    }
}
