package com.myvoip.app

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.documentfile.provider.DocumentFile
import android.net.Uri
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.zip.ZipInputStream
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherOutputStream
import javax.crypto.CipherInputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Backup-e ja thake: SIP account (password shoho), contact, favorite, settings.
 * Ja thake na: call history (Linphone-er nijossho database), recording file (boro).
 */
object Backup {

    fun toJson(): String {
        val root = JSONObject()
        root.put("app", "myvoip")
        root.put("version", 1)
        root.put("created", System.currentTimeMillis())

        val accounts = JSONArray()
        Store.accounts().forEach { accounts.put(it.toJson()) }
        root.put("accounts", accounts)

        val contacts = JSONArray()
        Store.contacts().forEach { contacts.put(it.toJson()) }
        root.put("contacts", contacts)

        val favs = JSONArray()
        Store.favorites().forEach { favs.put(it) }
        root.put("favorites", favs)

        root.put("defaultAccount", Store.defaultAccountId ?: "")

        val s = JSONObject()
        s.put("speakerDefault", AppSettings.speakerDefault)
        s.put("ringtoneOn", AppSettings.ringtoneOn)
        s.put("askRecordConsent", AppSettings.askRecordConsent)
        s.put("autoBackup", AppSettings.autoBackup)
        root.put("settings", s)

        // SIP call history export (Linphone keeps this in its own database).
        val history = JSONArray()
        try {
            SipEngine.callLogs().forEach { log ->
                val item = JSONObject()
                item.put("remote", log.remoteAddress?.asStringUriOnly() ?: "")
                item.put("direction", log.dir.name)
                item.put("status", log.status.name)
                item.put("startDate", log.startDate)
                item.put("durationSeconds", log.duration)
                history.put(item)
            }
        } catch (_: Exception) { }
        root.put("callHistory", history)
        return root.toString(2)
    }

    private fun aesKey(pw: String, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val k = f.generateSecret(PBEKeySpec(pw.toCharArray(), salt, 120000, 256)).encoded
        return SecretKeySpec(k, "AES")
    }

    /** Backup password thakle AES-256 diye lock kore file-er lekha baniye dey. */
    fun export(): String {
        val plain = toJson()
        val pw = Extras.backupPassword
        require(pw.isNotBlank()) { "Backup Password set korun, nahole SIP password unencrypted thakbe" }
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, aesKey(pw, salt), GCMParameterSpec(128, iv))
        val enc = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        val b64 = { b: ByteArray -> android.util.Base64.encodeToString(b, android.util.Base64.NO_WRAP) }
        return JSONObject().put("app", "myvoip-enc").put("salt", b64(salt))
            .put("iv", b64(iv)).put("data", b64(enc)).toString()
    }

    /** Restore kore. Error hole error-er lekha, shofol hole null. */
    fun restore(input: String): String? {
        var json = input
        try {
            val head = JSONObject(input)
            if (head.optString("app") == "myvoip-enc") {
                val pw = Extras.backupPassword
                if (pw.isEmpty()) return "Eta password deya backup. Age Settings -> Backup password-e oi password dien"
                val d = { k: String -> android.util.Base64.decode(head.getString(k), android.util.Base64.NO_WRAP) }
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, aesKey(pw, d("salt")), GCMParameterSpec(128, d("iv")))
                json = String(c.doFinal(d("data")), Charsets.UTF_8)
            }
        } catch (e: Exception) {
            return "Password bhul ba file nosto"
        }
        try {
            val root = JSONObject(json)
            if (root.optString("app") != "myvoip") return "Eta My VoIP-er backup file na"

            val accArr = root.optJSONArray("accounts") ?: JSONArray()
            val accounts = (0 until accArr.length()).map { SipAccount.fromJson(accArr.getJSONObject(it)) }

            val conArr = root.optJSONArray("contacts") ?: JSONArray()
            val contacts = (0 until conArr.length()).map { Contact.fromJson(conArr.getJSONObject(it)) }

            val favArr = root.optJSONArray("favorites") ?: JSONArray()
            val favs = (0 until favArr.length()).map { favArr.getString(it) }.toSet()

            Store.saveAccounts(accounts)
            Store.saveContacts(contacts)
            Store.setFavorites(favs)
            val def = root.optString("defaultAccount")
            Store.defaultAccountId = if (def.isEmpty()) accounts.firstOrNull()?.id else def

            val s = root.optJSONObject("settings")
            if (s != null) {
                AppSettings.speakerDefault = s.optBoolean("speakerDefault", false)
                AppSettings.ringtoneOn = s.optBoolean("ringtoneOn", true)
                AppSettings.askRecordConsent = s.optBoolean("askRecordConsent", true)
                AppSettings.autoBackup = s.optBoolean("autoBackup", true)
            }
            SipEngine.applyAccounts()
            return null
        } catch (e: Exception) {
            return "Restore hoyni: ${e.message}"
        }
    }

    // ---------- Automatic backup (app-er bhitore, protidin) ----------

    fun backupDir(ctx: Context): File {
        val dir = File(ctx.filesDir, "backups")
        dir.mkdirs()
        return dir
    }

    fun autoBackup(ctx: Context): File {
        require(Extras.backupPassword.isNotBlank()) { "Daily backup-er jonno age Backup Password set korun" }
        val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val file = File(backupDir(ctx), "backup_$stamp.json")
        file.writeText(export())
        AppSettings.lastAutoBackup = System.currentTimeMillis()

        // Shudhu shesh 7 ta rakhe
        val all = backupDir(ctx).listFiles { f -> f.name.endsWith(".json") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
        all.drop(7).forEach { it.delete() }
        return file
    }

    fun latestAutoBackup(ctx: Context): File? =
        backupDir(ctx).listFiles { f -> f.name.endsWith(".json") }
            ?.maxByOrNull { it.lastModified() }

    /** Daily complete archive: account/config JSON + call history + WAV recordings. */
    fun createFullArchive(ctx: Context): File {
        val password = Extras.backupPassword
        require(password.isNotBlank()) { "Full backup-er jonno age Backup Password set korun" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val plainZip = File(backupDir(ctx), "myvoip_full_$stamp.tmp")
        ZipOutputStream(plainZip.outputStream().buffered()).use { zip ->
            zip.putNextEntry(ZipEntry("myvoip_backup.json"))
            zip.write(toJson().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            val recDir = SipEngine.recordingsDir()
            recDir.listFiles { f -> f.isFile && f.extension.equals("wav", true) }
                ?.forEach { file ->
                    zip.putNextEntry(ZipEntry("recordings/${file.name}"))
                    file.inputStream().buffered().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
        }
        val encrypted = File(backupDir(ctx), "myvoip_full_$stamp.zip.enc")
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, aesKey(password, salt), GCMParameterSpec(128, iv))
        encrypted.outputStream().buffered().use { raw ->
            raw.write("MYVOIP1".toByteArray(Charsets.US_ASCII))
            raw.write(salt)
            raw.write(iv)
            CipherOutputStream(raw, cipher).use { crypt ->
                plainZip.inputStream().buffered().use { it.copyTo(crypt) }
            }
        }
        plainZip.delete()
        val archives = backupDir(ctx).listFiles { f -> f.name.startsWith("myvoip_full_") && f.name.endsWith(".zip.enc") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
        archives.drop(7).forEach { it.delete() }
        return encrypted
    }

    fun latestFullArchive(ctx: Context): File? =
        backupDir(ctx).listFiles { f -> f.name.startsWith("myvoip_full_") && f.name.endsWith(".zip.enc") }
            ?.maxByOrNull { it.lastModified() }

    /** Decrypt full archive, restore app data and copy WAV files back. */
    fun restoreFullArchive(ctx: Context, archive: File): String? {
        return try {
            val password = Extras.backupPassword
            if (password.isBlank()) return "Age Settings-e Backup Password din"
            archive.inputStream().buffered().use { raw ->
                val magic = ByteArray(7)
                if (raw.read(magic) != 7 || String(magic, Charsets.US_ASCII) != "MYVOIP1")
                    return "Eta My VoIP encrypted full backup na"
                val salt = ByteArray(16).also { raw.readFullyCompat(it) }
                val iv = ByteArray(12).also { raw.readFullyCompat(it) }
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, aesKey(password, salt), GCMParameterSpec(128, iv))
                var config: String? = null
                val recordDir = SipEngine.recordingsDir()
                ZipInputStream(CipherInputStream(raw, cipher)).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        if (!entry.isDirectory && entry.name == "myvoip_backup.json") {
                            val buffer = java.io.ByteArrayOutputStream()
                            zip.copyTo(buffer)
                            config = buffer.toString(Charsets.UTF_8.name())
                        } else if (!entry.isDirectory && entry.name.startsWith("recordings/")) {
                            val safeName = File(entry.name).name
                            if (safeName.endsWith(".wav", true)) {
                                File(recordDir, safeName).outputStream().buffered().use { zip.copyTo(it) }
                            }
                        }
                        zip.closeEntry()
                    }
                }
                val json = config ?: return "Backup file-e app data paoa jayni"
                val history = JSONObject(json).optJSONArray("callHistory") ?: JSONArray()
                File(ctx.filesDir, "call_history_backup.json").writeText(history.toString(2))
                restore(json)
            }
        } catch (e: Exception) {
            "Full backup restore hoyni: ${e.message}"
        }
    }

    private fun java.io.InputStream.readFullyCompat(target: ByteArray) {
        var offset = 0
        while (offset < target.size) {
            val count = read(target, offset, target.size - offset)
            if (count < 0) throw java.io.EOFException("Backup header incomplete")
            offset += count
        }
    }

    /** Upload into a folder selected once by the user through Android's document picker. */
    fun uploadLatestToDrive(ctx: Context, archive: File): Boolean {
        val raw = AppSettings.driveTreeUri
        if (raw.isBlank()) return false
        if (Extras.backupPassword.isBlank()) return false
        val tree = DocumentFile.fromTreeUri(ctx, Uri.parse(raw)) ?: return false
        if (!tree.canWrite()) return false
        val name = archive.name
        tree.findFile(name)?.delete()
        val target = tree.createFile("application/octet-stream", name) ?: return false
        ctx.contentResolver.openOutputStream(target.uri, "w")?.use { output ->
            archive.inputStream().buffered().use { it.copyTo(output) }
        } ?: return false
        AppSettings.lastCloudBackup = System.currentTimeMillis()
        return true
    }
}

class BackupWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            Backup.autoBackup(applicationContext)
            val full = Backup.createFullArchive(applicationContext)
            val uri = AppSettings.driveTreeUri
            if (uri.isNotBlank() && !Backup.uploadLatestToDrive(applicationContext, full)) {
                return Result.retry()
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

object BackupScheduler {
    fun apply(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        if (AppSettings.autoBackup) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val req = PeriodicWorkRequestBuilder<BackupWorker>(24, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()
            wm.enqueueUniquePeriodicWork("daily_backup", ExistingPeriodicWorkPolicy.UPDATE, req)
        } else {
            wm.cancelUniqueWork("daily_backup")
        }
    }
}
