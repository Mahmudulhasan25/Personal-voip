package com.myvoip.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

/** Ekta message. via = "SIP" ba "SMS". */
class Msg(
    val peer: String,
    val text: String,
    val time: Long,
    val outgoing: Boolean,
    val via: String,
    var status: String
)

/** Shob message (SIP + SMS) ei app-er nijer storage-e thake. */
object MessageStore {
    private lateinit var prefs: SharedPreferences
    private val list = ArrayList<Msg>()

    /** Phone-er SMS inbox (READ_SMS permission thakle). null = poRha hoyni. */
    @Volatile
    private var phoneSms: List<Msg>? = null
    private val main = Handler(Looper.getMainLooper())

    /** Screen refresh korar jonno. Fragment onStart-e set kore, onStop-e null kore. */
    @Volatile
    var onChange: (() -> Unit)? = null

    private var loaded = false

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("myvoip_messages", Context.MODE_PRIVATE)
    }

    /** Prothom bar dorkar hole tokhon pore (startup-e na). */
    @Synchronized
    private fun ensureLoaded() {
        if (loaded) return
        loaded = true
        try {
            val arr = JSONArray(prefs.getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Msg(
                        o.getString("peer"), o.getString("text"), o.getLong("time"),
                        o.getBoolean("out"), o.getString("via"), o.getString("status")
                    )
                )
            }
        } catch (_: Exception) {
        }
    }

    /** Number theke ekta key (shesh 10 digit), jate +880 ar 0 shoho ek-i conversation hoy. */
    fun keyOf(number: String): String {
        val d = number.filter { it.isDigit() }
        return if (d.length > 10) d.takeLast(10) else d
    }

    @Synchronized
    fun add(m: Msg) {
        ensureLoaded()
        list.add(m)
        while (list.size > 600) list.removeAt(0)
        save()
        changed()
    }

    @Synchronized
    fun setStatus(m: Msg, status: String) {
        m.status = status
        save()
        changed()
    }

    /** Shob message: SIP + (permission thakle) phone-er SMS. Nijer pathano SMS phone-er sent-e-i ache, tai duplicate bad. */
    private fun all(): List<Msg> {
        ensureLoaded()
        val p = phoneSms
        return if (p == null) list else list.filter { it.via != "SMS" } + p
    }

    fun hasSmsPermission(ctx: Context): Boolean =
        androidx.core.content.ContextCompat.checkSelfPermission(
            ctx, android.Manifest.permission.READ_SMS
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

    /** Phone-er SMS pore (background thread-e dakun). */
    fun loadPhoneSms(ctx: Context) {
        if (!hasSmsPermission(ctx)) return
        val out = ArrayList<Msg>()
        try {
            ctx.contentResolver.query(
                android.net.Uri.parse("content://sms"),
                arrayOf("address", "body", "date", "type"),
                null, null, "date DESC LIMIT 800"
            )?.use { c ->
                while (c.moveToNext()) {
                    val addr = c.getString(0) ?: continue
                    val type = c.getInt(3)
                    if (type != 1 && type != 2) continue
                    out.add(
                        Msg(
                            addr, c.getString(1) ?: "", c.getLong(2), type == 2, "SMS",
                            if (type == 2) "Sent" else "Received"
                        )
                    )
                }
            }
            phoneSms = out
            changed()
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun forPeer(key: String): List<Msg> = all().filter { keyOf(it.peer) == key }.sortedBy { it.time }

    /** Prottek conversation-er shesh message, notun age. */
    @Synchronized
    fun conversations(): List<Msg> {
        val last = LinkedHashMap<String, Msg>()
        for (m in all().sortedBy { it.time }) last[keyOf(m.peer)] = m
        return last.values.sortedByDescending { it.time }
    }

    @Synchronized
    fun deleteConversation(key: String) {
        ensureLoaded()
        list.removeAll { keyOf(it.peer) == key }
        save()
        changed()
    }

    private fun save() {
        ensureLoaded()
        val arr = JSONArray()
        for (m in list) {
            val o = JSONObject()
            o.put("peer", m.peer)
            o.put("text", m.text)
            o.put("time", m.time)
            o.put("out", m.outgoing)
            o.put("via", m.via)
            o.put("status", m.status)
            arr.put(o)
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    private fun changed() {
        main.post { onChange?.invoke() }
    }
}
