package com.myvoip.app

import android.content.Context
import android.content.SharedPreferences

/** Notun chhoto feature-er data: block list, speed dial, voicemail, App Lock PIN, backup password. */
object Extras {
    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        val legacy = ctx.getSharedPreferences("myvoip_extra", Context.MODE_PRIVATE)
        prefs = try {
            val masterKey = androidx.security.crypto.MasterKey.Builder(ctx)
                .setKeyScheme(androidx.security.crypto.MasterKey.KeyScheme.AES256_GCM)
                .build()
            val secure = androidx.security.crypto.EncryptedSharedPreferences.create(
                ctx,
                "myvoip_extra_secure",
                masterKey,
                androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            if (secure.all.isEmpty() && legacy.all.isNotEmpty()) {
                val edit = secure.edit()
                legacy.all.forEach { (key, value) ->
                    when (value) {
                        is String -> edit.putString(key, value)
                        is Boolean -> edit.putBoolean(key, value)
                        is Int -> edit.putInt(key, value)
                        is Long -> edit.putLong(key, value)
                        is Float -> edit.putFloat(key, value)
                        is Set<*> -> edit.putStringSet(key, value.filterIsInstance<String>().toSet())
                    }
                }
                edit.commit()
                legacy.edit().clear().apply()
            }
            secure
        } catch (_: Exception) {
            legacy
        }
    }

    fun key(number: String): String {
        val d = number.filter { it.isDigit() }
        return if (d.length > 10) d.takeLast(10) else d
    }

    // ---- Block list ----
    fun blocked(): Set<String> = prefs.getStringSet("blocked", emptySet()) ?: emptySet()

    fun isBlocked(number: String): Boolean {
        val k = key(number)
        return k.isNotEmpty() && k in blocked()
    }

    fun block(number: String) {
        val k = key(number)
        if (k.isEmpty()) return
        prefs.edit().putStringSet("blocked", HashSet(blocked()) + k).apply()
    }

    fun unblock(k: String) {
        prefs.edit().putStringSet("blocked", HashSet(blocked()) - k).apply()
    }

    // ---- Speed dial (1-9) ----
    fun speed(digit: String): String = prefs.getString("speed_$digit", "") ?: ""

    fun setSpeed(digit: String, number: String) {
        prefs.edit().putString("speed_$digit", number.trim()).apply()
    }

    // ---- Call forwarding (incoming call onno number-e pathano) ----
    var forwardTo: String
        get() = prefs.getString("forward_to", "") ?: ""
        set(v) {
            prefs.edit().putString("forward_to", v).apply()
        }

    // ---- App Lock ----
    var pin: String
        get() = prefs.getString("pin", "") ?: ""
        set(v) {
            prefs.edit().putString("pin", v).apply()
        }

    // ---- Backup password ----
    var backupPassword: String
        get() = prefs.getString("backup_pw", "") ?: ""
        set(v) {
            prefs.edit().putString("backup_pw", v).apply()
        }
}
