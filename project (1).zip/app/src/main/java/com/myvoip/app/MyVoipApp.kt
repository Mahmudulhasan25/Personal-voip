package com.myvoip.app

import android.app.Application
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

class MyVoipApp : Application() {

    override fun onCreate() {
        super.onCreate()
        installCrashReporter()
        Store.init(this)
        PhoneContacts.load(this)
        SipEngine.init(this)
    }

    /** Crash hole karon file-e likhe rakhe; porer bar app khulle MainActivity screen-e dekhay. */
    private fun installCrashReporter() {
        val file = File(filesDir, "crash.txt")
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                file.writeText(
                    "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), " +
                        "${Build.MANUFACTURER} ${Build.MODEL}\n\n$sw"
                )
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, throwable)
        }
    }
}
