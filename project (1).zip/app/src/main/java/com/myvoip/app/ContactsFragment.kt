package com.myvoip.app

import android.Manifest
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import java.util.UUID

// Ekbar permission chaowar por ei process-e abar bar bar chabe na
private var askedContactsPermission = false

class ContactsFragment : Fragment(R.layout.fragment_list) {

    /** fromPhone = true hole phone-er contact (shudhu call kora jay, edit/delete na). */
    private class Entry(val contact: Contact, val fromPhone: Boolean)

    private lateinit var adapter: TwoLineAdapter
    private var shown: List<Entry> = emptyList()
    private var query = ""

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            context?.let { PhoneContacts.load(it) }
            reload()
        } else {
            context?.toast("Phone contact dekhte hole Settings theke Contacts permission din")
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.findViewById<TextView>(R.id.tvTitle).text = "Contacts"
        view.findViewById<TextView>(R.id.tvEmpty).text = "Kono contact nei"

        val btn = view.findViewById<Button>(R.id.btnAction)
        btn.text = "Add contact"
        btn.setOnClickListener { showForm(null) }

        val etSearch = view.findViewById<EditText>(R.id.etSearch)
        etSearch.visibility = View.VISIBLE
        etSearch.doAfterTextChanged {
            query = it?.toString() ?: ""
            reload()
        }

        val list = view.findViewById<ListView>(R.id.list)
        adapter = TwoLineAdapter(requireContext(), emptyList())
        list.adapter = adapter
        list.emptyView = view.findViewById(R.id.tvEmpty)

        list.setOnItemClickListener { _, _, pos, _ ->
            val e = shown.getOrNull(pos) ?: return@setOnItemClickListener
            showOptions(e)
        }
    }

    override fun onStart() {
        super.onStart()
        val ctx = requireContext()
        if (PhoneContacts.hasPermission(ctx)) {
            PhoneContacts.load(ctx)
        } else if (!askedContactsPermission) {
            askedContactsPermission = true
            permLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
        reload()
    }

    private fun reload() {
        val q = query.trim().lowercase()
        val all = Store.contacts().map { Entry(it, false) } +
            PhoneContacts.list.map { Entry(it, true) }
        shown = all
            .filter {
                q.isEmpty() ||
                    it.contact.name.lowercase().contains(q) ||
                    it.contact.number.contains(q)
            }
            .sortedBy { it.contact.name.lowercase() }
        adapter.rows = shown.map {
            Row(it.contact.name, it.contact.number + if (it.fromPhone) " · Phone" else "")
        }
        adapter.notifyDataSetChanged()
    }

    private fun call(c: Contact) {
        (requireActivity() as MainActivity).ensureMic {
            val err = SipEngine.call(c.number, null)
            if (err != null) context?.toast(err)
        }
    }

    private fun showOptions(e: Entry) {
        val c = e.contact
        val opts = if (e.fromPhone) {
            arrayOf("Call", "Copy to My VoIP contacts")
        } else {
            arrayOf("Call", "Edit", "Delete")
        }
        AlertDialog.Builder(requireContext())
            .setTitle(c.name)
            .setItems(opts) { _, which ->
                if (e.fromPhone) {
                    when (which) {
                        0 -> call(c)
                        1 -> {
                            val list = Store.contacts().toMutableList()
                            list.add(Contact(name = c.name, number = c.number))
                            Store.saveContacts(list)
                            reload()
                            context?.toast("Copy hoyeche")
                        }
                    }
                } else {
                    when (which) {
                        0 -> call(c)
                        1 -> showForm(c)
                        2 -> AlertDialog.Builder(requireContext())
                            .setTitle("${c.name}-ke muchben?")
                            .setPositiveButton("Muchun") { _, _ ->
                                Store.saveContacts(Store.contacts().filter { it.id != c.id })
                                reload()
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                }
            }
            .show()
    }

    private fun showForm(existing: Contact?) {
        formDialog(
            requireContext(),
            if (existing == null) "Add contact" else "Edit contact",
            listOf(
                Field("Name", existing?.name ?: ""),
                Field("Number", existing?.number ?: "", phone = true)
            )
        ) { v, _ ->
            if (v[0].isEmpty() || v[1].isEmpty()) {
                context?.toast("Name ar number dujon-i dorkar")
                return@formDialog
            }
            val c = Contact(
                id = existing?.id ?: UUID.randomUUID().toString(),
                name = v[0],
                number = v[1]
            )
            val list = Store.contacts().toMutableList()
            val idx = list.indexOfFirst { it.id == c.id }
            if (idx >= 0) list[idx] = c else list.add(c)
            Store.saveContacts(list)
            reload()
        }
    }
}
