package com.myvoip.app

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.fragment.app.Fragment
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * AI chat screen. API key app-e nei: app shudhu nijer server-er /chat endpoint-e
 * message pathay (server-ei API key thake).
 */
class AiChatFragment : Fragment(R.layout.fragment_ai_chat) {

    private lateinit var box: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var etMsg: EditText
    private lateinit var btnSend: Button
    private var busy = false

    companion object {
        // role ("user" / "assistant") to text. Screen bodle gele-o chat mone thake.
        private val history = ArrayList<Pair<String, String>>()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        box = view.findViewById(R.id.chatBox)
        scroll = view.findViewById(R.id.chatScroll)
        etMsg = view.findViewById(R.id.etMsg)
        btnSend = view.findViewById(R.id.btnSend)

        view.findViewById<Button>(R.id.btnServer).setOnClickListener { serverDialog() }
        view.findViewById<Button>(R.id.btnClearChat).setOnClickListener {
            history.clear()
            box.removeAllViews()
        }
        btnSend.setOnClickListener { send() }

        for ((role, text) in history) addBubble(role, text)
        scrollDown()
    }

    private fun serverDialog() {
        formDialog(
            requireContext(),
            "AI Server",
            listOf(
                Field("Server URL (https://...)", AppSettings.aiServerUrl),
                Field("App token (server-e set korle)", AppSettings.aiToken)
            )
        ) { v, _ ->
            AppSettings.aiServerUrl = v[0]
            AppSettings.aiToken = v[1]
            context?.toast("Save hoyeche")
        }
    }

    private fun send() {
        if (busy) return
        val text = etMsg.text.toString().trim()
        if (text.isEmpty()) return

        val base = AppSettings.aiServerUrl.trim().trimEnd('/')
        if (base.isEmpty()) {
            context?.toast("Age Server URL din")
            serverDialog()
            return
        }

        etMsg.setText("")
        history.add("user" to text)
        addBubble("user", text)
        val waiting = addBubble("assistant", "...")
        scrollDown()

        busy = true
        btnSend.isEnabled = false
        val snapshot = history.takeLast(20).toList()
        val token = AppSettings.aiToken.trim()

        Thread {
            var reply: String? = null
            var error: String? = null
            try {
                reply = callServer(base, token, snapshot)
            } catch (e: Exception) {
                error = e.message ?: "Somossa hoyeche"
            }
            val act = activity ?: return@Thread
            act.runOnUiThread {
                busy = false
                btnSend.isEnabled = true
                if (reply != null) {
                    history.add("assistant" to reply)
                    waiting.text = reply
                } else {
                    // Fail hole user-er last message history theke bad dei, jate abar pathate pare
                    if (history.isNotEmpty() && history.last().first == "user") {
                        history.removeAt(history.size - 1)
                    }
                    waiting.text = "Error: $error"
                }
                scrollDown()
            }
        }.start()
    }

    private fun callServer(base: String, token: String, msgs: List<Pair<String, String>>): String {
        val conn = URL("$base/chat").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            // Free hosting ghumiye thakle prothom request-e 30-60 second lagte pare
            conn.connectTimeout = 20_000
            conn.readTimeout = 90_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (token.isNotEmpty()) conn.setRequestProperty("X-App-Token", token)

            val arr = JSONArray()
            for ((role, content) in msgs) {
                arr.put(JSONObject().put("role", role).put("content", content))
            }
            val body = JSONObject().put("messages", arr).toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val json = try {
                JSONObject(text)
            } catch (e: Exception) {
                null
            }
            if (code !in 200..299) {
                throw IOException(json?.optString("error")?.takeIf { it.isNotEmpty() } ?: "Server error $code")
            }
            return json?.optString("reply") ?: throw IOException("Server-er uttor bujha gelo na")
        } finally {
            conn.disconnect()
        }
    }

    private fun addBubble(role: String, text: String): TextView {
        val ctx = requireContext()
        val d = ctx.resources.displayMetrics.density
        val user = role == "user"

        val tv = TextView(ctx)
        tv.text = text
        tv.textSize = 16f
        tv.setTextIsSelectable(true)
        tv.setTextColor(if (user) Color.WHITE else Color.parseColor("#111111"))
        val padH = (12 * d).toInt()
        val padV = (8 * d).toInt()
        tv.setPadding(padH, padV, padH, padV)
        tv.background = GradientDrawable().apply {
            cornerRadius = 16 * d
            setColor(Color.parseColor(if (user) "#0D9488" else "#E5E7EB"))
        }

        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.gravity = if (user) Gravity.END else Gravity.START
        lp.topMargin = (6 * d).toInt()
        if (user) lp.marginStart = (48 * d).toInt() else lp.marginEnd = (48 * d).toInt()
        box.addView(tv, lp)
        return tv
    }

    private fun scrollDown() {
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }
}
