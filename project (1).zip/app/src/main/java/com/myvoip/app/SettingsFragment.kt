package com.myvoip.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment(R.layout.fragment_list) {

    private lateinit var adapter: TwoLineAdapter

    private val wallpaperPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val ok = Wallpaper.save(requireContext(), uri)
            context?.toast(if (ok) "Wallpaper set hoyeche" else "Chhobi neya gelo na")
            reload()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.findViewById<TextView>(R.id.tvTitle).text = "Settings"
        view.findViewById<Button>(R.id.btnAction).visibility = View.GONE

        val list = view.findViewById<ListView>(R.id.list)
        adapter = TwoLineAdapter(requireContext(), emptyList())
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            when (pos) {
                0 -> open(AccountsFragment())
                1 -> audioDialog()
                2 -> notificationDialog()
                3 -> privacyDialog()
                4 -> open(BackupFragment())
                5 -> aboutDialog()
                6 -> networkDialog()
                7 -> debugDialog()
                8 -> wallpaperDialog()
                9 -> open(AiChatFragment())
            }
        }
    }

    override fun onStart() {
        super.onStart()
        reload()
    }

    private fun onOff(b: Boolean) = if (b) "ON" else "OFF"

    private fun reload() {
        adapter.rows = listOf(
            Row("SIP Server / Accounts", "Host, username, password, UDP/TCP/TLS, login/logout"),
            Row(
                "Audio",
                "Loudspeaker default: ${onOff(AppSettings.speakerDefault)} · Ringtone: ${onOff(AppSettings.ringtoneOn)}"
            ),
            Row("Notifications", "Incoming call ar app notification"),
            Row("Privacy & Security", "Record-er shotorkobarta, data muchhe fela"),
            Row("Backup & Restore", "Google Drive / file, protidin automatic"),
            Row("About", "My VoIP v1.0"),
            Row(
                "Network (STUN / ICE)",
                "Ek-pokkhiy audio hole eta try korun · STUN: ${onOff(AppSettings.useStun)} · ICE: ${onOff(AppSettings.useIce)}"
            ),
            Row("Call debug info", "Call-er state timeline (somossa hole screenshot pathan)"),
            Row(
                "Call screen wallpaper",
                if (Wallpaper.exists(requireContext())) "Custom wallpaper ON" else "Default (gradient)"
            ),
            Row("AI Chatbot", "AI-er shathe chat korun (Server URL Chat screen-er Server button-e)")
        )
        adapter.notifyDataSetChanged()
    }

    private fun open(f: Fragment) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.container, f)
            .addToBackStack(null)
            .commit()
    }

    // ---------- Audio ----------

    private fun audioDialog() {
        val items = arrayOf("Call-e default-e loudspeaker", "Incoming call-e ringtone bajan")
        val checked = booleanArrayOf(AppSettings.speakerDefault, AppSettings.ringtoneOn)
        AlertDialog.Builder(requireContext())
            .setTitle("Audio")
            .setMultiChoiceItems(items, checked) { _, which, isChecked ->
                if (which == 0) AppSettings.speakerDefault = isChecked
                else AppSettings.ringtoneOn = isChecked
            }
            .setPositiveButton("OK") { _, _ -> reload() }
            .show()
    }

    // ---------- Notifications ----------

    private fun notificationDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Notifications")
            .setMessage(
                "Call cholar shomoy je notification dekhay, ar app-er notification " +
                    "on/off phone-er system settings theke thik kora jay."
            )
            .setPositiveButton("Open system settings") { _, _ ->
                try {
                    val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, requireContext().packageName)
                    startActivity(i)
                } catch (e: Exception) {
                    context?.toast("Settings khola gelo na")
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- Privacy & Security ----------

    private fun privacyDialog() {
        val opts = arrayOf(
            "Record-er age shotorkobarta: ${onOff(AppSettings.askRecordConsent)} (change korte chapen)",
            "Call history muchun",
            "Shob recording muchun",
            "Shob account, contact ar favorite muchun"
        )
        AlertDialog.Builder(requireContext())
            .setTitle("Privacy & Security")
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> {
                        AppSettings.askRecordConsent = !AppSettings.askRecordConsent
                        reload()
                        context?.toast("Record-er age shotorkobarta ${onOff(AppSettings.askRecordConsent)}")
                    }
                    1 -> confirm("Shob call history muchben?") { SipEngine.clearLogs() }
                    2 -> confirm("Shob recording muchben?") {
                        SipEngine.recordingsDir().listFiles()?.forEach { it.delete() }
                    }
                    3 -> confirm("Shob account, contact ar favorite muchben? (Age backup nin)") {
                        Store.saveAccounts(emptyList())
                        Store.saveContacts(emptyList())
                        Store.setFavorites(emptySet())
                        Store.defaultAccountId = null
                        SipEngine.applyAccounts()
                    }
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun confirm(title: String, action: () -> Unit) {
        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setPositiveButton("Muchun") { _, _ ->
                action()
                context?.toast("Hoyeche")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Network (NAT) ----------

    private fun networkDialog() {
        val items = arrayOf("STUN (public IP khuje ber kore)", "ICE (aro kora-kori path khuje)")
        val checked = booleanArrayOf(AppSettings.useStun, AppSettings.useIce)
        AlertDialog.Builder(requireContext())
            .setTitle("Network (NAT)")
            .setMultiChoiceItems(items, checked) { _, which, isChecked ->
                if (which == 0) AppSettings.useStun = isChecked
                else AppSettings.useIce = isChecked
            }
            .setPositiveButton("Apply") { _, _ ->
                SipEngine.applyAccounts()
                reload()
                context?.toast("Account abar register hocche")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Wallpaper ----------

    private fun wallpaperDialog() {
        val b = AlertDialog.Builder(requireContext())
            .setTitle("Call screen wallpaper")
            .setMessage("Call cholar shomoy pechone nijer pochondoer chhobi dekhate parben.")
            .setPositiveButton("Chhobi bachai") { _, _ -> wallpaperPicker.launch("image/*") }
            .setNegativeButton("Close", null)
        if (Wallpaper.exists(requireContext())) {
            b.setNeutralButton("Default-e fire") { _, _ ->
                Wallpaper.remove(requireContext())
                reload()
            }
        }
        b.show()
    }

    // ---------- Debug ----------

    private fun debugDialog() {
        val text = SipEngine.debugText()
        AlertDialog.Builder(requireContext())
            .setTitle("Call debug info")
            .setMessage(if (text.isEmpty()) "Ekhono kono call hoyni" else text)
            .setPositiveButton("Close", null)
            .setNeutralButton("Clear") { _, _ -> SipEngine.clearDebug() }
            .show()
    }

    // ---------- About ----------

    private fun aboutDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("My VoIP")
            .setMessage(
                "SIP softphone (Linphone SDK, GPLv3).\n\n" +
                    "Password app-er private storage-e save thake. " +
                    "Call record korar age onno pokkhoer shommoti nin."
            )
            .setPositiveButton("OK", null)
            .show()
    }
}
