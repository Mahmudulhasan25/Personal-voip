package com.myvoip.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.linphone.core.Call

class CallActivity : AppCompatActivity(), SipEngine.Listener {

    private lateinit var tvName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvTimer: TextView
    private lateinit var rowControls: View
    private lateinit var btnMute: Button
    private lateinit var btnSpeaker: Button
    private lateinit var btnRecord: Button
    private lateinit var btnAnswer: Button
    private lateinit var btnHangup: Button

    private val handler = Handler(Looper.getMainLooper())
    private var ringtone: Ringtone? = null
    private var muted = false
    private var closing = false

    private val micLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) doAnswer() else toast("Microphone permission lagbe")
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateUi()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        tvName = findViewById(R.id.tvName)
        tvStatus = findViewById(R.id.tvStatus)
        tvTimer = findViewById(R.id.tvTimer)
        rowControls = findViewById(R.id.rowControls)
        btnMute = findViewById(R.id.btnMute)
        btnSpeaker = findViewById(R.id.btnSpeaker)
        btnRecord = findViewById(R.id.btnRecord)
        btnAnswer = findViewById(R.id.btnAnswer)
        btnHangup = findViewById(R.id.btnHangup)

        btnAnswer.setOnClickListener { answer() }
        btnHangup.setOnClickListener {
            val call = SipEngine.activeCall()
            if (call != null) call.terminate() else finish()
        }
        btnMute.setOnClickListener {
            val call = SipEngine.activeCall() ?: return@setOnClickListener
            call.microphoneMuted = !call.microphoneMuted
            updateToggleLabels(call)
        }
        btnSpeaker.setOnClickListener {
            SipEngine.setSpeaker(!SipEngine.speakerOn)
            val call = SipEngine.activeCall()
            if (call != null) updateToggleLabels(call)
        }
        btnRecord.setOnClickListener { onRecordClicked() }
    }

    override fun onStart() {
        super.onStart()
        SipEngine.addListener(this)
        handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        SipEngine.removeListener(this)
        handler.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopRing()
        handler.removeCallbacksAndMessages(null)
    }

    override fun onCallStateChanged(call: Call, state: Call.State) {
        updateUi()
    }

    // ---------- UI ----------

    private fun updateUi() {
        if (closing) return
        val call = SipEngine.activeCall()
        if (call == null) {
            closeSoon("Call ended")
            return
        }
        tvName.text = SipEngine.labelFor(call.remoteAddress)
        updateToggleLabels(call)

        when (call.state) {
            Call.State.IncomingReceived -> {
                tvStatus.text = "Incoming call"
                tvTimer.text = ""
                btnAnswer.visibility = View.VISIBLE
                btnHangup.text = "Reject"
                rowControls.visibility = View.GONE
                startRing()
            }
            Call.State.OutgoingInit,
            Call.State.OutgoingProgress,
            Call.State.OutgoingRinging -> {
                stopRing()
                tvStatus.text = "Calling..."
                tvTimer.text = ""
                btnAnswer.visibility = View.GONE
                btnHangup.text = "Cancel"
                rowControls.visibility = View.VISIBLE
                btnRecord.visibility = View.INVISIBLE
            }
            Call.State.Connected,
            Call.State.StreamsRunning -> {
                stopRing()
                tvStatus.text = "Connected"
                tvTimer.text = fmtDuration(call.duration)
                btnAnswer.visibility = View.GONE
                btnHangup.text = "Hang up"
                rowControls.visibility = View.VISIBLE
                btnRecord.visibility = View.VISIBLE
                btnRecord.text = if (SipEngine.isRecording(call)) "Stop REC ●" else "Record"
            }
            Call.State.End,
            Call.State.Released,
            Call.State.Error -> closeSoon("Call ended")
            else -> {
                tvStatus.text = call.state?.name ?: ""
            }
        }
    }

    private fun closeSoon(text: String) {
        if (closing) return
        closing = true
        stopRing()
        tvStatus.text = text
        handler.postDelayed({ finish() }, 700)
    }

    /** Mute ar Speaker button-er lekha ashol obosthar shathe mila-y. */
    private fun updateToggleLabels(call: Call) {
        btnMute.text = if (call.microphoneMuted) "🔇 Muted" else "🎤 Mute"
        btnSpeaker.text = if (SipEngine.speakerOn) "🔊 Speaker ON" else "🔈 Speaker"
    }

    // ---------- Answer ----------

    private fun answer() {
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) doAnswer() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun doAnswer() {
        stopRing()
        val call = SipEngine.activeCall() ?: return
        SipEngine.answer(call)
    }

    // ---------- Recording ----------

    private fun onRecordClicked() {
        val call = SipEngine.activeCall() ?: return
        if (SipEngine.isRecording(call)) {
            SipEngine.toggleRecording(call)
            btnRecord.text = "Record"
            toast("Recording save hoyeche (Records tab-e dekhun)")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Call record korben?")
            .setMessage(
                "Onek deshe call record korte onno pokkhoer shommoti lage. " +
                    "Onno pokkhoke janiye tarpor record korun."
            )
            .setPositiveButton("Record shuru") { _, _ ->
                val c = SipEngine.activeCall()
                if (c != null) {
                    val on = SipEngine.toggleRecording(c)
                    btnRecord.text = if (on) "Stop REC ●" else "Record"
                    if (!on) toast("Recording shuru hoyni")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Ringtone ----------

    private fun startRing() {
        if (ringtone != null) return
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(this, uri)
            ringtone?.play()
        } catch (_: Throwable) {
        }
    }

    private fun stopRing() {
        try {
            ringtone?.stop()
        } catch (_: Throwable) {
        }
        ringtone = null
    }
}
