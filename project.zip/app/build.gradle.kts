plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.myvoip.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.myvoip.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Shudhu ekta APK: arm64 (prai shob notun phone). Eta size-o kome.
    defaultConfig {
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    // .so file gulo APK-te compress kore rakhe: download/APK size onek kome
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    // Debug build-ke non-debuggable kora: app onek druto khole. (Shrink/R8 ba^dh: build ba call bhange jete pare.)
    // Signing ekhono debug key-ei, tai install/upgrade ager moto-i hobe.
    buildTypes {
        debug {
            isDebuggable = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.linphone:linphone-sdk-android:5.4.+")
}
