package com.myvoip.app

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Backup-e ja thake: SIP account (password shoho), contact, favorite, settings.
 * Ja thake na: call history (Linphone-er nijossho database), recording file (boro).
 */
object Backup {

    fun toJson(): String {
        val root = JSONObject()
        root.put("app", "myvoip")
        root.put("version", 1)
        root.put("created", System.currentTimeMillis())

        val accounts = JSONArray()
        Store.accounts().forEach { accounts.put(it.toJson()) }
        root.put("accounts", accounts)

        val contacts = JSONArray()
        Store.contacts().forEach { contacts.put(it.toJson()) }
        root.put("contacts", contacts)

        val favs = JSONArray()
        Store.favorites().forEach { favs.put(it) }
        root.put("favorites", favs)

        root.put("defaultAccount", Store.defaultAccountId ?: "")

        val s = JSONObject()
        s.put("speakerDefault", AppSettings.speakerDefault)
        s.put("ringtoneOn", AppSettings.ringtoneOn)
        s.put("askRecordConsent", AppSettings.askRecordConsent)
        s.put("autoBackup", AppSettings.autoBackup)
        root.put("settings", s)

        return root.toString(2)
    }

    private fun aesKey(pw: String, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val k = f.generateSecret(PBEKeySpec(pw.toCharArray(), salt, 120000, 256)).encoded
        return SecretKeySpec(k, "AES")
    }

    /** Backup password thakle AES-256 diye lock kore file-er lekha baniye dey. */
    fun export(): String {
        val plain = toJson()
        val pw = Extras.backupPassword
        if (pw.isEmpty()) return plain
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, aesKey(pw, salt), GCMParameterSpec(128, iv))
        val enc = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        val b64 = { b: ByteArray -> android.util.Base64.encodeToString(b, android.util.Base64.NO_WRAP) }
        return JSONObject().put("app", "myvoip-enc").put("salt", b64(salt))
            .put("iv", b64(iv)).put("data", b64(enc)).toString()
    }

    /** Restore kore. Error hole error-er lekha, shofol hole null. */
    fun restore(input: String): String? {
        var json = input
        try {
            val head = JSONObject(input)
            if (head.optString("app") == "myvoip-enc") {
                val pw = Extras.backupPassword
                if (pw.isEmpty()) return "Eta password deya backup. Age Settings -> Backup password-e oi password dien"
                val d = { k: String -> android.util.Base64.decode(head.getString(k), android.util.Base64.NO_WRAP) }
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, aesKey(pw, d("salt")), GCMParameterSpec(128, d("iv")))
                json = String(c.doFinal(d("data")), Charsets.UTF_8)
            }
        } catch (e: Exception) {
            return "Password bhul ba file nosto"
        }
        try {
            val root = JSONObject(json)
            if (root.optString("app") != "myvoip") return "Eta My VoIP-er backup file na"

            val accArr = root.optJSONArray("accounts") ?: JSONArray()
            val accounts = (0 until accArr.length()).map { SipAccount.fromJson(accArr.getJSONObject(it)) }

            val conArr = root.optJSONArray("contacts") ?: JSONArray()
            val contacts = (0 until conArr.length()).map { Contact.fromJson(conArr.getJSONObject(it)) }

            val favArr = root.optJSONArray("favorites") ?: JSONArray()
            val favs = (0 until favArr.length()).map { favArr.getString(it) }.toSet()

            Store.saveAccounts(accounts)
            Store.saveContacts(contacts)
            Store.setFavorites(favs)
            val def = root.optString("defaultAccount")
            Store.defaultAccountId = if (def.isEmpty()) accounts.firstOrNull()?.id else def

            val s = root.optJSONObject("settings")
            if (s != null) {
                AppSettings.speakerDefault = s.optBoolean("speakerDefault", false)
                AppSettings.ringtoneOn = s.optBoolean("ringtoneOn", true)
                AppSettings.askRecordConsent = s.optBoolean("askRecordConsent", true)
                AppSettings.autoBackup = s.optBoolean("autoBackup", true)
            }
            SipEngine.applyAccounts()
            return null
        } catch (e: Exception) {
            return "Restore hoyni: ${e.message}"
        }
    }

    // ---------- Automatic backup (app-er bhitore, protidin) ----------

    fun backupDir(ctx: Context): File {
        val dir = File(ctx.filesDir, "backups")
        dir.mkdirs()
        return dir
    }

    fun autoBackup(ctx: Context): File {
        val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val file = File(backupDir(ctx), "backup_$stamp.json")
        file.writeText(export())
        AppSettings.lastAutoBackup = System.currentTimeMillis()

        // Shudhu shesh 7 ta rakhe
        val all = backupDir(ctx).listFiles { f -> f.name.endsWith(".json") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
        all.drop(7).forEach { it.delete() }
        return file
    }

    fun latestAutoBackup(ctx: Context): File? =
        backupDir(ctx).listFiles { f -> f.name.endsWith(".json") }
            ?.maxByOrNull { it.lastModified() }
}

class BackupWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            Backup.autoBackup(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

object BackupScheduler {
    fun apply(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        if (AppSettings.autoBackup) {
            val req = PeriodicWorkRequestBuilder<BackupWorker>(24, TimeUnit.HOURS).build()
            wm.enqueueUniquePeriodicWork("daily_backup", ExistingPeriodicWorkPolicy.KEEP, req)
        } else {
            wm.cancelUniqueWork("daily_backup")
        }
    }
}
