package com.myvoip.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.WindowManager
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.linphone.core.Call

class CallActivity : AppCompatActivity(), SipEngine.Listener {

    private lateinit var tvName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvTimer: TextView
    private lateinit var rowControls: View
    private lateinit var rowBottom: View
    private lateinit var rowIncoming: View
    private lateinit var btnMute: View
    private lateinit var btnSpeaker: View
    private lateinit var btnHold: View
    private lateinit var btnRecord: View
    private lateinit var btnKeypad: View
    private lateinit var btnAnswer: View
    private lateinit var btnReject: View
    private lateinit var btnHangup: View
    private lateinit var icMute: ImageView
    private lateinit var icSpeaker: ImageView
    private lateinit var icHold: ImageView
    private lateinit var icRecord: ImageView
    private lateinit var lblMute: TextView
    private lateinit var lblSpeaker: TextView
    private lateinit var lblHold: TextView
    private lateinit var lblRecord: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var ringtone: Ringtone? = null
    private var closing = false
    private var connectedAt = 0L

    private val micLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) doAnswer() else toast("Microphone permission lagbe")
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateUi()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        tvName = findViewById(R.id.tvName)
        tvStatus = findViewById(R.id.tvStatus)
        tvTimer = findViewById(R.id.tvTimer)
        rowControls = findViewById(R.id.rowControls)
        rowBottom = findViewById(R.id.rowBottom)
        rowIncoming = findViewById(R.id.rowIncoming)
        btnMute = findViewById(R.id.btnMute)
        btnSpeaker = findViewById(R.id.btnSpeaker)
        btnHold = findViewById(R.id.btnHold)
        btnRecord = findViewById(R.id.btnRecord)
        btnKeypad = findViewById(R.id.btnKeypad)
        btnAnswer = findViewById(R.id.btnAnswer)
        btnReject = findViewById(R.id.btnReject)
        btnHangup = findViewById(R.id.btnHangup)
        icMute = findViewById(R.id.icMute)
        icSpeaker = findViewById(R.id.icSpeaker)
        icHold = findViewById(R.id.icHold)
        icRecord = findViewById(R.id.icRecord)
        lblMute = findViewById(R.id.lblMute)
        lblSpeaker = findViewById(R.id.lblSpeaker)
        lblHold = findViewById(R.id.lblHold)
        lblRecord = findViewById(R.id.lblRecord)
        icKeypadInit()

        // Custom wallpaper thakle dekhai
        val bmp = Wallpaper.load(this)
        if (bmp != null) {
            val iv = findViewById<ImageView>(R.id.ivWallpaper)
            iv.setImageBitmap(bmp)
            iv.visibility = View.VISIBLE
        }

        val hang = View.OnClickListener {
            val call = SipEngine.activeCall()
            if (call != null) call.terminate() else finish()
        }
        btnHangup.setOnClickListener(hang)
        btnReject.setOnClickListener(hang)
        btnAnswer.setOnClickListener { answer() }
        btnMute.setOnClickListener {
            val call = SipEngine.activeCall() ?: return@setOnClickListener
            call.microphoneMuted = !call.microphoneMuted
            updateToggleLabels(call)
        }
        btnSpeaker.setOnClickListener {
            SipEngine.setSpeaker(!SipEngine.speakerOn)
            val call = SipEngine.activeCall()
            if (call != null) updateToggleLabels(call)
        }
        btnHold.setOnClickListener { toggleHold() }
        btnRecord.setOnClickListener { onRecordClicked() }
        btnKeypad.setOnClickListener { showKeypad() }
    }

    private fun icKeypadInit() {
        findViewById<ImageView>(R.id.icKeypad).setImageResource(R.drawable.ic_dialpad)
        icMute.setImageResource(R.drawable.ic_mic)
        icSpeaker.setImageResource(R.drawable.ic_volume)
        icHold.setImageResource(R.drawable.ic_pause)
        icRecord.setImageResource(R.drawable.ic_record)
    }

    override fun onStart() {
        super.onStart()
        SipEngine.addListener(this)
        handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        SipEngine.removeListener(this)
        handler.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopRing()
        handler.removeCallbacksAndMessages(null)
    }

    override fun onCallStateChanged(call: Call, state: Call.State) {
        updateUi()
    }

    // ---------- UI ----------

    private fun updateUi() {
        if (closing) return
        val call = SipEngine.activeCall()
        if (call == null) {
            closeSoon("Call ended")
            return
        }
        tvName.text = SipEngine.labelFor(call.remoteAddress)
        updateToggleLabels(call)

        when (call.state) {
            Call.State.IncomingReceived -> {
                tvStatus.text = "Incoming call"
                tvTimer.text = ""
                rowIncoming.visibility = View.VISIBLE
                rowBottom.visibility = View.GONE
                rowControls.visibility = View.GONE
                startRing()
            }
            Call.State.OutgoingInit,
            Call.State.OutgoingProgress,
            Call.State.OutgoingEarlyMedia,
            Call.State.OutgoingRinging -> {
                stopRing()
                tvStatus.text = "Calling..."
                tvTimer.text = ""
                showInCall(false)
            }
            Call.State.Connected,
            Call.State.StreamsRunning -> {
                stopRing()
                // Linphone-er duration kokhono 0 thake; tai nijer ghori-o rakhi
                if (connectedAt == 0L) connectedAt = SystemClock.elapsedRealtime()
                val secs = ((SystemClock.elapsedRealtime() - connectedAt) / 1000).toInt()
                tvStatus.text = "Connected"
                tvTimer.text = fmtDuration(maxOf(call.duration, secs))
                showInCall(true)
            }
            Call.State.Pausing,
            Call.State.Paused -> {
                tvStatus.text = "On hold"
                tvTimer.text = fmtDuration(call.duration)
                showInCall(true)
            }
            Call.State.PausedByRemote -> {
                tvStatus.text = "Onno pokkho hold-e rekheche"
                tvTimer.text = fmtDuration(call.duration)
            }
            Call.State.Resuming -> {
                tvStatus.text = "Resuming..."
            }
            Call.State.End,
            Call.State.Released,
            Call.State.Error -> closeSoon("Call ended")
            else -> {
                tvStatus.text = call.state?.name ?: ""
            }
        }
    }

    /** In-call controls dekhay. connected=false hole (dial korar shomoy) Hold/Record lukano thake. */
    private fun showInCall(connected: Boolean) {
        rowIncoming.visibility = View.GONE
        rowBottom.visibility = View.VISIBLE
        rowControls.visibility = View.VISIBLE
        // Choy-ta bataam shob shomoy dekhai; Hold/Record/Keypad kaj kore shudhu call dhorar por
        for (b in listOf(btnHold, btnRecord, btnKeypad)) {
            b.visibility = View.VISIBLE
            b.isEnabled = connected
            b.alpha = if (connected) 1f else 0.4f
        }
    }

    private fun closeSoon(text: String) {
        if (closing) return
        closing = true
        stopRing()
        tvStatus.text = text
        handler.postDelayed({ finish() }, 700)
    }

    private val activeTint = 0xFF4FC3F7.toInt()
    private val offTint = 0xFFFFFFFF.toInt()

    /** Mute, Speaker, Hold, Record icon ar lekha ashol obosthar shathe mila-y. */
    private fun updateToggleLabels(call: Call) {
        val muted = call.microphoneMuted
        icMute.setImageResource(if (muted) R.drawable.ic_mic_off else R.drawable.ic_mic)
        icMute.setColorFilter(if (muted) activeTint else offTint)
        lblMute.text = if (muted) "Unmute" else "Mute"

        val spk = SipEngine.speakerOn
        icSpeaker.setColorFilter(if (spk) activeTint else offTint)
        lblSpeaker.text = "Speaker"

        val held = call.state == Call.State.Paused || call.state == Call.State.Pausing
        icHold.setImageResource(if (held) R.drawable.ic_play else R.drawable.ic_pause)
        icHold.setColorFilter(if (held) activeTint else offTint)
        lblHold.text = if (held) "Resume" else "Hold"

        val rec = SipEngine.isRecording(call)
        icRecord.setColorFilter(if (rec) 0xFFFF5252.toInt() else offTint)
        lblRecord.text = if (rec) "Stop rec" else "Record"
    }

    // ---------- Keypad (DTMF) ----------

    private fun showKeypad() {
        val call = SipEngine.activeCall() ?: return
        val grid = GridLayout(this)
        grid.columnCount = 3
        grid.setPadding(24, 24, 24, 8)
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
        for (k in keys) {
            val b = Button(this)
            b.text = k
            b.textSize = 18f
            b.setOnClickListener { call.sendDtmf(k[0]) }
            val lp = GridLayout.LayoutParams()
            lp.width = 0
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            b.layoutParams = lp
            grid.addView(b)
        }
        AlertDialog.Builder(this)
            .setTitle("Keypad")
            .setView(grid)
            .setPositiveButton("Close", null)
            .show()
    }

    // ---------- Hold ----------

    private fun toggleHold() {
        val call = SipEngine.activeCall() ?: return
        when (call.state) {
            Call.State.Paused -> call.resume()
            Call.State.Connected, Call.State.StreamsRunning -> call.pause()
            else -> {}
        }
    }

    // ---------- Answer ----------

    private fun answer() {
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) doAnswer() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun doAnswer() {
        stopRing()
        val call = SipEngine.activeCall() ?: return
        SipEngine.answer(call)
    }

    // ---------- Recording ----------

    private fun startRecording() {
        val c = SipEngine.activeCall() ?: return
        val on = SipEngine.toggleRecording(c)
        updateToggleLabels(c)
        if (!on) toast("Recording shuru hoyni")
    }

    private fun onRecordClicked() {
        val call = SipEngine.activeCall() ?: return
        if (SipEngine.isRecording(call)) {
            SipEngine.toggleRecording(call)
            updateToggleLabels(call)
            toast("Recording save hoyeche (Records tab-e dekhun)")
            return
        }
        if (!AppSettings.askRecordConsent) {
            startRecording()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Call record korben?")
            .setMessage(
                "Onek deshe call record korte onno pokkhoer shommoti lage. " +
                    "Onno pokkhoke janiye tarpor record korun."
            )
            .setPositiveButton("Record shuru") { _, _ -> startRecording() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Ringtone ----------

    private fun startRing() {
        if (ringtone != null || !AppSettings.ringtoneOn) return
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(this, uri)
            ringtone?.play()
        } catch (_: Throwable) {
        }
    }

    private fun stopRing() {
        try {
            ringtone?.stop()
        } catch (_: Throwable) {
        }
        ringtone = null
    }
}
