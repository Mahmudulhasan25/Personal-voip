package com.myvoip.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Ekta SIP account (provider-er deya tothyo). */
data class SipAccount(
    val id: String = UUID.randomUUID().toString(),
    val label: String,
    val host: String,          // "sip.example.com" ba "sip.example.com:5061"
    val username: String,
    val password: String,
    val authUser: String = "",  // provider alada auth username dile
    val transport: String = "UDP", // UDP / TCP / TLS
    val enabled: Boolean = true
) {
    val domain: String get() = host.substringBefore(":")

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("label", label)
        .put("host", host)
        .put("username", username)
        .put("password", password)
        .put("authUser", authUser)
        .put("transport", transport)
        .put("enabled", enabled)

    companion object {
        fun fromJson(o: JSONObject) = SipAccount(
            id = o.getString("id"),
            label = o.optString("label"),
            host = o.getString("host"),
            username = o.getString("username"),
            password = o.optString("password"),
            authUser = o.optString("authUser"),
            transport = o.optString("transport", "UDP"),
            enabled = o.optBoolean("enabled", true)
        )
    }
}

data class Contact(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val number: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("number", number)

    companion object {
        fun fromJson(o: JSONObject) = Contact(
            id = o.getString("id"),
            name = o.optString("name"),
            number = o.optString("number")
        )
    }
}

/** App-private SharedPreferences-e account ar contact save kore. */
object Store {
    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("myvoip_store", Context.MODE_PRIVATE)
    }

    fun accounts(): List<SipAccount> = readList("accounts") { SipAccount.fromJson(it) }

    fun saveAccounts(list: List<SipAccount>) = writeList("accounts", list.map { it.toJson() })

    var defaultAccountId: String?
        get() = prefs.getString("default_account", null)
        set(value) {
            prefs.edit().putString("default_account", value).apply()
        }

    fun contacts(): List<Contact> = readList("contacts") { Contact.fromJson(it) }

    fun saveContacts(list: List<Contact>) = writeList("contacts", list.map { it.toJson() })

    // ---- Favorites (number-er shesh 10 digit diye chine, phone/app dui contact-ei kaj kore) ----

    private fun favoriteKey(number: String): String =
        number.filter { it.isDigit() }.takeLast(10)

    fun favorites(): Set<String> = prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()

    fun setFavorites(keys: Set<String>) {
        prefs.edit().putStringSet("favorites", keys.toSet()).apply()
    }

    fun isFavorite(number: String): Boolean {
        val k = favoriteKey(number)
        return k.isNotEmpty() && favorites().contains(k)
    }

    fun toggleFavorite(number: String) {
        val k = favoriteKey(number)
        if (k.isEmpty()) return
        val set = favorites().toMutableSet()
        if (!set.add(k)) set.remove(k)
        setFavorites(set)
    }

    private fun <T> readList(key: String, parse: (JSONObject) -> T): List<T> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { parse(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeList(key: String, items: List<JSONObject>) {
        val arr = JSONArray()
        items.forEach { arr.put(it) }
        prefs.edit().putString(key, arr.toString()).apply()
    }
}
