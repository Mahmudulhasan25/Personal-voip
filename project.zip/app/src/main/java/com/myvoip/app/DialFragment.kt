package com.myvoip.app

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.GridLayout
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.fragment.app.Fragment
import org.linphone.core.Call

class DialFragment : Fragment(R.layout.fragment_dial), SipEngine.Listener {

    private var accounts: List<SipAccount> = emptyList()
    private lateinit var spinner: Spinner
    private lateinit var tvReg: TextView
    private lateinit var etNumber: EditText
    private lateinit var btnReturn: Button

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        spinner = view.findViewById(R.id.spAccount)
        tvReg = view.findViewById(R.id.tvReg)
        etNumber = view.findViewById(R.id.etNumber)
        btnReturn = view.findViewById(R.id.btnReturn)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                updateStatus()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        view.findViewById<Button>(R.id.btnCall).setOnClickListener {
            val number = etNumber.text.toString().trim()
            if (number.isEmpty()) {
                context?.toast("Number din")
                return@setOnClickListener
            }
            val accId = accounts.getOrNull(spinner.selectedItemPosition)?.id
            (requireActivity() as MainActivity).ensureMic {
                val err = SipEngine.call(number, accId)
                if (err != null) context?.toast(err)
            }
        }
        btnReturn.setOnClickListener { SipEngine.openCallScreen() }

        // Dial pad: 1-9, *, 0, #
        val pad = view.findViewById<GridLayout>(R.id.pad)
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
        for (k in keys) {
            val b = Button(requireContext())
            b.text = k
            b.textSize = 22f
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            )
            lp.width = 0
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            b.layoutParams = lp
            b.setOnClickListener { etNumber.append(k) }
            pad.addView(b)
        }

        // Backspace (dhore rakhle shob muche jay)
        val btnDelete = view.findViewById<Button>(R.id.btnDelete)
        btnDelete.setOnClickListener {
            val t = etNumber.text
            if (t.isNotEmpty()) t.delete(t.length - 1, t.length)
        }
        btnDelete.setOnLongClickListener {
            etNumber.text.clear()
            true
        }
    }

    override fun onStart() {
        super.onStart()
        SipEngine.addListener(this)
        loadAccounts()
        updateReturn()
    }

    override fun onStop() {
        super.onStop()
        SipEngine.removeListener(this)
    }

    override fun onAccountsChanged() {
        updateStatus()
    }

    override fun onCallStateChanged(call: Call, state: Call.State) {
        updateReturn()
    }

    private fun loadAccounts() {
        accounts = Store.accounts().filter { it.enabled }
        val labels = accounts.map { it.label.ifBlank { it.username } }
        spinner.adapter = ArrayAdapter(
            requireContext(), android.R.layout.simple_spinner_dropdown_item, labels
        )
        val defIdx = accounts.indexOfFirst { it.id == Store.defaultAccountId }
        if (defIdx >= 0) spinner.setSelection(defIdx)
        updateStatus()
    }

    private fun updateStatus() {
        val acc = accounts.getOrNull(spinner.selectedItemPosition)
        tvReg.text = if (acc == null) {
            "Accounts tab-e giye SIP account joge korun"
        } else {
            SipEngine.regStates[acc.id] ?: "—"
        }
    }

    private fun updateReturn() {
        btnReturn.visibility = if (SipEngine.activeCall() != null) View.VISIBLE else View.GONE
    }
}
