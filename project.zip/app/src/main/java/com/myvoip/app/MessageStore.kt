package com.myvoip.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

/** Ekta message. via = "SIP" ba "SMS". */
class Msg(
    val peer: String,
    val text: String,
    val time: Long,
    val outgoing: Boolean,
    val via: String,
    var status: String
)

/** Shob message (SIP + SMS) ei app-er nijer storage-e thake. */
object MessageStore {
    private lateinit var prefs: SharedPreferences
    private val list = ArrayList<Msg>()
    private val main = Handler(Looper.getMainLooper())

    /** Screen refresh korar jonno. Fragment onStart-e set kore, onStop-e null kore. */
    @Volatile
    var onChange: (() -> Unit)? = null

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("myvoip_messages", Context.MODE_PRIVATE)
        try {
            val arr = JSONArray(prefs.getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Msg(
                        o.getString("peer"), o.getString("text"), o.getLong("time"),
                        o.getBoolean("out"), o.getString("via"), o.getString("status")
                    )
                )
            }
        } catch (_: Exception) {
        }
    }

    /** Number theke ekta key (shesh 10 digit), jate +880 ar 0 shoho ek-i conversation hoy. */
    fun keyOf(number: String): String {
        val d = number.filter { it.isDigit() }
        return if (d.length > 10) d.takeLast(10) else d
    }

    @Synchronized
    fun add(m: Msg) {
        list.add(m)
        while (list.size > 600) list.removeAt(0)
        save()
        changed()
    }

    @Synchronized
    fun setStatus(m: Msg, status: String) {
        m.status = status
        save()
        changed()
    }

    @Synchronized
    fun forPeer(key: String): List<Msg> = list.filter { keyOf(it.peer) == key }.sortedBy { it.time }

    /** Prottek conversation-er shesh message, notun age. */
    @Synchronized
    fun conversations(): List<Msg> {
        val last = LinkedHashMap<String, Msg>()
        for (m in list.sortedBy { it.time }) last[keyOf(m.peer)] = m
        return last.values.sortedByDescending { it.time }
    }

    @Synchronized
    fun deleteConversation(key: String) {
        list.removeAll { keyOf(it.peer) == key }
        save()
        changed()
    }

    private fun save() {
        val arr = JSONArray()
        for (m in list) {
            val o = JSONObject()
            o.put("peer", m.peer)
            o.put("text", m.text)
            o.put("time", m.time)
            o.put("out", m.outgoing)
            o.put("via", m.via)
            o.put("status", m.status)
            arr.put(o)
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    private fun changed() {
        main.post { onChange?.invoke() }
    }
}
