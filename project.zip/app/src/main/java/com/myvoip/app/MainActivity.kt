package com.myvoip.app

import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.io.File

class MainActivity : AppCompatActivity() {

    private var pendingMicAction: (() -> Unit)? = null

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        val action = pendingMicAction
        pendingMicAction = null
        if (hasMic()) {
            action?.invoke()
        } else if (action != null) {
            toast("Microphone permission lagbe")
        }
    }

    fun hasMic(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.READ_PHONE_STATE
            )
        } else {
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE)
        }

    /** Mic permission thakle sorasori action, noile age permission chay. */
    fun ensureMic(action: () -> Unit) {
        if (hasMic()) {
            action()
        } else {
            pendingMicAction = action
            permLauncher.launch(requiredPermissions())
        }
    }

    // ---- Phone-er SIM diye SMS ----
    private var pendingSms: Triple<String, String, (Boolean) -> Unit>? = null

    private val smsPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val p = pendingSms ?: return@registerForActivityResult
        pendingSms = null
        doSms(p.first, p.second, granted, p.third)
    }

    fun sendSms(number: String, text: String, done: (Boolean) -> Unit) {
        val n = number.replace(Regex("[\\s\\-().]"), "")
        if (n.isEmpty()) {
            toast("Number din")
            return
        }
        val has = ContextCompat.checkSelfPermission(
            this, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
        if (has) {
            doSms(n, text, true, done)
        } else {
            pendingSms = Triple(n, text, done)
            smsPermLauncher.launch(Manifest.permission.SEND_SMS)
        }
    }

    private fun doSms(n: String, text: String, allowed: Boolean, done: (Boolean) -> Unit) {
        if (allowed) {
            try {
                val sm = if (Build.VERSION.SDK_INT >= 31) {
                    getSystemService(android.telephony.SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    android.telephony.SmsManager.getDefault()
                }
                sm.sendMultipartTextMessage(n, null, sm.divideMessage(text), null, null)
                done(true)
            } catch (e: Exception) {
                toast("SMS pathano gelo na: ${e.message}")
                done(false)
            }
        } else {
            // Permission na dile phone-er SMS app khule message boshiye dey
            try {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n)))
                i.putExtra("sms_body", text)
                startActivity(i)
            } catch (e: Exception) {
                toast("SMS app khola gelo na")
            }
            done(false)
        }
    }

    // ---- Phone-er SIM diye call (SIP noy): Home, Contacts, History theke ek-i jaygay ----
    private var pendingSimNumber: String? = null

    private val simPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val n = pendingSimNumber ?: return@registerForActivityResult
        pendingSimNumber = null
        startSimCall(n, granted)
    }

    fun simCall(raw: String) {
        val n = raw.replace(Regex("[\\s\\-().]"), "")
        if (n.isEmpty()) {
            toast("Number din")
            return
        }
        val has = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
        if (has) {
            startSimCall(n, true)
        } else {
            pendingSimNumber = n
            simPermLauncher.launch(Manifest.permission.CALL_PHONE)
        }
    }

    private fun startSimCall(n: String, allowed: Boolean) {
        val uri = Uri.parse("tel:" + Uri.encode(n))
        if (!allowed) {
            // Permission na dile dialer khule number boshiye dey, shudhu call chapte hoy
            try {
                startActivity(Intent(Intent.ACTION_DIAL, uri))
            } catch (e: Exception) {
                toast("SIM call shuru kora gelo na")
            }
            return
        }
        // Dual SIM hole SIM 1 / SIM 2 bachte dey
        var handles: List<android.telecom.PhoneAccountHandle> = emptyList()
        val tm = getSystemService(android.telecom.TelecomManager::class.java)
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) ==
                PackageManager.PERMISSION_GRANTED
            ) {
                handles = tm.callCapablePhoneAccounts
            }
        } catch (_: Exception) {
        }
        if (handles.size > 1) {
            val labels = handles.mapIndexed { i, h ->
                val l = try {
                    tm.getPhoneAccount(h)?.label?.toString()
                } catch (_: Exception) {
                    null
                }
                "SIM ${i + 1}" + if (l.isNullOrBlank()) "" else " · $l"
            }
            AlertDialog.Builder(this)
                .setTitle("Kon SIM diye call?")
                .setItems(labels.toTypedArray()) { _, i -> placeSimCall(uri, handles[i]) }
                .show()
        } else {
            placeSimCall(uri, null)
        }
    }

    private fun placeSimCall(uri: Uri, h: android.telecom.PhoneAccountHandle?) {
        try {
            val i = Intent(Intent.ACTION_CALL, uri)
            if (h != null) i.putExtra(android.telecom.TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, h)
            startActivity(i)
        } catch (e: Exception) {
            toast("SIM call shuru kora gelo na")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val accents = intArrayOf(
            R.style.Theme_MyVoip_Accent0, R.style.Theme_MyVoip_Accent1, R.style.Theme_MyVoip_Accent2,
            R.style.Theme_MyVoip_Accent3, R.style.Theme_MyVoip_Accent4, R.style.Theme_MyVoip_Accent5,
            R.style.Theme_MyVoip_Accent6, R.style.Theme_MyVoip_Accent7, R.style.Theme_MyVoip_Accent8
        )
        setTheme(accents[AppSettings.accent])
        if (AppSettings.themeMode == 3) theme.applyStyle(R.style.Overlay_Amoled, true)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // App wallpaper: chhobi pechone, fragment-er upor halka scrim jate lekha porha jay
        val bg = AppWallpaper.load(this)
        if (bg != null) {
            val iv = findViewById<android.widget.ImageView>(R.id.ivBg)
            iv.setImageBitmap(bg)
            iv.visibility = android.view.View.VISIBLE
            val night = (resources.configuration.uiMode and
                android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES
            val scrim = if (night) 0xA6000000.toInt() else 0xA6FFFFFF.toInt()
            supportFragmentManager.registerFragmentLifecycleCallbacks(
                object : androidx.fragment.app.FragmentManager.FragmentLifecycleCallbacks() {
                    override fun onFragmentViewCreated(
                        fm: androidx.fragment.app.FragmentManager, f: Fragment,
                        v: android.view.View, savedInstanceState: Bundle?
                    ) {
                        v.setBackgroundColor(scrim)
                    }
                }, true
            )
        }

        showLastCrashIfAny()
        window.decorView.post {
            SipEngine.logEvent(
                "STARTUP first screen ${android.os.SystemClock.elapsedRealtime() - android.os.Process.getStartElapsedRealtime()}ms after process start"
            )
        }

        val nav = findViewById<BottomNavigationView>(R.id.nav)
        nav.setOnItemSelectedListener { item ->
            val fragment: Fragment = when (item.itemId) {
                R.id.nav_contacts -> ContactsFragment()
                R.id.nav_records -> RecordingsFragment()
                R.id.nav_messages -> MessagesFragment()
                else -> HomeFragment()
            }
            // Settings-er bhitore khola sub-screen thakle age sheta bondho kori
            supportFragmentManager.popBackStack(
                null,
                androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE
            )
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, fragment)
                .commit()
            true
        }

        if (savedInstanceState == null) {
            nav.selectedItemId = R.id.nav_history
            // Prothom bar permission chay
            val missing = requiredPermissions().filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
        }
    }

    /** Upore gear icon chaple Settings khole. */
    fun openSettings() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, SettingsFragment())
            .addToBackStack(null)
            .commit()
    }

    // ---- App Lock (PIN) ----
    private var unlocked = false
    private var stoppedAt = 0L
    private var lockShowing = false

    override fun onStart() {
        super.onStart()
        // App abar samne ashle network bodle thakle abar register
        SipEngine.refreshRegistration()
        if (Extras.pin.isNotEmpty()) {
            // 30 second-er beshi pechone thakle abar PIN chay
            val away = android.os.SystemClock.elapsedRealtime() - stoppedAt
            if (!unlocked || (stoppedAt != 0L && away > 30_000)) showLock()
        }
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = android.os.SystemClock.elapsedRealtime()
    }

    private fun showLock() {
        if (lockShowing) return
        lockShowing = true
        val et = android.widget.EditText(this)
        et.hint = "PIN"
        et.inputType = android.text.InputType.TYPE_CLASS_NUMBER or
            android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        val pad = (20 * resources.displayMetrics.density).toInt()
        et.setPadding(pad, pad, pad, pad)
        val d = AlertDialog.Builder(this)
            .setTitle("My VoIP locked")
            .setView(et)
            .setCancelable(false)
            .setPositiveButton("Unlock", null)
            .setNegativeButton("Exit") { _, _ -> finishAffinity() }
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (et.text.toString() == Extras.pin) {
                    unlocked = true
                    lockShowing = false
                    d.dismiss()
                } else {
                    et.setText("")
                    toast("PIN thik na")
                }
            }
        }
        d.show()
    }

    private fun showLastCrashIfAny() {
        val f = File(filesDir, "crash.txt")
        if (!f.exists()) return
        val text = f.readText().take(3000)
        f.delete()
        AlertDialog.Builder(this)
            .setTitle("Last crash report (screenshot pathan)")
            .setMessage(text)
            .setPositiveButton("OK", null)
            .show()
    }
}
