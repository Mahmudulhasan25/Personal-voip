package com.myvoip.app

import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.io.File

class MainActivity : AppCompatActivity() {

    private var pendingMicAction: (() -> Unit)? = null

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        val action = pendingMicAction
        pendingMicAction = null
        if (hasMic()) {
            action?.invoke()
        } else if (action != null) {
            toast("Microphone permission lagbe")
        }
    }

    fun hasMic(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(Manifest.permission.RECORD_AUDIO)
        }

    /** Mic permission thakle sorasori action, noile age permission chay. */
    fun ensureMic(action: () -> Unit) {
        if (hasMic()) {
            action()
        } else {
            pendingMicAction = action
            permLauncher.launch(requiredPermissions())
        }
    }

    // ---- Phone-er SIM diye SMS ----
    private var pendingSms: Triple<String, String, (Boolean) -> Unit>? = null

    private val smsPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val p = pendingSms ?: return@registerForActivityResult
        pendingSms = null
        doSms(p.first, p.second, granted, p.third)
    }

    fun sendSms(number: String, text: String, done: (Boolean) -> Unit) {
        val n = number.replace(Regex("[\\s\\-().]"), "")
        if (n.isEmpty()) {
            toast("Number din")
            return
        }
        val has = ContextCompat.checkSelfPermission(
            this, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
        if (has) {
            doSms(n, text, true, done)
        } else {
            pendingSms = Triple(n, text, done)
            smsPermLauncher.launch(Manifest.permission.SEND_SMS)
        }
    }

    private fun doSms(n: String, text: String, allowed: Boolean, done: (Boolean) -> Unit) {
        if (allowed) {
            try {
                val sm = if (Build.VERSION.SDK_INT >= 31) {
                    getSystemService(android.telephony.SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    android.telephony.SmsManager.getDefault()
                }
                sm.sendMultipartTextMessage(n, null, sm.divideMessage(text), null, null)
                done(true)
            } catch (e: Exception) {
                toast("SMS pathano gelo na: ${e.message}")
                done(false)
            }
        } else {
            // Permission na dile phone-er SMS app khule message boshiye dey
            try {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n)))
                i.putExtra("sms_body", text)
                startActivity(i)
            } catch (e: Exception) {
                toast("SMS app khola gelo na")
            }
            done(false)
        }
    }

    // ---- Phone-er SIM diye call (SIP noy): Home, Contacts, History theke ek-i jaygay ----
    private var pendingSimNumber: String? = null

    private val simPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val n = pendingSimNumber ?: return@registerForActivityResult
        pendingSimNumber = null
        startSimCall(n, granted)
    }

    fun simCall(raw: String) {
        val n = raw.replace(Regex("[\\s\\-().]"), "")
        if (n.isEmpty()) {
            toast("Number din")
            return
        }
        val has = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
        if (has) {
            startSimCall(n, true)
        } else {
            pendingSimNumber = n
            simPermLauncher.launch(Manifest.permission.CALL_PHONE)
        }
    }

    private fun startSimCall(n: String, allowed: Boolean) {
        val uri = Uri.parse("tel:" + Uri.encode(n))
        try {
            // Permission na dile dialer khule number boshiye dey, shudhu call chapte hoy
            startActivity(Intent(if (allowed) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        } catch (e: Exception) {
            toast("SIM call shuru kora gelo na")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        showLastCrashIfAny()
        window.decorView.post {
            SipEngine.logEvent(
                "STARTUP first screen ${android.os.SystemClock.elapsedRealtime() - android.os.Process.getStartElapsedRealtime()}ms after process start"
            )
        }

        val nav = findViewById<BottomNavigationView>(R.id.nav)
        nav.setOnItemSelectedListener { item ->
            val fragment: Fragment = when (item.itemId) {
                R.id.nav_contacts -> ContactsFragment()
                R.id.nav_records -> RecordingsFragment()
                R.id.nav_messages -> MessagesFragment()
                else -> HomeFragment()
            }
            // Settings-er bhitore khola sub-screen thakle age sheta bondho kori
            supportFragmentManager.popBackStack(
                null,
                androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE
            )
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, fragment)
                .commit()
            true
        }

        if (savedInstanceState == null) {
            nav.selectedItemId = R.id.nav_history
            // Prothom bar permission chay
            val missing = requiredPermissions().filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
        }
    }

    /** Upore gear icon chaple Settings khole. */
    fun openSettings() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, SettingsFragment())
            .addToBackStack(null)
            .commit()
    }

    override fun onStart() {
        super.onStart()
        // App abar samne ashle network bodle thakle abar register
        SipEngine.refreshRegistration()
    }

    private fun showLastCrashIfAny() {
        val f = File(filesDir, "crash.txt")
        if (!f.exists()) return
        val text = f.readText().take(3000)
        f.delete()
        AlertDialog.Builder(this)
            .setTitle("Last crash report (screenshot pathan)")
            .setMessage(text)
            .setPositiveButton("OK", null)
            .show()
    }
}
