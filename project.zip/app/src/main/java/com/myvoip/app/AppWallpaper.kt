package com.myvoip.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/** App-er mul screen-er (Recents, Contacts, Settings...) wallpaper. */
object AppWallpaper {
    private fun file(ctx: Context) = File(ctx.filesDir, "app_wallpaper.jpg")

    fun exists(ctx: Context): Boolean = file(ctx).exists()

    fun load(ctx: Context): Bitmap? =
        if (exists(ctx)) BitmapFactory.decodeFile(file(ctx).absolutePath) else null

    fun remove(ctx: Context) {
        file(ctx).delete()
    }

    fun save(ctx: Context, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return false
            file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }
}
