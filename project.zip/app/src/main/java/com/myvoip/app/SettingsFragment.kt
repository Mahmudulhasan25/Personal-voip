package com.myvoip.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    private lateinit var rows: LinearLayout

    private val wallpaperPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val ok = Wallpaper.save(requireContext(), uri)
            context?.toast(if (ok) "Wallpaper set hoyeche" else "Chhobi neya gelo na")
            reload()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        rows = view.findViewById(R.id.rows)
        view.findViewById<View>(R.id.btnBack).setOnClickListener {
            parentFragmentManager.popBackStack()
        }
    }

    override fun onStart() {
        super.onStart()
        reload()
    }

    private fun onOff(b: Boolean) = if (b) "ON" else "OFF"

    private val grey = 0xFF6B7280.toInt()
    private val accent = 0xFF00897B.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun section(title: String) {
        val t = TextView(requireContext())
        t.text = title.uppercase()
        t.textSize = 12f
        t.setTextColor(accent)
        t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.letterSpacing = 0.08f
        t.setPadding(dp(20), dp(20), dp(20), dp(4))
        rows.addView(t)
    }

    private fun baseRow(icon: Int, title: String, subtitle: String?): LinearLayout {
        val ctx = requireContext()
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(20), dp(14), dp(16), dp(14))
        val tv = android.util.TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        row.setBackgroundResource(tv.resourceId)

        val ic = ImageView(ctx)
        ic.setImageResource(icon)
        ic.setColorFilter(grey)
        row.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val colLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        colLp.marginStart = dp(20)
        row.addView(col, colLp)

        val t = TextView(ctx)
        t.text = title
        t.textSize = 16f
        col.addView(t)
        if (!subtitle.isNullOrEmpty()) {
            val s = TextView(ctx)
            s.text = subtitle
            s.textSize = 12.5f
            s.setTextColor(grey)
            col.addView(s)
        }
        return row
    }

    private fun link(icon: Int, title: String, subtitle: String?, onClick: () -> Unit) {
        val row = baseRow(icon, title, subtitle)
        val ch = ImageView(requireContext())
        ch.setImageResource(R.drawable.ic_chevron)
        ch.setColorFilter(0xFFB0B5BD.toInt())
        row.addView(ch, LinearLayout.LayoutParams(dp(24), dp(24)))
        row.setOnClickListener { onClick() }
        rows.addView(row)
    }

    private fun toggle(
        icon: Int,
        title: String,
        subtitle: String?,
        checked: Boolean,
        onChange: (Boolean) -> Unit
    ) {
        val row = baseRow(icon, title, subtitle)
        val sw = SwitchCompat(requireContext())
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, b -> onChange(b) }
        row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        rows.addView(row)
    }

    private fun themeName() = when (AppSettings.themeMode) {
        1 -> "Light"
        2 -> "Dark"
        else -> "System default"
    }

    private fun reload() {
        rows.removeAllViews()

        section("Calls")
        toggle(R.drawable.ic_volume, "Loudspeaker by default", "Start every call on speaker",
            AppSettings.speakerDefault) { AppSettings.speakerDefault = it }
        toggle(R.drawable.ic_call, "Ringtone", "Ring on incoming calls",
            AppSettings.ringtoneOn) { AppSettings.ringtoneOn = it }
        toggle(R.drawable.ic_record, "Recording reminder", "Warn me before recording a call",
            AppSettings.askRecordConsent) { AppSettings.askRecordConsent = it }

        section("Accounts & network")
        link(R.drawable.ic_person, "SIP accounts", "Server, login, UDP / TCP / TLS") {
            open(AccountsFragment())
        }
        link(R.drawable.ic_network, "Network",
            "STUN ${onOff(AppSettings.useStun)} · ICE ${onOff(AppSettings.useIce)}") { networkDialog() }

        section("Appearance")
        link(R.drawable.ic_theme, "Theme", themeName()) { themeDialog() }
        link(R.drawable.ic_image, "Call screen wallpaper",
            if (Wallpaper.exists(requireContext())) "Custom image" else "Default") { wallpaperDialog() }

        section("Data")
        link(R.drawable.ic_backup, "Backup & restore", "File, Google Drive, daily auto backup") {
            open(BackupFragment())
        }
        link(R.drawable.ic_lock, "Privacy & data", "Clear history, recordings, accounts") {
            privacyDialog()
        }
        link(R.drawable.ic_notifications, "Notifications", "Open system settings") {
            notificationDialog()
        }

        section("Help")
        link(R.drawable.ic_bug, "Call debug info", "Call timeline (send a screenshot if there is a problem)") {
            debugDialog()
        }
        link(R.drawable.ic_info, "About", "My VoIP v1.0") { aboutDialog() }
    }

    private fun open(f: Fragment) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.container, f)
            .addToBackStack(null)
            .commit()
    }

    // ---------- Theme ----------

    private fun themeDialog() {
        val names = arrayOf("System default", "Light", "Dark")
        AlertDialog.Builder(requireContext())
            .setTitle("Theme")
            .setSingleChoiceItems(names, AppSettings.themeMode) { d, which ->
                AppSettings.themeMode = which
                AppSettings.applyTheme()
                d.dismiss()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- Notifications ----------

    private fun notificationDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Notifications")
            .setMessage(
                "Call cholar shomoy je notification dekhay, ar app-er notification " +
                    "on/off phone-er system settings theke thik kora jay."
            )
            .setPositiveButton("Open system settings") { _, _ ->
                try {
                    val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, requireContext().packageName)
                    startActivity(i)
                } catch (e: Exception) {
                    context?.toast("Settings khola gelo na")
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ---------- Privacy & Security ----------

    private fun privacyDialog() {
        val opts = arrayOf(
            "Record-er age shotorkobarta: ${onOff(AppSettings.askRecordConsent)} (change korte chapen)",
            "Call history muchun",
            "Shob recording muchun",
            "Shob account, contact ar favorite muchun"
        )
        AlertDialog.Builder(requireContext())
            .setTitle("Privacy & Security")
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> {
                        AppSettings.askRecordConsent = !AppSettings.askRecordConsent
                        reload()
                        context?.toast("Record-er age shotorkobarta ${onOff(AppSettings.askRecordConsent)}")
                    }
                    1 -> confirm("Shob call history muchben?") { SipEngine.clearLogs() }
                    2 -> confirm("Shob recording muchben?") {
                        SipEngine.recordingsDir().listFiles()?.forEach { it.delete() }
                    }
                    3 -> confirm("Shob account, contact ar favorite muchben? (Age backup nin)") {
                        Store.saveAccounts(emptyList())
                        Store.saveContacts(emptyList())
                        Store.setFavorites(emptySet())
                        Store.defaultAccountId = null
                        SipEngine.applyAccounts()
                    }
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun confirm(title: String, action: () -> Unit) {
        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setPositiveButton("Muchun") { _, _ ->
                action()
                context?.toast("Hoyeche")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Network (NAT) ----------

    private fun networkDialog() {
        val items = arrayOf("STUN (public IP khuje ber kore)", "ICE (aro kora-kori path khuje)")
        val checked = booleanArrayOf(AppSettings.useStun, AppSettings.useIce)
        AlertDialog.Builder(requireContext())
            .setTitle("Network (NAT)")
            .setMultiChoiceItems(items, checked) { _, which, isChecked ->
                if (which == 0) AppSettings.useStun = isChecked
                else AppSettings.useIce = isChecked
            }
            .setPositiveButton("Apply") { _, _ ->
                SipEngine.applyAccounts()
                reload()
                context?.toast("Account abar register hocche")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Wallpaper ----------

    private fun wallpaperDialog() {
        val b = AlertDialog.Builder(requireContext())
            .setTitle("Call screen wallpaper")
            .setMessage("Call cholar shomoy pechone nijer pochondoer chhobi dekhate parben.")
            .setPositiveButton("Chhobi bachai") { _, _ -> wallpaperPicker.launch("image/*") }
            .setNegativeButton("Close", null)
        if (Wallpaper.exists(requireContext())) {
            b.setNeutralButton("Default-e fire") { _, _ ->
                Wallpaper.remove(requireContext())
                reload()
            }
        }
        b.show()
    }

    // ---------- Debug ----------

    private fun debugDialog() {
        val text = SipEngine.debugText()
        AlertDialog.Builder(requireContext())
            .setTitle("Call debug info")
            .setMessage(if (text.isEmpty()) "Ekhono kono call hoyni" else text)
            .setPositiveButton("Close", null)
            .setNeutralButton("Clear") { _, _ -> SipEngine.clearDebug() }
            .show()
    }

    // ---------- About ----------

    private fun aboutDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("My VoIP")
            .setMessage(
                "SIP softphone (Linphone SDK, GPLv3).\n\n" +
                    "Password app-er private storage-e save thake. " +
                    "Call record korar age onno pokkhoer shommoti nin."
            )
            .setPositiveButton("OK", null)
            .show()
    }
}
