package com.myvoip.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import org.linphone.core.Account
import org.linphone.core.Address
import org.linphone.core.AudioDevice
import org.linphone.core.ChatMessage
import org.linphone.core.ChatMessageListenerStub
import org.linphone.core.ChatRoom
import org.linphone.core.Call
import org.linphone.core.CallLog
import org.linphone.core.Core
import org.linphone.core.CoreListenerStub
import org.linphone.core.Factory
import org.linphone.core.MediaEncryption
import org.linphone.core.Reason
import org.linphone.core.RegistrationState
import org.linphone.core.TransportType
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Linphone SDK-r upor ekta wrapper. App-er baki ongsho shudhu eta-i bebohar kore.
 * Core ekbar app shuru-te toiri hoy (MyVoipApp), tai incoming call dhora jay.
 */
object SipEngine {

    interface Listener {
        fun onAccountsChanged() {}
        fun onCallStateChanged(call: Call, state: Call.State) {}
    }

    private lateinit var appContext: Context
    lateinit var core: Core
        private set

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()

    /** saved account id -> status text (Registered, Failed, ...) */
    val regStates = HashMap<String, String>()

    var speakerOn = false
        private set

    // ---- Debug timeline: call-er state gulo somoy shoho (Settings -> Call debug info) ----
    private val debugLog = ArrayList<String>()

    fun logEvent(text: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        debugLog.add("$t  $text")
        while (debugLog.size > 80) debugLog.removeAt(0)
    }

    fun debugText(): String = debugLog.joinToString("\n")

    fun clearDebug() {
        debugLog.clear()
    }

    private val coreListener = object : CoreListenerStub() {
        override fun onAccountRegistrationStateChanged(
            core: Core,
            account: Account,
            state: RegistrationState?,
            message: String
        ) {
            val identity = account.params.identityAddress?.asStringUriOnly()?.lowercase()
            val saved = Store.accounts().firstOrNull {
                identityOf(it).lowercase() == identity
            } ?: return
            val text = when (state) {
                RegistrationState.Ok -> "Registered ✅"
                RegistrationState.Progress -> "Registering..."
                RegistrationState.Failed -> "Failed: $message"
                RegistrationState.Cleared -> "Unregistered"
                RegistrationState.None -> "Not registered"
                else -> state?.name ?: "Unknown"
            }
            regStates[saved.id] = text
            logEvent("REG ${saved.username}: $text")
            notifyAccounts()
        }

        // Onno pokkho SIP message pathale
        override fun onMessageReceived(core: Core, chatRoom: ChatRoom, message: ChatMessage) {
            val text = message.utf8Text ?: return
            if (text.isEmpty()) return
            MessageStore.add(
                Msg(
                    remoteNumber(message.fromAddress), text, System.currentTimeMillis(),
                    false, "SIP", "Received"
                )
            )
        }

        override fun onCallStateChanged(
            core: Core,
            call: Call,
            state: Call.State?,
            message: String
        ) {
            if (state == null) return
            logEvent(
                "CALL ${remoteNumber(call.remoteAddress)} ${call.dir.name}: ${state.name}" +
                    if (message.isNotEmpty()) " ($message)" else ""
            )
            when (state) {
                Call.State.IncomingReceived ->
                    if (Extras.isBlocked(remoteNumber(call.remoteAddress))) {
                        call.decline(Reason.Declined)
                    } else if (Extras.forwardTo.isNotEmpty() && forwardCall(call)) {
                        // onno number-e pathano hoyeche
                    } else {
                        openCallScreen()
                    }
                // Shudhu speaker ON thakle-i output device bodlai, noile phone-er default route-e chhere dei
                Call.State.Connected, Call.State.StreamsRunning ->
                    if (speakerOn) applySpeaker() else routeToHeadset()
                Call.State.Released -> speakerOn = false
                else -> {}
            }
            main.post { listeners.forEach { it.onCallStateChanged(call, state) } }
        }
    }

    /** Incoming call Extras.forwardTo number-e pathay. Shofol hole true. */
    private fun forwardCall(call: Call): Boolean {
        return try {
            val n = Extras.forwardTo.replace(Regex("[\\s\\-().]"), "")
            val acc = Store.accounts().firstOrNull { it.enabled } ?: return false
            val addr = Factory.instance().createAddress(
                if (n.contains("@")) "sip:$n" else "sip:$n@${acc.domain}"
            ) ?: return false
            call.redirectTo(addr)
            true
        } catch (_: Exception) {
            false
        }
    }

    // ---------- Setup ----------

    fun init(ctx: Context) {
        appContext = ctx.applicationContext
        val factory = Factory.instance()
        factory.setDebugMode(false, "MyVoip")
        // Android context abosshoi shesh parameter hishebe dite hobe
        core = factory.createCore(null, null, appContext)
        core.addListener(coreListener)
        core.start()
        applyAccounts()
    }

    fun addListener(l: Listener) {
        listeners.addIfAbsent(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    private fun notifyAccounts() {
        main.post { listeners.forEach { it.onAccountsChanged() } }
    }

    // ---------- Accounts ----------

    private fun identityOf(a: SipAccount) = "sip:${a.username}@${a.domain}"

    private fun transportOf(s: String): TransportType = when (s.uppercase()) {
        "TCP" -> TransportType.Tcp
        "TLS" -> TransportType.Tls
        else -> TransportType.Udp
    }

    /** Saved account gulo theke Linphone-er account list notun kore banay. */
    fun applyAccounts() {
        val factory = Factory.instance()
        core.mediaEncryption = if (AppSettings.useSrtp) MediaEncryption.SRTP else MediaEncryption.None
        core.clearAccounts()
        core.clearAllAuthInfo()
        regStates.clear()

        var defaultAcc: Account? = null
        for (acc in Store.accounts()) {
            if (!acc.enabled) {
                regStates[acc.id] = "Disabled"
                continue
            }
            val authInfo = factory.createAuthInfo(
                acc.username,
                if (acc.authUser.isBlank()) null else acc.authUser,
                acc.password,
                null,
                null,
                acc.domain
            )
            val params = core.createAccountParams()
            params.identityAddress = factory.createAddress(identityOf(acc))
            val server = factory.createAddress("sip:${acc.host}")
            server?.transport = transportOf(acc.transport)
            params.serverAddress = server
            params.isRegisterEnabled = true

            // NAT policy: STUN (ar chaile ICE) -- ek-pokkhiy audio thik korte
            val nat = core.createNatPolicy()
            nat.setStunServer("stun.l.google.com:19302")
            nat.setStunEnabled(AppSettings.useStun)
            nat.setIceEnabled(AppSettings.useIce)
            params.setNatPolicy(nat)

            val account = core.createAccount(params)
            core.addAuthInfo(authInfo)
            core.addAccount(account)
            regStates[acc.id] = "Registering..."
            if (acc.id == Store.defaultAccountId) defaultAcc = account
        }
        core.defaultAccount = defaultAcc ?: core.accountList.firstOrNull()
        notifyAccounts()
    }

    private fun findCoreAccount(saved: SipAccount): Account? {
        val wanted = identityOf(saved).lowercase()
        return core.accountList.firstOrNull {
            it.params.identityAddress?.asStringUriOnly()?.lowercase() == wanted
        }
    }

    /** Network bodle (Wi-Fi <-> data) abar register korte. */
    fun refreshRegistration() {
        core.refreshRegisters()
    }

    // ---------- Calls ----------

    /** Notun incoming call (Call Waiting) age dekhay, tarpor cholman call. */
    fun activeCall(): Call? =
        core.calls.firstOrNull { it.state == Call.State.IncomingReceived }
            ?: core.currentCall ?: core.calls.firstOrNull()

    fun callCount(): Int = core.callsNb

    /** Hold-e thaka onno call-e jay (Swap). */
    fun swapCalls() {
        val cur = core.currentCall
        val other = core.calls.firstOrNull {
            it != cur && (it.state == Call.State.Paused || it.state == Call.State.Pausing)
        }
        other?.resume()
    }

    /** Dui call ek-sathe conference (Merge). */
    fun mergeCalls() {
        core.addAllToConference()
    }

    /** Call shuru kore. Kono error hole error-er lekha return kore, shofol hole null. */
    fun call(input: String, accountId: String?): String? {
        val raw = input.trim()
        if (raw.isEmpty()) return "Number din"
        // Phone contact-er number-e space/dash thake (+880 1712-345678), SIP-er jonno muche dei
        val number = if (raw.contains("@") || raw.startsWith("sip:")) {
            raw
        } else {
            raw.replace(Regex("[\\s\\-().]"), "")
        }

        val all = Store.accounts().filter { it.enabled }
        val saved = all.firstOrNull { it.id == accountId }
            ?: all.firstOrNull { it.id == Store.defaultAccountId }
            ?: all.firstOrNull()
            ?: return "Age Accounts tab-e giye SIP account joge korun"

        try {
            val coreAcc = findCoreAccount(saved)
            if (coreAcc != null) core.defaultAccount = coreAcc

            val target = when {
                number.startsWith("sip:") -> number
                number.contains("@") -> "sip:$number"
                else -> "sip:$number@${saved.domain}"
            }
            val remote = Factory.instance().createAddress(target) ?: return "Number thik na"
            val params = core.createCallParams(null) ?: return "Call params toiri hoyni"
            speakerOn = AppSettings.speakerDefault
            params.recordFile = newRecordPath(number)

            val call = core.inviteAddressWithParams(remote, params)
                ?: return "Call shuru kora gelo na"
            openCallScreen()
            return null
        } catch (e: Exception) {
            return "Error: ${e.message}"
        }
    }

    fun answer(call: Call) {
        speakerOn = AppSettings.speakerDefault
        val params = core.createCallParams(call)
        if (params != null) {
            params.recordFile = newRecordPath(remoteNumber(call.remoteAddress))
            call.acceptWithParams(params)
        } else {
            call.accept()
        }
    }

    fun hangup() {
        activeCall()?.terminate()
    }

    fun openCallScreen() {
        val i = Intent(appContext, CallActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        appContext.startActivity(i)
    }

    // ---------- SIP Messages ----------

    /**
     * SIP account diye message pathay. Error hole error-er lekha return kore.
     * onFailed: provider message dhorte na parle (Not delivered) main thread-e dake.
     */
    fun sendSipMessage(number: String, text: String, onFailed: (Msg) -> Unit): String? {
        val n = number.trim().replace(Regex("[\\s\\-().]"), "")
        if (n.isEmpty()) return "Number din"
        val all = Store.accounts().filter { it.enabled }
        val saved = all.firstOrNull { it.id == Store.defaultAccountId }
            ?: all.firstOrNull()
            ?: return "Age SIP account joge korun"
        try {
            val coreAcc = findCoreAccount(saved) ?: return "Account ekhono register hoyni"
            core.defaultAccount = coreAcc
            val local = coreAcc.params.identityAddress ?: return "Account-er thikana paoa jayni"
            val remote = Factory.instance().createAddress(
                if (n.contains("@")) "sip:$n" else "sip:$n@${saved.domain}"
            ) ?: return "Number thik na"

            @Suppress("DEPRECATION")
            val room = core.getChatRoom(remote, local) ?: return "Chat toiri kora gelo na"
            val chatMsg = room.createMessageFromUtf8(text)
            val rec = Msg(n, text, System.currentTimeMillis(), true, "SIP", "Sending...")
            MessageStore.add(rec)

            chatMsg.addListener(object : ChatMessageListenerStub() {
                override fun onMsgStateChanged(message: ChatMessage, state: ChatMessage.State?) {
                    when (state) {
                        ChatMessage.State.Delivered,
                        ChatMessage.State.DeliveredToUser,
                        ChatMessage.State.Displayed -> MessageStore.setStatus(rec, "Delivered")
                        ChatMessage.State.NotDelivered -> {
                            MessageStore.setStatus(rec, "Not delivered")
                            main.post { onFailed(rec) }
                        }
                        else -> {}
                    }
                }
            })
            chatMsg.send()
            return null
        } catch (e: Exception) {
            return "Error: ${e.message}"
        }
    }

    // ---------- Audio ----------

    fun setSpeaker(on: Boolean) {
        speakerOn = on
        applySpeaker()
    }

    /** Bluetooth / wired headset thakle auto oitate audio pathay. */
    private fun routeToHeadset() {
        try {
            val dev = core.audioDevices.firstOrNull {
                it.type == AudioDevice.Type.Bluetooth ||
                    it.type == AudioDevice.Type.Headset ||
                    it.type == AudioDevice.Type.Headphones
            }
            if (dev != null && core.outputAudioDevice?.type != dev.type) core.outputAudioDevice = dev
        } catch (_: Exception) {
        }
    }

    private fun applySpeaker() {
        val wanted = if (speakerOn) AudioDevice.Type.Speaker else AudioDevice.Type.Earpiece
        val dev = core.audioDevices.firstOrNull { it.type == wanted }
        if (dev != null) core.outputAudioDevice = dev
    }

    // ---------- Recording ----------

    fun recordingsDir(): File {
        val base = appContext.getExternalFilesDir(null) ?: appContext.filesDir
        val dir = File(base, "recordings")
        dir.mkdirs()
        return dir
    }

    private fun newRecordPath(remote: String): String {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safe = remote.replace(Regex("[^A-Za-z0-9+]"), "_")
        return File(recordingsDir(), "rec_${ts}_$safe.wav").absolutePath
    }

    fun isRecording(call: Call): Boolean = call.params.isRecording

    /** Recording chalu/bondho kore. Notun obostha (true = recording hocche) return kore. */
    fun toggleRecording(call: Call): Boolean {
        if (call.params.isRecording) call.stopRecording() else call.startRecording()
        return call.params.isRecording
    }

    // ---------- Call history ----------

    fun callLogs(): List<CallLog> = core.callLogs.toList()

    fun removeLog(log: CallLog) {
        core.removeCallLog(log)
    }

    fun clearLogs() {
        core.clearCallLogs()
    }

    // ---------- Name helpers ----------

    fun remoteNumber(addr: Address): String = addr.username ?: addr.asStringUriOnly()

    /** Contact list-e thakle "Name (number)", noile shudhu number. */
    fun labelFor(addr: Address): String {
        val num = remoteNumber(addr)
        val name = PhoneContacts.nameFor(num)
        return if (name != null) "$name ($num)" else num
    }
}
