package com.myvoip.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/** Phone-er nijossho contact list (shudhu pora jay, edit hoy na). */
object PhoneContacts {

    @Volatile
    var list: List<Contact> = emptyList()
        private set

    // last 10 digit -> naam. Row-por-row linear khoja na kore ek jhotkay naam pawar jonno.
    @Volatile
    private var index: Map<String, String> = emptyMap()

    private fun keyOf(number: String): String {
        val d = number.filter { it.isDigit() }
        return if (d.length > 10) d.takeLast(10) else d
    }

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    fun load(ctx: Context) {
        if (!hasPermission(ctx)) {
            list = emptyList()
            index = emptyMap()
            return
        }
        val result = ArrayList<Contact>()
        val seen = HashSet<String>()
        try {
            val phone = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val cursor = ctx.contentResolver.query(
                phone,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
            )
            cursor?.use { c ->
                val nameIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (c.moveToNext()) {
                    val name = c.getString(nameIdx) ?: continue
                    val number = c.getString(numIdx) ?: continue
                    val key = name + "|" + number.filter { it.isDigit() }
                    if (seen.add(key)) {
                        result.add(Contact(id = "phone:$key", name = name, number = number))
                    }
                }
            }
        } catch (e: Exception) {
            // permission/provider somossa hole khali list
        }
        val idx = HashMap<String, String>()
        for (c in result) {
            val k = keyOf(c.number)
            if (k.length >= 7 && !idx.containsKey(k)) idx[k] = c.name
        }
        index = idx
        list = result
    }

    private fun digits(s: String) = s.filter { it.isDigit() }

    /** +880 1712... ar 01712... ek-i number dhorte last 10 digit milay. */
    fun sameNumber(a: String, b: String): Boolean {
        val x = digits(a)
        val y = digits(b)
        if (x.isEmpty() || y.isEmpty()) return false
        if (x == y) return true
        if (x.length < 7 || y.length < 7) return false
        val n = minOf(10, x.length, y.length)
        return x.takeLast(n) == y.takeLast(n)
    }

    /** App-er contact + phone-er contact dujon-er modhye number-er naam khuje. */
    fun nameFor(number: String): String? {
        Store.contacts().firstOrNull { sameNumber(it.number, number) }?.let { return it.name }
        val k = keyOf(number)
        if (k.length < 7) return list.firstOrNull { sameNumber(it.number, number) }?.name
        return index[k]
    }
}
