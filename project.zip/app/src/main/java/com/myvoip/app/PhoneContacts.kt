package com.myvoip.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/** Phone-er nijossho contact list (shudhu pora jay, edit hoy na). */
object PhoneContacts {

    @Volatile
    var list: List<Contact> = emptyList()
        private set

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    fun load(ctx: Context) {
        if (!hasPermission(ctx)) {
            list = emptyList()
            return
        }
        val result = ArrayList<Contact>()
        val seen = HashSet<String>()
        try {
            val phone = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val cursor = ctx.contentResolver.query(
                phone,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
            )
            cursor?.use { c ->
                val nameIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (c.moveToNext()) {
                    val name = c.getString(nameIdx) ?: continue
                    val number = c.getString(numIdx) ?: continue
                    val key = name + "|" + number.filter { it.isDigit() }
                    if (seen.add(key)) {
                        result.add(Contact(id = "phone:$key", name = name, number = number))
                    }
                }
            }
        } catch (e: Exception) {
            // permission/provider somossa hole khali list
        }
        list = result
    }

    private fun digits(s: String) = s.filter { it.isDigit() }

    /** +880 1712... ar 01712... ek-i number dhorte last 10 digit milay. */
    fun sameNumber(a: String, b: String): Boolean {
        val x = digits(a)
        val y = digits(b)
        if (x.isEmpty() || y.isEmpty()) return false
        if (x == y) return true
        if (x.length < 7 || y.length < 7) return false
        val n = minOf(10, x.length, y.length)
        return x.takeLast(n) == y.takeLast(n)
    }

    /** App-er contact + phone-er contact dujon-er modhye number-er naam khuje. */
    fun nameFor(number: String): String? {
        Store.contacts().firstOrNull { sameNumber(it.number, number) }?.let { return it.name }
        return list.firstOrNull { sameNumber(it.number, number) }?.name
    }
}
