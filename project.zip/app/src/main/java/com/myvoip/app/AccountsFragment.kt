package com.myvoip.app

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import java.util.UUID

class AccountsFragment : Fragment(R.layout.fragment_list), SipEngine.Listener {

    private lateinit var adapter: TwoLineAdapter
    private var items: List<SipAccount> = emptyList()
    private val transports = listOf("UDP", "TCP", "TLS")

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.findViewById<TextView>(R.id.tvTitle).text = "SIP Accounts"
        view.findViewById<TextView>(R.id.tvEmpty).text =
            "Kono account nei.\nAdd account chepe provider-er tothyo din."

        val btn = view.findViewById<Button>(R.id.btnAction)
        btn.text = "Add account"
        btn.setOnClickListener { showForm(null) }

        val list = view.findViewById<ListView>(R.id.list)
        adapter = TwoLineAdapter(requireContext(), emptyList())
        list.adapter = adapter
        list.emptyView = view.findViewById(R.id.tvEmpty)

        list.setOnItemClickListener { _, _, pos, _ ->
            val a = items.getOrNull(pos) ?: return@setOnItemClickListener
            showOptions(a)
        }
    }

    override fun onStart() {
        super.onStart()
        SipEngine.addListener(this)
        reload()
    }

    override fun onStop() {
        super.onStop()
        SipEngine.removeListener(this)
    }

    override fun onAccountsChanged() {
        reload()
    }

    private fun reload() {
        items = Store.accounts()
        val def = Store.defaultAccountId
        adapter.rows = items.map { a ->
            val star = if (a.id == def) " ★" else ""
            Row(
                a.label.ifBlank { a.username } + star,
                "${a.username}@${a.host} · ${a.transport} · ${SipEngine.regStates[a.id] ?: "—"}"
            )
        }
        adapter.notifyDataSetChanged()
    }

    private fun showOptions(a: SipAccount) {
        val opts = arrayOf(
            "Edit",
            "Make default",
            if (a.enabled) "Disable" else "Enable",
            "Delete"
        )
        AlertDialog.Builder(requireContext())
            .setTitle(a.label.ifBlank { a.username })
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> showForm(a)
                    1 -> {
                        Store.defaultAccountId = a.id
                        SipEngine.applyAccounts()
                        reload()
                    }
                    2 -> save(a.copy(enabled = !a.enabled))
                    3 -> AlertDialog.Builder(requireContext())
                        .setTitle("Account muchben?")
                        .setPositiveButton("Muchun") { _, _ -> delete(a) }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
            .show()
    }

    private fun showForm(existing: SipAccount?) {
        formDialog(
            requireContext(),
            if (existing == null) "Add SIP account" else "Edit account",
            listOf(
                Field("Label (jemon: Office)", existing?.label ?: ""),
                Field("Host / Domain (sip.example.com ba sip.example.com:5060)", existing?.host ?: ""),
                Field("Username", existing?.username ?: ""),
                Field("Password", existing?.password ?: "", password = true),
                Field("Auth username (shudhu provider bolle)", existing?.authUser ?: "")
            ),
            transports,
            transports.indexOf(existing?.transport ?: "UDP").coerceAtLeast(0)
        ) { v, choice ->
            if (v[1].isEmpty() || v[2].isEmpty() || v[3].isEmpty()) {
                context?.toast("Host, username ar password dorkar")
                return@formDialog
            }
            val acc = SipAccount(
                id = existing?.id ?: UUID.randomUUID().toString(),
                label = if (v[0].isEmpty()) v[2] else v[0],
                host = v[1],
                username = v[2],
                password = v[3],
                authUser = v[4],
                transport = transports[choice],
                enabled = existing?.enabled ?: true
            )
            save(acc)
        }
    }

    private fun save(acc: SipAccount) {
        val list = Store.accounts().toMutableList()
        val idx = list.indexOfFirst { it.id == acc.id }
        if (idx >= 0) list[idx] = acc else list.add(acc)
        Store.saveAccounts(list)
        if (list.none { it.id == Store.defaultAccountId }) Store.defaultAccountId = acc.id
        SipEngine.applyAccounts()
        reload()
    }

    private fun delete(acc: SipAccount) {
        val list = Store.accounts().filter { it.id != acc.id }
        Store.saveAccounts(list)
        if (Store.defaultAccountId == acc.id) Store.defaultAccountId = list.firstOrNull()?.id
        SipEngine.applyAccounts()
        reload()
    }
}
