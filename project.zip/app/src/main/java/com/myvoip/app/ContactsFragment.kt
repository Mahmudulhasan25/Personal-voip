package com.myvoip.app

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import java.util.UUID

class ContactsFragment : Fragment(R.layout.fragment_list) {

    private lateinit var adapter: TwoLineAdapter
    private var contacts: List<Contact> = emptyList()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.findViewById<TextView>(R.id.tvTitle).text = "Contacts"
        view.findViewById<TextView>(R.id.tvEmpty).text = "Kono contact nei. Add contact chapen."

        val btn = view.findViewById<Button>(R.id.btnAction)
        btn.text = "Add contact"
        btn.setOnClickListener { showForm(null) }

        val list = view.findViewById<ListView>(R.id.list)
        adapter = TwoLineAdapter(requireContext(), emptyList())
        list.adapter = adapter
        list.emptyView = view.findViewById(R.id.tvEmpty)

        list.setOnItemClickListener { _, _, pos, _ ->
            val c = contacts.getOrNull(pos) ?: return@setOnItemClickListener
            showOptions(c)
        }
    }

    override fun onStart() {
        super.onStart()
        reload()
    }

    private fun reload() {
        contacts = Store.contacts().sortedBy { it.name.lowercase() }
        adapter.rows = contacts.map { Row(it.name, it.number) }
        adapter.notifyDataSetChanged()
    }

    private fun showOptions(c: Contact) {
        AlertDialog.Builder(requireContext())
            .setTitle(c.name)
            .setItems(arrayOf("Call", "Edit", "Delete")) { _, which ->
                when (which) {
                    0 -> (requireActivity() as MainActivity).ensureMic {
                        val err = SipEngine.call(c.number, null)
                        if (err != null) context?.toast(err)
                    }
                    1 -> showForm(c)
                    2 -> AlertDialog.Builder(requireContext())
                        .setTitle("${c.name}-ke muchben?")
                        .setPositiveButton("Muchun") { _, _ ->
                            Store.saveContacts(Store.contacts().filter { it.id != c.id })
                            reload()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
            .show()
    }

    private fun showForm(existing: Contact?) {
        formDialog(
            requireContext(),
            if (existing == null) "Add contact" else "Edit contact",
            listOf(
                Field("Name", existing?.name ?: ""),
                Field("Number", existing?.number ?: "", phone = true)
            )
        ) { v, _ ->
            if (v[0].isEmpty() || v[1].isEmpty()) {
                context?.toast("Name ar number dujon-i dorkar")
                return@formDialog
            }
            val c = Contact(id = existing?.id ?: UUID.randomUUID().toString(), name = v[0], number = v[1])
            val list = Store.contacts().toMutableList()
            val idx = list.indexOfFirst { it.id == c.id }
            if (idx >= 0) list[idx] = c else list.add(c)
            Store.saveContacts(list)
            reload()
        }
    }
}
