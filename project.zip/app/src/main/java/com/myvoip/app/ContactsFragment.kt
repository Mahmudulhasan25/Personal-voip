package com.myvoip.app

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import java.util.UUID

// Ekbar permission chaowar por ei process-e abar bar bar chabe na
private var askedContactsPermission = false

class ContactsFragment : Fragment(R.layout.fragment_list) {

    /** fromPhone = true hole phone-er contact (shudhu call kora jay, edit/delete na). */
    private class Entry(val contact: Contact, val fromPhone: Boolean)

    private lateinit var adapter: TwoLineAdapter
    private var shown: List<Entry> = emptyList()
    private var query = ""

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            context?.let { PhoneContacts.load(it) }
            reload()
        } else {
            showPermissionHelp()
        }
    }

    // Phone-er contact picker: permission lage na, user ekta contact beche dey
    private val pickLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        val uri = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && uri != null) importPicked(uri)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.findViewById<TextView>(R.id.tvTitle).text = "Contacts"

        val btn = view.findViewById<Button>(R.id.btnAction)
        btn.text = "Add"
        btn.setOnClickListener { showForm(null) }

        val btn2 = view.findViewById<Button>(R.id.btnAction2)
        btn2.text = "From phone"
        btn2.setOnClickListener { showFromPhone() }

        val etSearch = view.findViewById<EditText>(R.id.etSearch)
        etSearch.visibility = View.VISIBLE
        etSearch.doAfterTextChanged {
            query = it?.toString() ?: ""
            reload()
        }

        val list = view.findViewById<ListView>(R.id.list)
        adapter = TwoLineAdapter(requireContext(), emptyList())
        list.adapter = adapter
        list.emptyView = view.findViewById(R.id.tvEmpty)

        list.setOnItemClickListener { _, _, pos, _ ->
            val e = shown.getOrNull(pos) ?: return@setOnItemClickListener
            showOptions(e)
        }
    }

    override fun onStart() {
        super.onStart()
        val ctx = requireContext()
        if (PhoneContacts.hasPermission(ctx)) {
            // Pechone reload kore tarpor list dekhai, jate tab khulte atke na jay
            val app = ctx.applicationContext
            Thread {
                PhoneContacts.load(app)
                activity?.runOnUiThread { if (isAdded) reload() }
            }.start()
        } else if (!askedContactsPermission) {
            askedContactsPermission = true
            permLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
        reload()
    }

    private fun reload() {
        val v = view ?: return
        val has = PhoneContacts.hasPermission(requireContext())

        // Header-e dekhay phone theke koyta contact pawa gelo (jachai-er jonno)
        v.findViewById<TextView>(R.id.tvTitle).text =
            if (has) "Contacts (${PhoneContacts.list.size} phone)" else "Contacts"
        v.findViewById<TextView>(R.id.tvEmpty).text =
            if (has) "Kono contact nei"
            else "Phone-er contact dekhte permission dorkar.\n'From phone' chapen."
        v.findViewById<Button>(R.id.btnAction2).visibility =
            if (has) View.GONE else View.VISIBLE

        val q = query.trim().lowercase()
        val all = Store.contacts().map { Entry(it, false) } +
            PhoneContacts.list.map { Entry(it, true) }
        val hidden = hiddenPhone()
        shown = all
            .filter { it.fromPhone.not() || PhoneKey.of(it.contact.number) !in hidden }
            .filter {
                q.isEmpty() ||
                    it.contact.name.lowercase().contains(q) ||
                    it.contact.number.contains(q)
            }
            .sortedWith(
                compareByDescending<Entry> { Store.isFavorite(it.contact.number) }
                    .thenBy { it.contact.name.lowercase() }
            )
        adapter.rows = shown.map {
            val star = if (Store.isFavorite(it.contact.number)) "★ " else ""
            Row(
                nameWithNumber(star + it.contact.name, it.contact.number),
                if (it.fromPhone) "Phone" else "My VoIP"
            )
        }
        adapter.notifyDataSetChanged()
    }

    // ---------- Phone theke ----------

    private fun showFromPhone() {
        AlertDialog.Builder(requireContext())
            .setTitle("Phone-er contact")
            .setItems(
                arrayOf(
                    "Shob contact dekhan (permission lagbe)",
                    "Ekta contact beche nin (permission lagbe na)"
                )
            ) { _, which ->
                if (which == 0) permLauncher.launch(Manifest.permission.READ_CONTACTS)
                else pickOne()
            }
            .show()
    }

    private fun pickOne() {
        try {
            pickLauncher.launch(
                Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
            )
        } catch (e: ActivityNotFoundException) {
            context?.toast("Phone-er contact app paoa jayni")
        }
    }

    private fun importPicked(uri: Uri) {
        try {
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            requireContext().contentResolver.query(uri, projection, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val name = c.getString(0) ?: ""
                    val number = c.getString(1) ?: ""
                    if (number.isNotEmpty()) {
                        val list = Store.contacts().toMutableList()
                        list.add(Contact(name = name.ifEmpty { number }, number = number))
                        Store.saveContacts(list)
                        reload()
                        context?.toast("$name joge hoyeche")
                    }
                }
            }
        } catch (e: Exception) {
            context?.toast("Contact neya gelo na: ${e.message}")
        }
    }

    private fun showPermissionHelp() {
        AlertDialog.Builder(requireContext())
            .setTitle("Contacts permission paoa jayni")
            .setMessage(
                "Settings -> Apps -> My VoIP -> Permissions -> Contacts -> Allow korun. " +
                    "Ba 'From phone' theke ekta ekta kore contact beche nite paren."
            )
            .setPositiveButton("Open Settings") { _, _ ->
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", requireContext().packageName, null)
                        )
                    )
                } catch (e: Exception) {
                    context?.toast("Settings khola gelo na")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Contact options ----------

    private fun call(c: Contact) {
        (requireActivity() as MainActivity).ensureMic {
            val err = SipEngine.call(c.number, null)
            if (err != null) context?.toast(err)
        }
    }

    private fun showOptions(e: Entry) {
        val c = e.contact
        val favLabel = if (Store.isFavorite(c.number)) "☆ Remove from favorites" else "★ Add to favorites"
        val opts = if (e.fromPhone) {
            arrayOf("SIP call", "SIM call", "Edit", favLabel)
        } else {
            arrayOf("SIP call", "SIM call", "Edit", "Delete", favLabel)
        }
        AlertDialog.Builder(requireContext())
            .setTitle(c.name)
            .setItems(opts) { _, which ->
                if (which == opts.size - 1) {
                    Store.toggleFavorite(c.number)
                    reload()
                    return@setItems
                }
                if (e.fromPhone) {
                    when (which) {
                        0 -> call(c)
                        1 -> (requireActivity() as MainActivity).simCall(c.number)
                        2 -> showForm(c, phoneOrigin = true)
                    }
                } else {
                    when (which) {
                        0 -> call(c)
                        1 -> (requireActivity() as MainActivity).simCall(c.number)
                        2 -> showForm(c)
                        3 -> AlertDialog.Builder(requireContext())
                            .setTitle("${c.name}-ke muchben?")
                            .setPositiveButton("Muchun") { _, _ ->
                                Store.saveContacts(Store.contacts().filter { it.id != c.id })
                                reload()
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                }
            }
            .show()
    }

    private object PhoneKey {
        fun of(n: String): String = n.filter { it.isDigit() }.takeLast(10)
    }

    private fun hiddenPhone(): Set<String> =
        requireContext().getSharedPreferences("myvoip_hidden", android.content.Context.MODE_PRIVATE)
            .getStringSet("phone", emptySet()) ?: emptySet()

    private fun hidePhone(number: String) {
        val sp = requireContext().getSharedPreferences("myvoip_hidden", android.content.Context.MODE_PRIVATE)
        val s = HashSet(sp.getStringSet("phone", emptySet()) ?: emptySet())
        s.add(PhoneKey.of(number))
        sp.edit().putStringSet("phone", s).apply()
    }

    /** phoneOrigin = true: phone-er contact edit hole ta My VoIP-te copy hoye edit hoy, ager ta lukano thake. */
    private fun showForm(existing: Contact?, phoneOrigin: Boolean = false) {
        formDialog(
            requireContext(),
            if (existing == null) "Add contact" else "Edit contact",
            listOf(
                Field("Name", existing?.name ?: ""),
                Field("Number", existing?.number ?: "", phone = true)
            )
        ) { v, _ ->
            if (v[0].isEmpty() || v[1].isEmpty()) {
                context?.toast("Name ar number dujon-i dorkar")
                return@formDialog
            }
            if (phoneOrigin && existing != null) hidePhone(existing.number)
            val c = Contact(
                id = if (phoneOrigin) UUID.randomUUID().toString() else existing?.id ?: UUID.randomUUID().toString(),
                name = v[0],
                number = v[1]
            )
            val list = Store.contacts().toMutableList()
            val idx = list.indexOfFirst { it.id == c.id }
            if (idx >= 0) list[idx] = c else list.add(c)
            Store.saveContacts(list)
            reload()
        }
    }
}
