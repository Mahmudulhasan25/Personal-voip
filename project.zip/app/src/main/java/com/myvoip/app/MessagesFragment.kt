package com.myvoip.app

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment

/** Messages ta: shob conversation-er list. + chaple notun message. */
class MessagesFragment : Fragment(R.layout.fragment_messages) {

    private lateinit var adapter: TwoLineAdapter
    private var shown: List<Msg> = emptyList()
    private lateinit var tvEmpty: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val list = view.findViewById<ListView>(R.id.list)
        tvEmpty = view.findViewById(R.id.tvEmpty)
        adapter = TwoLineAdapter(requireContext(), emptyList())
        list.adapter = adapter

        list.setOnItemClickListener { _, _, pos, _ -> openChat(shown[pos].peer) }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val m = shown[pos]
            AlertDialog.Builder(requireContext())
                .setTitle("Conversation muchhe felben?")
                .setMessage(PhoneContacts.nameFor(m.peer) ?: m.peer)
                .setPositiveButton("Delete") { _, _ ->
                    MessageStore.deleteConversation(MessageStore.keyOf(m.peer))
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }

        view.findViewById<ImageView>(R.id.btnNew).setOnClickListener {
            val ctx = requireContext()
            val et = android.widget.EditText(ctx)
            et.hint = "Number"
            et.inputType = android.text.InputType.TYPE_CLASS_PHONE
            val pad = (20 * resources.displayMetrics.density).toInt()
            et.setPadding(pad, pad, pad, pad)
            AlertDialog.Builder(ctx)
                .setTitle("Notun message")
                .setView(et)
                .setPositiveButton("Next") { _, _ ->
                    val n = et.text.toString().trim()
                    if (n.isEmpty()) ctx.toast("Number din") else openChat(n)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun openChat(peer: String) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.container, ChatFragment.newInstance(peer))
            .addToBackStack(null)
            .commit()
    }

    override fun onStart() {
        super.onStart()
        MessageStore.onChange = { reload() }
        reload()
    }

    override fun onStop() {
        MessageStore.onChange = null
        super.onStop()
    }

    private fun reload() {
        if (view == null) return
        shown = MessageStore.conversations()
        adapter.rows = shown.map { m ->
            val name = PhoneContacts.nameFor(m.peer)
            val prefix = if (m.outgoing) "You: " else ""
            Row(
                name ?: m.peer,
                "$prefix${m.text}\n${m.via} · ${fmtDhaka(m.time)}"
            )
        }
        adapter.notifyDataSetChanged()
        tvEmpty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
    }
}
