package com.myvoip.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BackupFragment : Fragment(R.layout.fragment_backup) {

    private lateinit var tvAutoStatus: TextView

    // Backup file save: user nije jayga (jemon Google Drive) beche nen
    private val createDoc = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) writeBackup(uri)
    }

    // Restore file nirbachon
    private val openDoc = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) readBackup(uri)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        tvAutoStatus = view.findViewById(R.id.tvAutoStatus)

        view.findViewById<Button>(R.id.btnBackup).setOnClickListener {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            createDoc.launch("myvoip_backup_$stamp.json")
        }

        view.findViewById<Button>(R.id.btnRestore).setOnClickListener {
            confirmRestore { openDoc.launch(arrayOf("*/*")) }
        }

        val chk = view.findViewById<CheckBox>(R.id.chkAuto)
        chk.isChecked = AppSettings.autoBackup
        chk.setOnCheckedChangeListener { _, checked ->
            AppSettings.autoBackup = checked
            context?.let { BackupScheduler.apply(it) }
            updateStatus()
        }

        view.findViewById<Button>(R.id.btnAutoNow).setOnClickListener {
            try {
                Backup.autoBackup(requireContext())
                context?.toast("Backup hoyeche")
            } catch (e: Exception) {
                context?.toast("Backup hoyni: ${e.message}")
            }
            updateStatus()
        }

        view.findViewById<Button>(R.id.btnRestoreAuto).setOnClickListener {
            val f = Backup.latestAutoBackup(requireContext())
            if (f == null) {
                context?.toast("Kono auto-backup nei")
            } else {
                confirmRestore {
                    val err = Backup.restore(f.readText())
                    context?.toast(err ?: "Restore hoyeche")
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        updateStatus()
    }

    private fun updateStatus() {
        val ctx: Context = context ?: return
        val last = AppSettings.lastAutoBackup
        val lastText = if (last == 0L) {
            "Ekhono auto-backup hoyni"
        } else {
            "Shesh auto-backup: " +
                SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("Asia/Dhaka")
                }.format(Date(last))
        }
        val state = if (AppSettings.autoBackup) "Chalu" else "Bondho"
        val files = Backup.backupDir(ctx).listFiles()?.size ?: 0
        tvAutoStatus.text = "$state · $lastText · $files ta file"
    }

    private fun confirmRestore(action: () -> Unit) {
        AlertDialog.Builder(requireContext())
            .setTitle("Restore korben?")
            .setMessage("Ekhon-kar SIP account, contact ar settings backup-er tothyo diye bodle jabe.")
            .setPositiveButton("Restore") { _, _ -> action() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun writeBackup(uri: Uri) {
        val ctx = context ?: return
        try {
            ctx.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(Backup.export().toByteArray())
            }
            ctx.toast("Backup save hoyeche")
        } catch (e: Exception) {
            ctx.toast("Backup hoyni: ${e.message}")
        }
    }

    private fun readBackup(uri: Uri) {
        val ctx = context ?: return
        try {
            val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (text == null) {
                ctx.toast("File pora gelo na")
                return
            }
            val err = Backup.restore(text)
            ctx.toast(err ?: "Restore hoyeche")
        } catch (e: Exception) {
            ctx.toast("Restore hoyni: ${e.message}")
        }
    }
}
