package com.myvoip.app

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import org.linphone.core.Call
import org.linphone.core.CallLog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Mul screen: upore Recents (filter, search, settings), niche dial pad. */
class HomeFragment : Fragment(R.layout.fragment_home), SipEngine.Listener {

    private lateinit var adapter: TwoLineAdapter
    private lateinit var tvTitle: TextView
    private lateinit var tvReg: TextView
    private lateinit var tvNumber: TextView
    private lateinit var btnDelete: View
    private lateinit var btnReturn: View
    private lateinit var padPanel: View
    private lateinit var etSearch: EditText

    private var logs: List<CallLog> = emptyList()
    private var accounts: List<SipAccount> = emptyList()
    private var accIndex = 0
    private var number = StringBuilder()

    // 0 = All, 1 = Missed, 2 = Outgoing
    private var filter = 0
    private var query = ""

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        tvTitle = view.findViewById(R.id.tvTitle)
        tvReg = view.findViewById(R.id.tvReg)
        tvNumber = view.findViewById(R.id.tvNumber)
        btnDelete = view.findViewById(R.id.btnDelete)
        btnReturn = view.findViewById(R.id.btnReturn)
        padPanel = view.findViewById(R.id.padPanel)
        etSearch = view.findViewById(R.id.etSearch)

        // ---- Header icons ----
        view.findViewById<View>(R.id.btnSettings).setOnClickListener {
            (requireActivity() as MainActivity).openSettings()
        }
        view.findViewById<View>(R.id.btnFilter).setOnClickListener { anchor ->
            val m = PopupMenu(requireContext(), anchor)
            m.menu.add(0, 1, 0, "Missed calls")
            m.menu.add(0, 2, 1, "Outgoing calls")
            m.menu.add(0, 0, 2, "All calls")
            m.setOnMenuItemClickListener { item ->
                filter = item.itemId
                reload()
                true
            }
            m.show()
        }
        view.findViewById<View>(R.id.btnSearch).setOnClickListener {
            if (etSearch.visibility == View.VISIBLE) {
                etSearch.setText("")
                etSearch.visibility = View.GONE
            } else {
                etSearch.visibility = View.VISIBLE
                etSearch.requestFocus()
            }
        }
        etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                query = s?.toString()?.trim()?.lowercase() ?: ""
                reload()
            }

            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        // ---- Recents list ----
        val list = view.findViewById<ListView>(R.id.list)
        adapter = TwoLineAdapter(requireContext(), emptyList())
        list.adapter = adapter
        list.emptyView = view.findViewById(R.id.tvEmpty)
        list.setOnItemClickListener { _, _, pos, _ ->
            val log = logs.getOrNull(pos) ?: return@setOnItemClickListener
            showDetails(log)
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val log = logs.getOrNull(pos) ?: return@setOnItemLongClickListener true
            confirmDelete(log)
            true
        }

        // ---- Account line ----
        tvReg.setOnClickListener {
            if (accounts.size > 1) {
                AlertDialog.Builder(requireContext())
                    .setTitle("Kon account diye call?")
                    .setItems(accounts.map { it.label.ifBlank { it.username } }.toTypedArray()) { _, i ->
                        accIndex = i
                        updateStatus()
                    }
                    .show()
            }
        }
        btnReturn.setOnClickListener { SipEngine.openCallScreen() }

        // ---- Dial pad ----
        buildPad(view.findViewById(R.id.pad))
        tvNumber.setOnLongClickListener { anchor ->
            val m = PopupMenu(requireContext(), anchor)
            m.menu.add(0, 1, 0, "Paste")
            m.menu.add(0, 2, 1, "Copy")
            m.menu.add(0, 3, 2, "Clear")
            m.setOnMenuItemClickListener { item ->
                val cm = requireContext().getSystemService(android.content.ClipboardManager::class.java)
                when (item.itemId) {
                    1 -> {
                        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(requireContext())?.toString() ?: ""
                        number.append(t.filter { it.isDigit() || it == '+' || it == '*' || it == '#' })
                    }
                    2 -> if (number.isNotEmpty()) {
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("number", number.toString()))
                        context?.toast("Copy hoyeche")
                    }
                    else -> number.clear()
                }
                showNumber()
                true
            }
            m.show()
            true
        }
        btnDelete.setOnClickListener {
            if (number.isNotEmpty()) number.deleteCharAt(number.length - 1)
            showNumber()
        }
        btnDelete.setOnLongClickListener {
            number.clear()
            showNumber()
            true
        }
        view.findViewById<View>(R.id.btnTogglePad).setOnClickListener {
            padPanel.visibility = if (padPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        view.findViewById<View>(R.id.btnCall).setOnClickListener { doCall() }
        view.findViewById<View>(R.id.btnCallSim).setOnClickListener { doSimCall() }
    }

    private fun buildPad(pad: GridLayout) {
        val keys = listOf(
            "1" to "", "2" to "ABC", "3" to "DEF",
            "4" to "GHI", "5" to "JKL", "6" to "MNO",
            "7" to "PQRS", "8" to "TUV", "9" to "WXYZ",
            "*" to "", "0" to "+", "#" to ""
        )
        val dp = resources.displayMetrics.density
        for ((digit, letters) in keys) {
            val cell = LinearLayout(requireContext())
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            cell.setPadding(0, (7 * dp).toInt(), 0, (7 * dp).toInt())
            val outValue = android.util.TypedValue()
            requireContext().theme.resolveAttribute(
                android.R.attr.selectableItemBackground, outValue, true
            )
            cell.setBackgroundResource(R.drawable.bg_pad_key)

            val d = TextView(requireContext())
            d.text = digit
            d.textSize = 26f
            d.gravity = Gravity.CENTER
            d.setTextColor(tvNumber.textColors)
            cell.addView(d)

            val l = TextView(requireContext())
            l.text = if (letters.isEmpty()) " " else letters
            l.textSize = 10f
            l.gravity = Gravity.CENTER
            l.setTextColor(0xFF7B8794.toInt())
            cell.addView(l)

            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            )
            lp.width = 0
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            cell.layoutParams = lp

            cell.setOnClickListener {
                number.append(digit)
                showNumber()
            }
            if (digit == "0") {
                cell.setOnLongClickListener {
                    number.append("+")
                    showNumber()
                    true
                }
            }
            if (digit in "123456789") {
                cell.setOnLongClickListener { speedDial(digit); true }
            }
            pad.addView(cell)
        }
    }

    /** Digit chepe dhorle: save kora number-e call (1 = voicemail). Na thakle number boshanor dialog. */
    private fun speedDial(digit: String) {
        val saved = Extras.speed(digit)
        if (saved.isNotEmpty()) {
            val accId = accounts.getOrNull(accIndex)?.id
            (requireActivity() as MainActivity).ensureMic {
                val err = SipEngine.call(saved, accId)
                if (err != null) context?.toast(err)
            }
            return
        }
        val et = EditText(requireContext())
        et.hint = "Number"
        et.inputType = android.text.InputType.TYPE_CLASS_PHONE
        AlertDialog.Builder(requireContext())
            .setTitle(if (digit == "1") "Voicemail number" else "Speed dial $digit")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                Extras.setSpeed(digit, et.text.toString())
                context?.toast("Save hoyeche. Abar digit-ta chepe dhorun")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showNumber() {
        tvNumber.text = number.toString()
        btnDelete.visibility = if (number.isEmpty()) View.INVISIBLE else View.VISIBLE
    }

    private fun doCall() {
        if (padPanel.visibility != View.VISIBLE) {
            padPanel.visibility = View.VISIBLE
            return
        }
        val n = number.toString().trim()
        if (n.isEmpty()) {
            context?.toast("Number din")
            return
        }
        val accId = accounts.getOrNull(accIndex)?.id
        (requireActivity() as MainActivity).ensureMic {
            val err = SipEngine.call(n, accId)
            if (err != null) context?.toast(err)
        }
    }

    /** Phone-er SIM diye call (SIP noy). Dual SIM hole phone nijei SIM bachte bole. */
    private fun doSimCall() {
        if (padPanel.visibility != View.VISIBLE) {
            padPanel.visibility = View.VISIBLE
            return
        }
        (requireActivity() as MainActivity).simCall(number.toString())
    }

    // ---------- Lifecycle ----------

    override fun onStart() {
        super.onStart()
        SipEngine.addListener(this)
        accounts = Store.accounts().filter { it.enabled }
        val def = accounts.indexOfFirst { it.id == Store.defaultAccountId }
        accIndex = if (def >= 0) def else 0
        updateStatus()
        updateReturn()
        reload()
    }

    override fun onStop() {
        super.onStop()
        SipEngine.removeListener(this)
    }

    override fun onAccountsChanged() {
        updateStatus()
    }

    override fun onCallStateChanged(call: Call, state: Call.State) {
        updateReturn()
        if (state == Call.State.End || state == Call.State.Released) reload()
    }

    private fun updateStatus() {
        val acc = accounts.getOrNull(accIndex)
        tvReg.text = if (acc == null) {
            "No SIP account — Settings (gear icon) > SIP accounts"
        } else {
            val name = acc.label.ifBlank { acc.username }
            val more = if (accounts.size > 1) "  (tap to switch)" else ""
            "$name · ${SipEngine.regStates[acc.id] ?: "—"}$more"
        }
    }

    private fun updateReturn() {
        btnReturn.visibility = if (SipEngine.activeCall() != null) View.VISIBLE else View.GONE
    }

    // ---------- Recents ----------

    private fun reload() {
        val all = SipEngine.callLogs().sortedByDescending { it.startDate }
        var result = when (filter) {
            1 -> all.filter { it.status == Call.Status.Missed }
            2 -> all.filter { it.dir == Call.Dir.Outgoing }
            else -> all
        }
        if (query.isNotEmpty()) {
            result = result.filter {
                SipEngine.labelFor(it.remoteAddress).lowercase().contains(query)
            }
        }
        logs = result
        tvTitle.text = when (filter) {
            1 -> "Missed"
            2 -> "Outgoing"
            else -> "Recents"
        }

        adapter.rows = logs.map { log ->
            val incoming = log.dir == Call.Dir.Incoming
            val arrow = if (incoming) "↙ Incoming" else "↗ Outgoing"
            val status = when (log.status) {
                Call.Status.Missed -> " · Missed"
                Call.Status.Declined -> " · Declined"
                Call.Status.Aborted -> " · Not connected"
                else -> ""
            }
            val num = SipEngine.remoteNumber(log.remoteAddress)
            val name = PhoneContacts.nameFor(num)
            val details = "$arrow$status · ${fmtDate(log.startDate)} · ${fmtDuration(log.duration)}"
            Row(
                if (name != null) nameWithNumber(name, num) else num,
                details
            )
        }
        adapter.notifyDataSetChanged()
    }

    private fun showDetails(log: CallLog) {
        val num = SipEngine.remoteNumber(log.remoteAddress)
        val name = PhoneContacts.nameFor(num) ?: "—"
        val type = if (log.dir == Call.Dir.Incoming) "Incoming" else "Outgoing"
        val status = when (log.status) {
            Call.Status.Success -> "Answered"
            Call.Status.Missed -> "Missed"
            Call.Status.Declined -> "Declined"
            Call.Status.Aborted -> "Not connected"
            else -> "Other"
        }
        val full = SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("Asia/Dhaka")
        }.format(Date(toMillis(log.startDate)))
        val msg = "Number: $num\n" +
            "Name: $name\n" +
            "Type: $type\n" +
            "Status: $status\n" +
            "Time: $full\n" +
            "Duration: ${fmtDuration(log.duration)}"

        AlertDialog.Builder(requireContext())
            .setTitle("Call details")
            .setMessage(msg)
            .setPositiveButton("SIP call") { _, _ ->
                (requireActivity() as MainActivity).ensureMic {
                    val err = SipEngine.call(num, null)
                    if (err != null) context?.toast(err)
                }
            }
            .setNeutralButton("SIM call") { _, _ ->
                (requireActivity() as MainActivity).simCall(num)
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun confirmDelete(log: CallLog) {
        AlertDialog.Builder(requireContext())
            .setTitle("Ei entry muchben?")
            .setPositiveButton("Muchun") { _, _ ->
                SipEngine.removeLog(log)
                reload()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // Linphone shadharonoto second-e dey; jodi millisecond hoy tahole ei check
    private fun toMillis(t: Long): Long = if (t < 100_000_000_000L) t * 1000 else t

    // Bangladesh shomoy (Asia/Dhaka), AM/PM shoho
    private fun fmtDate(t: Long): String =
        SimpleDateFormat("dd MMM, hh:mm a", Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("Asia/Dhaka")
        }.format(Date(toMillis(t)))
}
