package com.myvoip.app

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment

/** Ekta number-er sathe chat. SIP button = SIP account diye, SMS button = phone-er SIM diye. */
class ChatFragment : Fragment(R.layout.fragment_chat) {

    companion object {
        fun newInstance(peer: String) = ChatFragment().apply {
            arguments = Bundle().apply { putString("peer", peer) }
        }
    }

    private lateinit var peer: String
    private var msgs: List<Msg> = emptyList()
    private lateinit var list: ListView
    private lateinit var et: EditText

    private val adapter = object : BaseAdapter() {
        override fun getCount() = msgs.size
        override fun getItem(p: Int): Any = msgs[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val ctx = parent!!.context
            val d = ctx.resources.displayMetrics.density
            val m = msgs[p]
            val wrap = LinearLayout(ctx)
            wrap.orientation = LinearLayout.VERTICAL
            wrap.setPadding((12 * d).toInt(), (4 * d).toInt(), (12 * d).toInt(), (4 * d).toInt())
            wrap.gravity = if (m.outgoing) Gravity.END else Gravity.START

            val bubble = TextView(ctx)
            bubble.text = m.text
            bubble.textSize = 16f
            bubble.maxWidth = (ctx.resources.displayMetrics.widthPixels * 0.75f).toInt()
            bubble.setPadding((14 * d).toInt(), (9 * d).toInt(), (14 * d).toInt(), (9 * d).toInt())
            val bg = GradientDrawable()
            bg.cornerRadius = 18 * d
            if (m.outgoing) {
                bg.setColor(if (m.via == "SIP") Color.parseColor("#16A36A") else Color.parseColor("#3478D4"))
                bubble.setTextColor(Color.WHITE)
            } else {
                bg.setColor(Color.parseColor("#33808080"))
                bubble.setTextColor(
                    android.util.TypedValue().let {
                        ctx.theme.resolveAttribute(android.R.attr.textColorPrimary, it, true)
                        ctx.getColor(it.resourceId)
                    }
                )
            }
            bubble.background = bg

            val info = TextView(ctx)
            info.text = "${m.via} · ${fmtDhaka(m.time, "hh:mm a")}" +
                if (m.outgoing) " · ${m.status}" else ""
            info.textSize = 11f
            info.alpha = 0.55f
            info.gravity = if (m.outgoing) Gravity.END else Gravity.START

            wrap.addView(bubble)
            wrap.addView(info)
            return wrap
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        peer = requireArguments().getString("peer") ?: ""
        val name = PhoneContacts.nameFor(peer)
        view.findViewById<TextView>(R.id.tvPeer).text = if (name != null) "$name ($peer)" else peer
        view.findViewById<ImageView>(R.id.btnBack).setOnClickListener {
            parentFragmentManager.popBackStack()
        }
        list = view.findViewById(R.id.list)
        list.adapter = adapter
        et = view.findViewById(R.id.etMsg)

        view.findViewById<View>(R.id.btnSip).setOnClickListener { sendSip() }
        view.findViewById<View>(R.id.btnSms).setOnClickListener { sendSms() }
    }

    private fun text(): String? {
        val t = et.text.toString().trim()
        if (t.isEmpty()) {
            context?.toast("Message likhun")
            return null
        }
        return t
    }

    private fun sendSip() {
        val t = text() ?: return
        val err = SipEngine.sendSipMessage(peer, t) { failed ->
            // Provider SIP message dhorlo na -> phone theke pathanor option
            if (isAdded) {
                AlertDialog.Builder(requireContext())
                    .setTitle("SIP diye pathano gelo na")
                    .setMessage("Ei provider SIP message support na-o korte pare. SMS hishebe phone theke pathaben?")
                    .setPositiveButton("SMS pathao") { _, _ -> smsNow(failed.text) }
                    .setNegativeButton("Na", null)
                    .show()
            }
        }
        if (err != null) context?.toast(err) else et.setText("")
    }

    private fun sendSms() {
        val t = text() ?: return
        smsNow(t)
    }

    private fun smsNow(t: String) {
        val act = activity as? MainActivity ?: return
        act.sendSms(peer, t) { ok ->
            if (ok) {
                MessageStore.add(Msg(peer, t, System.currentTimeMillis(), true, "SMS", "Sent"))
                et.setText("")
            }
        }
    }

    override fun onStart() {
        super.onStart()
        MessageStore.onChange = { reload() }
        reload()
    }

    override fun onStop() {
        MessageStore.onChange = null
        super.onStop()
    }

    private fun reload() {
        if (view == null) return
        msgs = MessageStore.forPeer(MessageStore.keyOf(peer))
        adapter.notifyDataSetChanged()
    }
}
