package com.myvoip.app

import android.content.Context
import android.content.SharedPreferences

/** App-er chhoto settings (audio, privacy, backup). */
object AppSettings {
    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("myvoip_settings", Context.MODE_PRIVATE)
    }

    var speakerDefault: Boolean
        get() = prefs.getBoolean("speaker_default", false)
        set(v) {
            prefs.edit().putBoolean("speaker_default", v).apply()
        }

    var ringtoneOn: Boolean
        get() = prefs.getBoolean("ringtone_on", true)
        set(v) {
            prefs.edit().putBoolean("ringtone_on", v).apply()
        }

    var askRecordConsent: Boolean
        get() = prefs.getBoolean("ask_record_consent", true)
        set(v) {
            prefs.edit().putBoolean("ask_record_consent", v).apply()
        }

    var autoBackup: Boolean
        get() = prefs.getBoolean("auto_backup", true)
        set(v) {
            prefs.edit().putBoolean("auto_backup", v).apply()
        }

    var lastAutoBackup: Long
        get() = prefs.getLong("last_auto_backup", 0L)
        set(v) {
            prefs.edit().putLong("last_auto_backup", v).apply()
        }
}
