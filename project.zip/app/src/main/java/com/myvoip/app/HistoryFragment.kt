package com.myvoip.app

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import org.linphone.core.Call
import org.linphone.core.CallLog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryFragment : Fragment(R.layout.fragment_list) {

    private lateinit var adapter: TwoLineAdapter
    private lateinit var btnFilter: Button
    private var logs: List<CallLog> = emptyList()

    // 0 = All, 1 = Missed, 2 = Incoming, 3 = Outgoing
    private var filter = 0
    private val filterNames = listOf("All", "Missed", "Incoming", "Outgoing")

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.findViewById<TextView>(R.id.tvTitle).text = "Call History"
        view.findViewById<TextView>(R.id.tvEmpty).text = "Kono call history nei"

        val btnClear = view.findViewById<Button>(R.id.btnAction)
        btnClear.text = "Clear"
        btnClear.setOnClickListener {
            if (SipEngine.callLogs().isEmpty()) return@setOnClickListener
            AlertDialog.Builder(requireContext())
                .setTitle("Shob history muchben?")
                .setPositiveButton("Muchun") { _, _ ->
                    SipEngine.clearLogs()
                    reload()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Filter: tap korle All -> Missed -> Incoming -> Outgoing ghure ashe
        btnFilter = view.findViewById(R.id.btnAction2)
        btnFilter.visibility = View.VISIBLE
        btnFilter.setOnClickListener {
            filter = (filter + 1) % filterNames.size
            reload()
        }

        val list = view.findViewById<ListView>(R.id.list)
        adapter = TwoLineAdapter(requireContext(), emptyList())
        list.adapter = adapter
        list.emptyView = view.findViewById(R.id.tvEmpty)

        // Tap = Call details
        list.setOnItemClickListener { _, _, pos, _ ->
            val log = logs.getOrNull(pos) ?: return@setOnItemClickListener
            showDetails(log)
        }

        // Dhore rakhle ei entry delete
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val log = logs.getOrNull(pos) ?: return@setOnItemLongClickListener true
            confirmDelete(log)
            true
        }
    }

    override fun onStart() {
        super.onStart()
        reload()
    }

    private fun reload() {
        val all = SipEngine.callLogs().sortedByDescending { it.startDate }
        logs = when (filter) {
            1 -> all.filter { it.status == Call.Status.Missed }
            2 -> all.filter { it.dir == Call.Dir.Incoming }
            3 -> all.filter { it.dir == Call.Dir.Outgoing }
            else -> all
        }
        btnFilter.text = "Filter: ${filterNames[filter]}"

        adapter.rows = logs.map { log ->
            val incoming = log.dir == Call.Dir.Incoming
            val arrow = if (incoming) "↙ Incoming" else "↗ Outgoing"
            val status = when (log.status) {
                Call.Status.Missed -> " · Missed"
                Call.Status.Declined -> " · Declined"
                Call.Status.Aborted -> " · Not connected"
                else -> ""
            }
            Row(
                SipEngine.labelFor(log.remoteAddress),
                "$arrow$status · ${fmtDate(log.startDate)} · ${fmtDuration(log.duration)}"
            )
        }
        adapter.notifyDataSetChanged()
    }

    private fun showDetails(log: CallLog) {
        val number = SipEngine.remoteNumber(log.remoteAddress)
        val name = PhoneContacts.nameFor(number) ?: "—"
        val type = if (log.dir == Call.Dir.Incoming) "Incoming" else "Outgoing"
        val status = when (log.status) {
            Call.Status.Success -> "Answered"
            Call.Status.Missed -> "Missed"
            Call.Status.Declined -> "Declined"
            Call.Status.Aborted -> "Not connected"
            else -> "Other"
        }
        val full = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault())
            .format(Date(toMillis(log.startDate)))
        val msg = "Number: $number\n" +
            "Name: $name\n" +
            "Type: $type\n" +
            "Status: $status\n" +
            "Time: $full\n" +
            "Duration: ${fmtDuration(log.duration)}"

        AlertDialog.Builder(requireContext())
            .setTitle("Call details")
            .setMessage(msg)
            .setPositiveButton("Call") { _, _ ->
                (requireActivity() as MainActivity).ensureMic {
                    val err = SipEngine.call(number, null)
                    if (err != null) context?.toast(err)
                }
            }
            .setNeutralButton("Delete") { _, _ -> confirmDelete(log) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun confirmDelete(log: CallLog) {
        AlertDialog.Builder(requireContext())
            .setTitle("Ei entry muchben?")
            .setPositiveButton("Muchun") { _, _ ->
                SipEngine.removeLog(log)
                reload()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // Linphone shadharonoto second-e dey; jodi millisecond hoy tahole ei check
    private fun toMillis(t: Long): Long = if (t < 100_000_000_000L) t * 1000 else t

    private fun fmtDate(t: Long): String =
        SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(toMillis(t)))
}
