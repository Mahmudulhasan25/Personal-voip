package com.myvoip.app

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import org.linphone.core.Call
import org.linphone.core.CallLog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryFragment : Fragment(R.layout.fragment_list) {

    private lateinit var adapter: TwoLineAdapter
    private var logs: List<CallLog> = emptyList()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view.findViewById<TextView>(R.id.tvTitle).text = "Call History"
        view.findViewById<TextView>(R.id.tvEmpty).text = "Kono call history nei"

        val btn = view.findViewById<Button>(R.id.btnAction)
        btn.text = "Clear all"
        btn.setOnClickListener {
            if (logs.isEmpty()) return@setOnClickListener
            AlertDialog.Builder(requireContext())
                .setTitle("Shob history muchben?")
                .setPositiveButton("Muchun") { _, _ ->
                    SipEngine.clearLogs()
                    reload()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        val list = view.findViewById<ListView>(R.id.list)
        adapter = TwoLineAdapter(requireContext(), emptyList())
        list.adapter = adapter
        list.emptyView = view.findViewById(R.id.tvEmpty)

        // Tap korle abar call
        list.setOnItemClickListener { _, _, pos, _ ->
            val log = logs.getOrNull(pos) ?: return@setOnItemClickListener
            val number = SipEngine.remoteNumber(log.remoteAddress)
            (requireActivity() as MainActivity).ensureMic {
                val err = SipEngine.call(number, null)
                if (err != null) context?.toast(err)
            }
        }

        // Dhore rakhle ei entry delete
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val log = logs.getOrNull(pos) ?: return@setOnItemLongClickListener true
            AlertDialog.Builder(requireContext())
                .setTitle("Ei entry muchben?")
                .setPositiveButton("Muchun") { _, _ ->
                    SipEngine.removeLog(log)
                    reload()
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }
    }

    override fun onStart() {
        super.onStart()
        reload()
    }

    private fun reload() {
        logs = SipEngine.callLogs().sortedByDescending { it.startDate }
        adapter.rows = logs.map { log ->
            val incoming = log.dir == Call.Dir.Incoming
            val arrow = if (incoming) "↙ Incoming" else "↗ Outgoing"
            val status = when (log.status) {
                Call.Status.Missed -> " · Missed"
                Call.Status.Declined -> " · Declined"
                Call.Status.Aborted -> " · Not connected"
                else -> ""
            }
            Row(
                SipEngine.labelFor(log.remoteAddress),
                "$arrow$status · ${fmtDate(log.startDate)} · ${fmtDuration(log.duration)}"
            )
        }
        adapter.notifyDataSetChanged()
    }

    private fun fmtDate(t: Long): String {
        // Linphone shadharonoto second-e dey; jodi millisecond hoy tahole ei check
        val ms = if (t < 100_000_000_000L) t * 1000 else t
        return SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(ms))
    }
}
