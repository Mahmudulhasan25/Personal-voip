package com.example.sipphone

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.linphone.core.TransportType

class MainActivity : AppCompatActivity(), SipManager.Listener {

    private lateinit var sip: SipManager

    private lateinit var etDomain: EditText
    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var rbTcp: RadioButton
    private lateinit var rbTls: RadioButton
    private lateinit var etNumber: EditText
    private lateinit var tvRegStatus: TextView
    private lateinit var tvCallStatus: TextView

    private var pendingAction: (() -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.RECORD_AUDIO] == true) {
            pendingAction?.invoke()
        } else {
            Toast.makeText(this, "Microphone permission lagbe", Toast.LENGTH_SHORT).show()
        }
        pendingAction = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etDomain = findViewById(R.id.etDomain)
        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        rbTcp = findViewById(R.id.rbTcp)
        rbTls = findViewById(R.id.rbTls)
        etNumber = findViewById(R.id.etNumber)
        tvRegStatus = findViewById(R.id.tvRegStatus)
        tvCallStatus = findViewById(R.id.tvCallStatus)

        sip = SipManager(applicationContext)
        sip.listener = this
        sip.start()

        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            withPermissions { login() }
        }
        findViewById<Button>(R.id.btnCall).setOnClickListener {
            val number = etNumber.text.toString().trim()
            if (number.isEmpty()) {
                Toast.makeText(this, "Number din", Toast.LENGTH_SHORT).show()
            } else {
                withPermissions { sip.call(number) }
            }
        }
        findViewById<Button>(R.id.btnHangup).setOnClickListener { sip.hangup() }
        findViewById<ToggleButton>(R.id.tbMute).setOnCheckedChangeListener { _, checked ->
            sip.setMuted(checked)
        }
        findViewById<ToggleButton>(R.id.tbSpeaker).setOnCheckedChangeListener { _, checked ->
            sip.setSpeaker(checked)
        }
    }

    private fun login() {
        val domain = etDomain.text.toString().trim()
        val user = etUsername.text.toString().trim()
        val pass = etPassword.text.toString()
        if (domain.isEmpty() || user.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Domain, username, password sob din", Toast.LENGTH_SHORT).show()
            return
        }
        val transport = when {
            rbTls.isChecked -> TransportType.Tls
            rbTcp.isChecked -> TransportType.Tcp
            else -> TransportType.Udp
        }
        sip.login(user, pass, domain, transport)
    }

    /** Mic (ar Android 13+ e notification) permission nite hoy; age check kore tarpor kaj. */
    private fun withPermissions(action: () -> Unit) {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)

        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            action()
        } else {
            pendingAction = action
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    // ---------- SipManager.Listener ----------

    override fun onRegistrationChanged(state: String) {
        tvRegStatus.text = state
    }

    override fun onCallStateChanged(state: String, remoteUser: String?) {
        tvCallStatus.text = "Call: $state ${remoteUser ?: ""}"
    }

    override fun onIncomingCall(remoteUser: String) {
        AlertDialog.Builder(this)
            .setTitle("Incoming call")
            .setMessage("$remoteUser apnake call korche")
            .setCancelable(false)
            .setPositiveButton("Answer") { _, _ -> withPermissions { sip.answer() } }
            .setNegativeButton("Reject") { _, _ -> sip.hangup() }
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        sip.listener = null
        sip.stop()
    }
}
