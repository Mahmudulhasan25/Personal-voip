package com.example.sipphone

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.linphone.core.Account
import org.linphone.core.AudioDevice
import org.linphone.core.Call
import org.linphone.core.Core
import org.linphone.core.CoreListenerStub
import org.linphone.core.Factory
import org.linphone.core.RegistrationState
import org.linphone.core.TransportType

/**
 * Linphone SDK-র ওপর ছোট একটা wrapper।
 * Activity শুধু এই class-এর method ডাকবে, SDK-র ভেতরের জিনিস সরাসরি ছোঁবে না।
 */
class SipManager(private val appContext: Context) {

    interface Listener {
        fun onRegistrationChanged(state: String)
        fun onCallStateChanged(state: String, remoteUser: String?)
        fun onIncomingCall(remoteUser: String)
    }

    var listener: Listener? = null

    private val main = Handler(Looper.getMainLooper())
    private lateinit var core: Core
    private var loggedInDomain: String? = null

    private val coreListener = object : CoreListenerStub() {
        override fun onAccountRegistrationStateChanged(
            core: Core,
            account: Account,
            state: RegistrationState?,
            message: String
        ) {
            val text = when (state) {
                RegistrationState.Ok -> "Registered ✅"
                RegistrationState.Progress -> "Registering..."
                RegistrationState.Failed -> "Registration failed: $message"
                RegistrationState.Cleared -> "Unregistered"
                else -> state?.name ?: "Unknown"
            }
            main.post { listener?.onRegistrationChanged(text) }
        }

        override fun onCallStateChanged(
            core: Core,
            call: Call,
            state: Call.State?,
            message: String
        ) {
            val remote = call.remoteAddress.username ?: call.remoteAddress.asStringUriOnly()
            when (state) {
                Call.State.IncomingReceived -> main.post { listener?.onIncomingCall(remote) }
                else -> main.post { listener?.onCallStateChanged(state?.name ?: "Unknown", remote) }
            }
        }
    }

    /** App শুরুর সময় একবার ডাকুন। */
    fun start() {
        val factory = Factory.instance()
        factory.setDebugMode(true, "SipPhone")
        // Android context অবশ্যই শেষ parameter হিসেবে দিতে হবে
        core = factory.createCore(null, null, appContext)
        core.addListener(coreListener)
        core.start()
    }

    /** SIP account দিয়ে login (register)। */
    fun login(
        username: String,
        password: String,
        domain: String,
        transport: TransportType = TransportType.Udp
    ) {
        val factory = Factory.instance()
        loggedInDomain = domain

        // ক্রেডেনশিয়াল
        val authInfo = factory.createAuthInfo(username, null, password, null, null, domain)

        // Account-এর সেটিংস
        val params = core.createAccountParams()
        params.identityAddress = factory.createAddress("sip:$username@$domain")

        val server = factory.createAddress("sip:$domain")
        server?.transport = transport
        params.serverAddress = server
        params.isRegisterEnabled = true

        val account = core.createAccount(params)
        core.addAuthInfo(authInfo)
        core.addAccount(account)
        core.defaultAccount = account
    }

    /** নম্বর বা user ডায়াল করা। আলাদা domain না দিলে নিজের account-এর domain ব্যবহার হবে। */
    fun call(numberOrUser: String) {
        val domain = loggedInDomain ?: return
        val target = if (numberOrUser.contains("@")) "sip:$numberOrUser" else "sip:$numberOrUser@$domain"
        val remote = core.interpretUrl(target, false) ?: return
        val params = core.createCallParams(null) ?: return
        core.inviteAddressWithParams(remote, params)
    }

    fun answer() {
        core.currentCall?.accept()
    }

    /** Call কাটা বা incoming call reject করা। */
    fun hangup() {
        (core.currentCall ?: core.calls.firstOrNull())?.terminate()
    }

    fun setMuted(muted: Boolean) {
        core.isMicEnabled = !muted
    }

    fun isMuted(): Boolean = !core.isMicEnabled

    fun setSpeaker(on: Boolean) {
        val wanted = if (on) AudioDevice.Type.Speaker else AudioDevice.Type.Earpiece
        core.audioDevices.firstOrNull { it.type == wanted }?.let { core.outputAudioDevice = it }
    }

    /** Network বদলালে (Wi-Fi ↔ mobile data) আবার register করতে। */
    fun refreshRegistration() {
        core.refreshRegisters()
    }

    fun stop() {
        core.removeListener(coreListener)
        core.stop()
    }
}
