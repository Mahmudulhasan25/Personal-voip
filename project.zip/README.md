# My VoIP (Android, Kotlin + Linphone SDK)

## Feature list (shob ache)
| Feature | Kothay |
|---|---|
| SIP Login (Host, Username, Password) | Accounts tab -> Add account |
| Incoming & Outgoing Call | Dial tab / Call screen |
| Call Recording | Call cholar shomoy "Record" button |
| Call History | History tab (tap = abar call, dhore rakhle = delete) |
| Contact List | Contacts tab (add / edit / delete / call) |
| Speaker & Mute | Call screen |
| Multiple SIP Accounts | Accounts tab (default account, enable/disable, delete) |
| UDP / TCP / TLS | Account form-er dropdown |
| Recording List ও Playback | Records tab -> tap -> Play |
| Recording Save ও Delete | Records tab -> tap -> Save to phone / Delete |

## Build (GitHub Actions)
1. Repository-te purono `project.zip` muche ei `project.zip` upload korun.
2. Actions e build cholbe. Shesh hole Artifacts theke `sip-phone-apk` namiye zip khulun.
3. `app-arm64-v8a-debug.apk` age install korun. "not compatible" bolle `app-armeabi-v7a-debug.apk`.

## Tothyo
- Account, contact: app-er nijossho private storage-e thake. Password ekhon plain-e save hoy (porer dhape encrypt korbo).
- Recording: `Android/data/com.myvoip.app/files/recordings/` e `.wav`. "Save to phone" diye onno jayga-e copy kora jay.
- Linphone SDK GPLv3: bondho-source kore bikri korte hole commercial license lagbe.
- Kono deshe call record-e onno pokkhoer shommoti lage. App record shuru-r age shotorko kore.

## Sima (limitations)
1. App bondho/background-e thakle incoming call ashbe na (push notification nei).
2. Recording-e duito pokkhoi record hoy kina, ta provider/phone-er upor kichu nirbhor kore; test kore dekhun.
3. Self-signed certificate-er TLS server-e connect nao hote pare.
4. Notun feature-ta compile kore test kora hoyni, build error ashle error-er text pathan.

## Crash hole
App crash korle abar khulle "Last crash report" box ashbe. Tar screenshot pathan.
