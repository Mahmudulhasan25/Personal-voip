# My VoIP (Android, Kotlin + Linphone SDK)

## Feature list
- Calling: SIP login/logout, Dial pad, incoming/outgoing call, Mute, Speaker, Hold, call duration
- Contacts: phone contacts + app contacts, search, add/edit/delete, favorites, direct call
- Call management: history (All/Missed/Incoming/Outgoing), call details, call recording, recordings list/playback/save/delete
- Backup: manual backup/restore (file ba Google Drive), daily automatic backup, Android Auto Backup
- Settings: SIP accounts (multiple, UDP/TCP/TLS), Audio, Notifications, Privacy & Security, Backup
- Call screen: compact icon-button layout, DTMF keypad, custom wallpaper (Settings -> Call screen wallpaper)
- Home: Recents on top (filter: Missed/Outgoing/All, search, settings icon), dial pad at the bottom; Theme: System/Light/Dark; icon-style Settings page
- SIM call: blue "SIM call" button on the dial pad calls through the phone SIM (CALL_PHONE permission)

## Build (GitHub Actions)
1. Repository-te purono `project.zip` muche ei `project.zip` upload korun.
2. Actions e build cholbe. Artifacts theke `sip-phone-apk` namiye zip khulun.
3. `app-arm64-v8a-debug.apk` age install korun. "not compatible" bolle `app-armeabi-v7a-debug.apk`.

## Limitations
- Background/bondho obosthay incoming call ashbe na (push notification nei).
- Google Drive: direct Drive API nei. File backup-e Drive beche neya jay; Android Auto Backup phone-er Google backup setting-er upor nirbhor kore.
- Backup-e call history ar recording file thake na.
- Password plain-e private storage-e thake.
- Call record-er age onno pokkhoer shommoti nin.
- Compile kore test kora hoyni; build error hole error-er text pathan.
